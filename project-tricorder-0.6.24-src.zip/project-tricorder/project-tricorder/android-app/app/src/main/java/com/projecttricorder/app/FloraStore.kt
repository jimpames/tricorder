package com.projecttricorder.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import java.io.FileInputStream
import kotlin.math.exp

/**
 * iNaturalist MobileNet classifiers from Google Coral test_data.
 * Plants / insects / birds — first-run download, like BirdNET.
 */
class FloraStore(private val context: android.content.Context) {

    data class Pack(
        val id: String,
        val modelName: String,
        val labelName: String,
        val modelUrl: String,
        val labelUrl: String,
    )

    private val dir: File get() = File(context.filesDir, "models").also { it.mkdirs() }

    private val packs = listOf(
        Pack(
            "plant",
            "mobilenet_v2_1.0_224_inat_plant_quant.tflite",
            "inat_plant_labels.txt",
            "https://raw.githubusercontent.com/google-coral/test_data/master/mobilenet_v2_1.0_224_inat_plant_quant.tflite",
            "https://raw.githubusercontent.com/google-coral/test_data/master/inat_plant_labels.txt",
        ),
        Pack(
            "insect",
            "mobilenet_v2_1.0_224_inat_insect_quant.tflite",
            "inat_insect_labels.txt",
            "https://raw.githubusercontent.com/google-coral/test_data/master/mobilenet_v2_1.0_224_inat_insect_quant.tflite",
            "https://raw.githubusercontent.com/google-coral/test_data/master/inat_insect_labels.txt",
        ),
        Pack(
            "bird_vis",
            "mobilenet_v2_1.0_224_inat_bird_quant.tflite",
            "inat_bird_labels.txt",
            "https://raw.githubusercontent.com/google-coral/test_data/master/mobilenet_v2_1.0_224_inat_bird_quant.tflite",
            "https://raw.githubusercontent.com/google-coral/test_data/master/inat_bird_labels.txt",
        ),
    )

    fun status(): JSONObject {
        val o = JSONObject()
        var ready = 0
        val arr = JSONArray()
        for (p in packs) {
            val ok = File(dir, p.modelName).exists() && File(dir, p.modelName).length() > 10_000
            if (ok) ready++
            arr.put(JSONObject().put("id", p.id).put("ready", ok))
        }
        return o.put("ready", ready > 0).put("packs_ready", ready).put("packs", arr)
    }

    fun ready(): Boolean = status().optBoolean("ready")

    fun download(onProgress: (String) -> Unit): String {
        for (p in packs) {
            onProgress("fetching ${p.id}")
            pull(p.modelUrl, File(dir, p.modelName))
            pull(p.labelUrl, File(dir, p.labelName))
        }
        return "flora/fauna ready (${status().optInt("packs_ready")} packs)"
    }

    fun classifyDataUrl(dataUrl: String): JSONArray {
        val comma = dataUrl.indexOf(',')
        val b64 = if (comma >= 0) dataUrl.substring(comma + 1) else dataUrl
        val bytes = Base64.decode(b64, Base64.DEFAULT)
        val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return JSONArray()
        return classifyBitmap(bmp)
    }

    fun classifyBitmap(src: Bitmap): JSONArray {
        val out = JSONArray()
        for (p in packs) {
            val mf = File(dir, p.modelName)
            if (!mf.exists() || mf.length() < 10000) continue
            try {
                out.put(JSONObject().put("pack", p.id).put("hits", runPack(mf, src)))
            } catch (t: Exception) {
                out.put(JSONObject().put("pack", p.id).put("error", t.message ?: "infer fail"))
            }
        }
        return out
    }

    private fun runPack(model: File, src: Bitmap): JSONArray {
        // These Coral files ship TFLite ImageClassifier metadata — same API family as YAMNet.
        val opts = org.tensorflow.lite.task.vision.classifier.ImageClassifier.ImageClassifierOptions.builder()
            .setMaxResults(3)
            .setScoreThreshold(0.05f)
            .build()
        val clf = org.tensorflow.lite.task.vision.classifier.ImageClassifier.createFromFileAndOptions(model, opts)
        try {
            val image = org.tensorflow.lite.support.image.TensorImage.fromBitmap(
                if (src.config == Bitmap.Config.ARGB_8888) src else src.copy(Bitmap.Config.ARGB_8888, false)
            )
            val hits = JSONArray()
            for (c in clf.classify(image)) {
                for (cat in c.categories) {
                    val name = cat.label ?: cat.displayName ?: continue
                    if (name.startsWith("???") || name.equals("background", true)) continue
                    hits.put(JSONObject().put("en", name).put("score", cat.score.toDouble()))
                }
            }
            return hits
        } finally {
            clf.close()
        }
    }

    @Suppress("unused")
    private fun runPackInterpreter(model: File, labelsFile: File, src: Bitmap): JSONArray {
        val labels = labelsFile.readLines().filter { it.isNotBlank() }
        val interp = Interpreter(load(model), Interpreter.Options().setNumThreads(2))
        try {
            val inT = interp.getInputTensor(0)
            val shape = inT.shape() // [1,H,W,3]
            val h = if (shape.size >= 3) shape[1] else 224
            val w = if (shape.size >= 4) shape[2] else 224
            val scaled = Bitmap.createScaledBitmap(src, w, h, true)
            val input = fillInput(scaled, inT.dataType(), h, w)
            val outT = interp.getOutputTensor(0)
            val n = outT.shape().last().coerceAtLeast(1)
            val scores = FloatArray(n)
            when (outT.dataType()) {
                DataType.UINT8 -> {
                    val raw = ByteArray(n)
                    interp.run(input, raw)
                    val q = outT.quantizationParams()
                    for (i in 0 until n) {
                        scores[i] = (raw[i].toInt() and 0xFF) * q.scale + q.zeroPoint
                    }
                }
                else -> {
                    val arr = Array(1) { FloatArray(n) }
                    interp.run(input, arr)
                    System.arraycopy(arr[0], 0, scores, 0, n)
                }
            }
            // If values look like logits, squash.
            val mx = scores.maxOrNull() ?: 0f
            if (mx > 1.5f) {
                for (i in scores.indices) scores[i] = (1f / (1f + exp(-scores[i])))
            }
            val ranked = scores.mapIndexed { i, v -> i to v }
                .sortedByDescending { it.second }
                .take(3)
            val hits = JSONArray()
            for ((i, v) in ranked) {
                if (v < 0.12f) continue
                val raw = labels.getOrNull(i) ?: continue
                if (raw.startsWith("???") || raw.equals("background", true)) continue
                hits.put(JSONObject().put("en", raw).put("score", v.toDouble()))
            }
            return hits
        } finally {
            interp.close()
        }
    }

    private fun fillInput(bmp: Bitmap, type: DataType, h: Int, w: Int): Any {
        val pixels = IntArray(h * w)
        bmp.getPixels(pixels, 0, w, 0, 0, w, h)
        return if (type == DataType.UINT8) {
            val buf = ByteBuffer.allocateDirect(h * w * 3).order(ByteOrder.nativeOrder())
            for (p in pixels) {
                buf.put(((p shr 16) and 0xFF).toByte())
                buf.put(((p shr 8) and 0xFF).toByte())
                buf.put((p and 0xFF).toByte())
            }
            buf.rewind()
            buf
        } else {
            val buf = ByteBuffer.allocateDirect(h * w * 3 * 4).order(ByteOrder.nativeOrder())
            for (p in pixels) {
                buf.putFloat(((p shr 16) and 0xFF) / 255f)
                buf.putFloat(((p shr 8) and 0xFF) / 255f)
                buf.putFloat((p and 0xFF) / 255f)
            }
            buf.rewind()
            buf
        }
    }

    private fun load(f: File): MappedByteBuffer {
        FileInputStream(f).use { fis ->
            val ch = fis.channel
            return ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size())
        }
    }

    private fun pull(url: String, dest: File) {
        val tmp = File(dest.absolutePath + ".part")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 120000
        conn.instanceFollowRedirects = true
        conn.connect()
        if (conn.responseCode >= 400) throw IllegalStateException("HTTP ${conn.responseCode} $url")
        conn.inputStream.use { input -> tmp.outputStream().use { output -> input.copyTo(output) } }
        tmp.renameTo(dest)
    }
}
