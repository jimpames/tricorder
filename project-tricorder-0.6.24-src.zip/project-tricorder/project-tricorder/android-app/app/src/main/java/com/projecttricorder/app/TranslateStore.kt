package com.projecttricorder.app

import com.google.android.gms.tasks.Tasks
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

class TranslateStore {

    private val manager = RemoteModelManager.getInstance()
    private var client: Translator? = null
    @Volatile private var pair: Pair<String, String>? = null

    data class Lang(val code: String, val name: String)

    fun languages(): List<Lang> {
        val all = TranslateLanguage.getAllLanguages().sorted()
        return all.map { Lang(it, displayName(it)) }
    }

    fun status(): JSONObject {
        val downloaded = downloadedCodes()
        return JSONObject()
            .put("ready", downloaded.isNotEmpty())
            .put("downloaded", JSONArray(downloaded))
            .put("count", downloaded.size)
            .put("available", TranslateLanguage.getAllLanguages().size)
    }

    fun downloadedCodes(): List<String> {
        return try {
            val models = Tasks.await(manager.getDownloadedModels(TranslateRemoteModel::class.java), 8, TimeUnit.SECONDS)
            models.map { it.language }.sorted()
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun downloadOne(code: String, onNote: (String) -> Unit): Boolean {
        val model = TranslateRemoteModel.Builder(code).build()
        onNote("XLAT fetching $code…")
        return try {
            Tasks.await(
                manager.download(model, DownloadConditions.Builder().build()),
                180,
                TimeUnit.SECONDS,
            )
            onNote("XLAT $code ready")
            true
        } catch (t: Exception) {
            onNote("XLAT $code fail: ${t.message}")
            false
        }
    }

    fun downloadAll(onNote: (String) -> Unit): String {
        val langs = TranslateLanguage.getAllLanguages().sorted()
        var ok = 0
        langs.forEachIndexed { i, code ->
            onNote("XLAT ${i + 1}/${langs.size} $code")
            if (downloadOne(code) { } ) ok += 1
        }
        return "Translator packs $ok/${langs.size} on device"
    }

    fun downloadPair(src: String, tgt: String, onNote: (String) -> Unit): String {
        val need = listOf(src, tgt).filter { it != "auto" }.distinct()
        need.forEach { downloadOne(it, onNote) }
        return status().toString()
    }

    @Synchronized
    fun release() {
        try { client?.close() } catch (_: Exception) {}
        client = null
        pair = null
    }

    @Synchronized
    fun ensurePair(src: String, tgt: String) {
        val s = if (src == "auto") TranslateLanguage.ENGLISH else src
        val t = tgt.ifBlank { TranslateLanguage.ENGLISH }
        val cur = pair
        if (cur?.first == s && cur.second == t && client != null) return
        try { client?.close() } catch (_: Exception) {}
        client = Translation.getClient(
            TranslatorOptions.Builder().setSourceLanguage(s).setTargetLanguage(t).build(),
        )
        pair = s to t
        try {
            Tasks.await(client!!.downloadModelIfNeeded(DownloadConditions.Builder().build()), 120, TimeUnit.SECONDS)
        } catch (_: Exception) { }
    }

    fun translate(text: String, src: String, tgt: String): String {
        if (text.isBlank()) return ""
        ensurePair(src, tgt)
        val c = client ?: return text
        return try {
            Tasks.await(c.translate(text), 20, TimeUnit.SECONDS)
        } catch (t: Exception) {
            "xlat fail: ${t.message}"
        }
    }

    fun localeFor(code: String): Locale {
        return when (code) {
            "zh" -> Locale.SIMPLIFIED_CHINESE
            "zh-TW", "zh-Hant" -> Locale.TRADITIONAL_CHINESE
            "iw", "he" -> Locale("he")
            else -> Locale(code)
        }
    }

    private fun displayName(code: String): String {
        return try {
            val loc = localeFor(code)
            loc.getDisplayLanguage(Locale.US).replaceFirstChar { it.uppercase() }
        } catch (_: Exception) {
            code
        }
    }
}
