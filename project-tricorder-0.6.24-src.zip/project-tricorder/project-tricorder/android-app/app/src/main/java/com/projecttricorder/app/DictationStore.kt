package com.projecttricorder.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.sqrt
import kotlin.math.abs

/**
 * Voice memos + hashed/synset embeddings. No extra Termux service.
 * USE tflite is fetched when earth-link is up so a later embedder can swap in;
 * matching already works offline via synset-expanded feature hashes.
 */
class DictationStore(private val context: android.content.Context) {

    private val dir: File get() = File(context.filesDir, "dictation").also { it.mkdirs() }
    private val file: File get() = File(dir, "memos.json")
    private val embedFile: File get() = File(context.filesDir, "models/universal_sentence_encoder.tflite")

    companion object {
        const val EMBED_URL =
            "https://storage.googleapis.com/mediapipe-models/text_embedder/universal_sentence_encoder/float32/1/universal_sentence_encoder.tflite"

        val SYNSETS = listOf(
            listOf("puzzle", "riddle", "crossword", "enigma", "conundrum", "brainteaser"),
            listOf("weapon", "gun", "pistol", "rifle", "firearm", "knife"),
            listOf("weather", "storm", "rain", "forecast", "climate"),
            listOf("plane", "aircraft", "flight", "airplane", "jet"),
            listOf("camp", "tent", "campsite", "bivouac"),
            listOf("meeting", "briefing", "standup", "conference", "call"),
            listOf("todo", "task", "action", "assignment"),
            listOf("idea", "thought", "notion", "concept"),
            listOf("map", "chart", "diagram", "mindmap"),
            listOf("bird", "avian", "songbird", "call"),
            listOf("plant", "flora", "tree", "leaf", "flower"),
            listOf("ship", "boat", "vessel", "craft"),
            listOf("radio", "music", "television", "broadcast"),
            listOf("emergency", "siren", "ambulance", "rescue"),
            listOf("person", "human", "people", "speech", "talk"),
        )
    }

    @Synchronized
    fun list(): JSONArray {
        val arr = load()
        val out = JSONArray()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            out.put(
                JSONObject()
                    .put("id", o.optString("id"))
                    .put("title", o.optString("title"))
                    .put("updated", o.optLong("updated"))
                    .put("chars", o.optString("body").length),
            )
        }
        return out
    }

    @Synchronized
    fun get(id: String): JSONObject {
        val arr = load()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") == normId(id)) return o
        }
        return JSONObject().put("ok", false).put("error", "missing")
    }

    @Synchronized
    fun create(title: String): JSONObject {
        val arr = load()
        val next = nextId(arr)
        val now = System.currentTimeMillis()
        val o = JSONObject()
            .put("id", next)
            .put("title", title.trim().ifBlank { "untitled $next" })
            .put("body", "")
            .put("created", now)
            .put("updated", now)
            .put("vec", JSONArray(embed((title)).toList()))
        arr.put(o)
        save(arr)
        return o
    }

    @Synchronized
    fun save(id: String, body: String, title: String? = null): JSONObject {
        val arr = load()
        val nid = normId(id)
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") == nid) {
                if (title != null) o.put("title", title)
                o.put("body", body)
                o.put("updated", System.currentTimeMillis())
                o.put("vec", JSONArray(embed(o.optString("title") + " " + body).toList()))
                save(arr)
                return o.put("ok", true)
            }
        }
        return JSONObject().put("ok", false).put("error", "missing")
    }

    @Synchronized
    fun kill(id: String): Boolean {
        val arr = load()
        val nid = normId(id)
        val keep = JSONArray()
        var found = false
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.optString("id") == nid) found = true else keep.put(o)
        }
        if (found) save(keep)
        return found
    }

    @Synchronized
    fun summarizeLocal(id: String): JSONObject {
        val src = get(id)
        if (!src.optString("id").isNullOrBlank() && src.has("error")) return src
        val body = src.optString("body")
        val title = src.optString("title")
        val sentences = body.split(Regex("(?<=[.!?])\\s+")).map { it.trim() }.filter { it.isNotEmpty() }
        val brief = sentences.take(3).joinToString(" ")
        val newTitle = "summarized: $title"
        val created = create(newTitle)
        return save(created.optString("id"), brief.ifBlank { body.take(400) })
    }

    fun mindmap(keyword: String, minScore: Double = 0.18): JSONArray {
        val q = embed(keyword)
        val arr = load()
        val hits = mutableListOf<Pair<Double, JSONObject>>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val vec = o.optJSONArray("vec")
            val v = if (vec != null && vec.length() > 0) {
                FloatArray(vec.length()) { vec.optDouble(it).toFloat() }
            } else embed(o.optString("title") + " " + o.optString("body"))
            var score = cosine(q, v)
            val blob = (o.optString("title") + " " + o.optString("body")).lowercase()
            if (expand(keyword).any { blob.contains(it) }) score = (score + 0.35).coerceAtMost(1.0)
            if (score >= minScore) {
                hits.add(
                    score to JSONObject()
                        .put("id", o.optString("id"))
                        .put("title", o.optString("title"))
                        .put("score", score)
                        .put("snippet", o.optString("body").take(160)),
                )
            }
        }
        hits.sortByDescending { it.first }
        val out = JSONArray()
        hits.take(16).forEach { out.put(it.second) }
        return out
    }

    fun status(): JSONObject =
        JSONObject()
            .put("ready", file.exists())
            .put("count", load().length())
            .put("embed_model", embedFile.exists() && embedFile.length() > 10_000)
            .put("embed_url", EMBED_URL)

    fun readyEmbed(): Boolean = embedFile.exists() && embedFile.length() > 10_000

    fun downloadEmbed(onProgress: (String) -> Unit): String {
        onProgress("fetching dictation embedder (Universal Sentence Encoder)")
        val tmp = File(embedFile.parentFile, embedFile.name + ".part")
        embedFile.parentFile?.mkdirs()
        val conn = (java.net.URL(EMBED_URL).openConnection() as java.net.HttpURLConnection).apply {
            connectTimeout = 20000
            readTimeout = 120000
            instanceFollowRedirects = true
        }
        conn.inputStream.use { inp ->
            tmp.outputStream().use { out -> inp.copyTo(out) }
        }
        conn.disconnect()
        if (tmp.length() < 10_000) {
            tmp.delete()
            throw IllegalStateException("embedder download too small")
        }
        if (embedFile.exists()) embedFile.delete()
        tmp.renameTo(embedFile)
        onProgress("dictation embedder ready (${embedFile.length() / 1024} KB)")
        return "dictation embedder ready"
    }

    fun embed(text: String): FloatArray {
        val v = FloatArray(128)
        val toks = expand(text)
        if (toks.isEmpty()) return v
        for (t in toks) {
            val h = t.hashCode()
            val i = abs(h) % 128
            v[i] += if (h < 0) -1f else 1f
            val syn = synsetIndex(t)
            if (syn >= 0) {
                val j = syn % 128
                v[j] += 2.2f
            }
        }
        var n = 0.0
        for (x in v) n += x * x
        val s = sqrt(n).toFloat().coerceAtLeast(1e-6f)
        for (i in v.indices) v[i] /= s
        return v
    }

    private fun synsetIndex(token: String): Int {
        SYNSETS.forEachIndexed { idx, set -> if (set.contains(token)) return idx }
        return -1
    }

    private fun expand(text: String): List<String> {
        val raw = text.lowercase().replace(Regex("[^a-z0-9\\s]"), " ").split(Regex("\\s+")).filter { it.length > 1 }
        val out = mutableListOf<String>()
        for (t in raw) {
            out.add(t)
            SYNSETS.firstOrNull { it.contains(t) }?.let { out.addAll(it) }
        }
        return out
    }

    private fun cosine(a: FloatArray, b: FloatArray): Double {
        val n = minOf(a.size, b.size)
        var dot = 0.0
        var na = 0.0
        var nb = 0.0
        for (i in 0 until n) {
            dot += a[i] * b[i]
            na += a[i] * a[i]
            nb += b[i] * b[i]
        }
        val d = sqrt(na) * sqrt(nb)
        return if (d < 1e-9) 0.0 else dot / d
    }

    private fun load(): JSONArray {
        if (!file.exists()) return JSONArray()
        return try {
            JSONArray(file.readText())
        } catch (_: Exception) {
            JSONArray()
        }
    }

    private fun save(arr: JSONArray) {
        file.writeText(arr.toString())
    }

    private fun nextId(arr: JSONArray): String {
        var max = 0
        for (i in 0 until arr.length()) {
            max = maxOf(max, arr.getJSONObject(i).optString("id").toIntOrNull() ?: 0)
        }
        return "%04d".format(max + 1)
    }

    private fun normId(id: String): String {
        val n = id.filter { it.isDigit() }.toIntOrNull() ?: 0
        return "%04d".format(n)
    }
}
