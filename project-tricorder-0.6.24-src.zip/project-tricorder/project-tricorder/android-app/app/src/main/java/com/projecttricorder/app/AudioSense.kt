package com.projecttricorder.app

import android.content.Context
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import org.json.JSONArray
import org.json.JSONObject
import org.tensorflow.lite.support.audio.TensorAudio
import org.tensorflow.lite.task.audio.classifier.AudioClassifier
import org.tensorflow.lite.task.core.BaseOptions
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/**
 * In-APK YAMNet via TFLite Task Audio. No Termux process.
 * Duty cycle: listen [dwellMs], classify 1s windows, sleep [intervalMs].
 */
class AudioSense(private val context: Context) {

    @Volatile var dwellMs: Long = 5000
    @Volatile var intervalMs: Long = 15000

    private val running = AtomicBoolean(false)
    @Volatile var lastPcm: ShortArray? = null
    @Volatile var holdForVoice = false
    private var thread: Thread? = null
    private var classifier: AudioClassifier? = null

    fun start(onResult: (String) -> Unit) {
        if (!running.compareAndSet(false, true)) return
        thread = Thread({
            try {
                loop(onResult)
            } catch (t: Throwable) {
                onResult(errorJson(t.message ?: "audio sense failed"))
            } finally {
                running.set(false)
            }
        }, "yamnet-sense").also { it.start() }
    }

    fun stop() {
        running.set(false)
        thread?.interrupt()
        thread = null
        try { classifier?.close() } catch (_: Exception) {}
        classifier = null
    }

    private fun loop(onResult: (String) -> Unit) {
        val base = BaseOptions.builder().setNumThreads(2).build()
        val options = AudioClassifier.AudioClassifierOptions.builder()
            .setBaseOptions(base)
            .setMaxResults(8)
            .setScoreThreshold(0.08f)
            .build()
        val clf = try {
            AudioClassifier.createFromFileAndOptions(context, "models/yamnet.tflite", options)
        } catch (t: Throwable) {
            AudioClassifier.createFromFile(context, "models/yamnet.tflite")
        }
        classifier = clf
        val format = clf.requiredTensorAudioFormat
        val sampleRate = format.sampleRate
        val channels = max(1, format.channels)
        val minBuf = AudioRecord.getMinBufferSize(
            sampleRate,
            if (channels >= 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
        )
        val recorder = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            sampleRate,
            if (channels >= 2) AudioFormat.CHANNEL_IN_STEREO else AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            max(minBuf, sampleRate * 2),
        )
        if (recorder.state != AudioRecord.STATE_INITIALIZED) {
            onResult(errorJson("mic failed to init"))
            return
        }
        val tensor = clf.createInputTensorAudio()
        recorder.startRecording()
        try {
            while (running.get()) {
                while (running.get() && holdForVoice) {
                    try { Thread.sleep(200) } catch (_: InterruptedException) { break }
                }
                if (!running.get()) break
                val listenMs = dwellMs.coerceIn(1000, 20000)
                val sleepMs = intervalMs.coerceIn(1000, 120000)
                val window = max(sampleRate, tensor.tensorBuffer.flatSize / max(1, channels))
                val needed = (listenMs / 1000.0 * sampleRate).toInt().coerceAtLeast(window)
                val pcm = ShortArray(needed)
                var filled = 0
                val t0 = System.currentTimeMillis()
                var aborted = false
                while (running.get() && filled < needed && System.currentTimeMillis() - t0 < listenMs + 1500) {
                    if (holdForVoice) { aborted = true; break }
                    val n = recorder.read(pcm, filled, needed - filled)
                    if (n > 0) filled += n
                }
                if (!running.get()) break
                if (aborted || holdForVoice) continue
                if (holdForVoice) {
                    lastPcm = null
                    continue
                }
                lastPcm = null
                val scores = HashMap<String, Float>()
                var hops = 0
                var offset = 0
                while (offset + window <= filled) {
                    val slice = pcm.copyOfRange(offset, offset + window)
                    val floats = FloatArray(slice.size) { i -> slice[i] / 32768f }
                    tensor.load(floats)
                    val recs = clf.classify(tensor)
                    for (c in recs) {
                        for (cat in c.categories) {
                            val name = cat.label ?: continue
                            val s = cat.score
                            scores[name] = max(scores[name] ?: 0f, s)
                        }
                    }
                    hops += 1
                    offset += window / 2
                }
                val wave = envelope(pcm, filled, 80)
                onResult(resultJson(scores, wave, hops, listenMs, sampleRate))
                val until = System.currentTimeMillis() + sleepMs
                while (running.get() && System.currentTimeMillis() < until) {
                    try { Thread.sleep(200) } catch (_: InterruptedException) { break }
                }
            }
        } finally {
            try { recorder.stop() } catch (_: Exception) {}
            try { recorder.release() } catch (_: Exception) {}
        }
    }

    private fun envelope(pcm: ShortArray, n: Int, bins: Int): FloatArray {
        val out = FloatArray(bins)
        if (n <= 0) return out
        val step = max(1, n / bins)
        for (i in 0 until bins) {
            val start = i * step
            val end = min(n, start + step)
            var peak = 0
            for (j in start until end) peak = max(peak, abs(pcm[j].toInt()))
            out[i] = peak / 32768f
        }
        return out
    }

    private fun resultJson(
        scores: Map<String, Float>,
        wave: FloatArray,
        hops: Int,
        dwell: Long,
        sr: Int,
    ): String {
        val ranked = scores.entries.sortedByDescending { it.value }.take(16)
        val labels = JSONArray()
        for (e in ranked) {
            labels.put(JSONObject().put("label", e.key).put("score", e.value.toDouble()))
        }
        val w = JSONArray()
        for (v in wave) w.put(v.toDouble())
        return JSONObject()
            .put("ok", true)
            .put("labels", labels)
            .put("wave", w)
            .put("hops", hops)
            .put("dwell_ms", dwell)
            .put("sample_rate", sr)
            .put("t_utc", System.currentTimeMillis())
            .toString()
    }

    private fun errorJson(msg: String) =
        JSONObject().put("ok", false).put("error", msg).toString()
}
