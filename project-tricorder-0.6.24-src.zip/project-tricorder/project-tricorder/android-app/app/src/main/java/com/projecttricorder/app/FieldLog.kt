package com.projecttricorder.app

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

/**
 * Unified tricorder book: JSONL + JPEG snaps in app storage.
 */
class FieldLog(private val context: Context) {

    private val dir: File
        get() = File(context.filesDir, "logs").also { it.mkdirs() }
    private val snapDir: File
        get() = File(dir, "snaps").also { it.mkdirs() }
    private val videoDir: File
        get() = File(dir, "video").also { it.mkdirs() }
    private val file: File get() = File(dir, "field.jsonl")

    fun append(
        kind: String,
        text: String,
        imageDataUrl: String? = null,
        extra: JSONObject = JSONObject(),
    ): JSONObject {
        val now = System.currentTimeMillis()
        val id = UUID.randomUUID().toString().take(8)
        var snapName: String? = null
        if (!imageDataUrl.isNullOrBlank() && imageDataUrl.contains("base64")) {
            try {
                val b64 = imageDataUrl.substringAfter(',')
                val bytes = Base64.decode(b64, Base64.DEFAULT)
                if (bytes.size > 200) {
                    snapName = "$id.jpg"
                    File(snapDir, snapName).writeBytes(bytes)
                }
            } catch (_: Exception) { }
        }
        val loc = lastFix()
        val row = JSONObject()
            .put("id", id)
            .put("kind", kind)
            .put("text", text.take(2000))
            .put("t_utc", iso(now))
            .put("t_local", local(now))
            .put("t_ms", now)
            .put("src", android.os.Build.MODEL)
        if (snapName != null) row.put("snap", snapName)
        extra.keys().forEach { row.put(it, extra.get(it)) }
        if (loc != null) {
            row.put("lat", loc.latitude)
            row.put("lon", loc.longitude)
            row.put("acc_m", loc.accuracy.toDouble())
        }
        file.appendText(row.toString() + "\n")
        return row
    }

    fun markVideo(path: String, ms: Long): JSONObject {
        return append("video", "Video log ${File(path).name}", extra = JSONObject()
            .put("video", File(path).name)
            .put("duration_ms", ms))
    }

    fun videoDir(): File = videoDir

    fun count(): Int = if (file.exists()) file.readLines().count { it.isNotBlank() } else 0

    fun summary(): JSONArray {
        val out = JSONArray()
        if (!file.exists()) return out
        file.readLines().forEach { line ->
            if (line.isBlank()) return@forEach
            try {
                val o = JSONObject(line)
                out.put(JSONObject()
                    .put("id", o.optString("id"))
                    .put("kind", o.optString("kind"))
                    .put("t_local", o.optString("t_local"))
                    .put("t_utc", o.optString("t_utc"))
                    .put("t_ms", o.optLong("t_ms"))
                    .put("text", o.optString("text").take(200))
                    .put("has_snap", o.has("snap"))
                    .put("has_video", o.has("video")))
            } catch (_: Exception) { }
        }
        return out
    }

    fun get(index: Int): JSONObject {
        if (!file.exists()) return JSONObject().put("ok", false).put("error", "empty log")
        val lines = file.readLines().filter { it.isNotBlank() }
        if (lines.isEmpty()) return JSONObject().put("ok", false).put("error", "empty log")
        val i = index.coerceIn(0, lines.lastIndex)
        val row = JSONObject(lines[i])
        row.put("ok", true)
        row.put("index", i)
        row.put("total", lines.size)
        val snap = row.optString("snap")
        if (snap.isNotBlank()) {
            val f = File(snapDir, snap)
            if (f.exists() && f.length() < 350_000) {
                val b64 = Base64.encodeToString(f.readBytes(), Base64.NO_WRAP)
                row.put("image", "data:image/jpeg;base64,$b64")
            }
        }
        val vid = row.optString("video")
        if (vid.isNotBlank()) {
            val f = File(videoDir, vid)
            if (f.exists()) {
                row.put("has_video", true)
                row.put("video_path", f.absolutePath)
                row.put("video_kb", f.length() / 1024)
            }
        }
        return row
    }

    fun path(): String = file.absolutePath

    private fun lastFix(): Location? {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null } }
                .maxByOrNull { it.time }
        } catch (_: Exception) { null }
    }

    private fun iso(ms: Long): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        return fmt.format(Date(ms))
    }

    private fun local(ms: Long): String {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return fmt.format(Date(ms))
    }
}
