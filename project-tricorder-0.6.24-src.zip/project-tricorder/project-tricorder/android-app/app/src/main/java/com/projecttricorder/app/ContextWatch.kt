package com.projecttricorder.app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class ContextWatch(private val context: Context) {
    private val exec = Executors.newSingleThreadScheduledExecutor()
    private var weatherJob: ScheduledFuture<*>? = null
    private var flightJob: ScheduledFuture<*>? = null
    private var citizenJob: ScheduledFuture<*>? = null
    private val seen = HashSet<String>()
    @Volatile private var flags: Set<String> = emptySet()
    @Volatile private var running = false

    fun start(enabled: Set<String>, onAlert: (JSONObject) -> Unit) {
        stop()
        flags = enabled
        running = true
        if ("weather_alerts_noaa" in flags) {
            weatherJob = exec.scheduleWithFixedDelay({ safe { pollWeather(onAlert) } }, 2, 180, TimeUnit.SECONDS)
        }
        if ("flight_overhead" in flags) {
            flightJob = exec.scheduleWithFixedDelay({ safe { pollFlights(onAlert) } }, 4, 45, TimeUnit.SECONDS)
        }
        if ("crime_safety_citizen" in flags) {
            citizenJob = exec.scheduleWithFixedDelay({ safe { pollCitizen(onAlert) } }, 6, 120, TimeUnit.SECONDS)
        }
        if ("traffic_waze" in flags) {
            onAlert(
                JSONObject()
                    .put("kind", "context")
                    .put("source", "notice")
                    .put("text", "Waze has no public keyless feed — not polled."),
            )
        }
    }

    fun stop() {
        running = false
        weatherJob?.cancel(false); weatherJob = null
        flightJob?.cancel(false); flightJob = null
        citizenJob?.cancel(false); citizenJob = null
    }

    private fun safe(block: () -> Unit) {
        try { if (running) block() } catch (_: Exception) {}
    }

    @SuppressLint("MissingPermission")
    private fun lastFix(): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val gps = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Exception) { null }
        val net = try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { null }
        return when {
            gps != null && net != null -> if (gps.time >= net.time) gps else net
            else -> gps ?: net
        }
    }

    private fun pollWeather(onAlert: (JSONObject) -> Unit) {
        val loc = lastFix() ?: return
        val url = "https://api.weather.gov/alerts/active?point=${loc.latitude},${loc.longitude}"
        val body = httpGet(url, "ProjectTricorder/0.5.4 (field instrument; nws.alerts)") ?: return
        val features = JSONObject(body).optJSONArray("features") ?: return
        for (i in 0 until features.length()) {
            val f = features.optJSONObject(i) ?: continue
            val id = f.optString("id", "w$i")
            val p = f.optJSONObject("properties") ?: continue
            val sev = p.optString("severity")
            if (sev !in setOf("Severe", "Extreme", "Moderate")) continue
            if (!seen.add("wx:$id")) continue
            val event = p.optString("event", "Weather")
            val headline = p.optString("headline", event)
            val area = p.optString("areaDesc", "")
            val details = listOf(headline, area).filter { it.isNotBlank() }.joinToString(" — ")
            onAlert(
                JSONObject()
                    .put("kind", "context")
                    .put("source", "weather")
                    .put("event", event)
                    .put("severity", sev)
                    .put("text", details)
                    .put("hhmm", nowHhmm()),
            )
        }
    }

    private val routeCache = HashMap<String, String>()

    private fun pollFlights(onAlert: (JSONObject) -> Unit) {
        val loc = lastFix() ?: return
        val d = 0.25 // ~25 km box
        val url =
            "https://opensky-network.org/api/states/all?lamin=${loc.latitude - d}&lomin=${loc.longitude - d}" +
                "&lamax=${loc.latitude + d}&lomax=${loc.longitude + d}"
        val body = httpGet(url, "ProjectTricorder/0.6.21") ?: return
        val states = JSONObject(body).optJSONArray("states") ?: return
        var n = 0
        val bits = ArrayList<String>()
        for (i in 0 until states.length()) {
            val row = states.optJSONArray(i) ?: continue
            val grounded = row.optBoolean(8, false)
            if (grounded) continue
            val icao = row.optString(0, "").trim()
            val call = row.optString(1, "").trim().ifBlank { "aircraft" }
            val alt = row.optDouble(7, Double.NaN)
            val vel = row.optDouble(9, Double.NaN)
            val key = "ac:${icao.ifBlank { call }}"
            if (!seen.add(key)) continue
            n += 1
            val altS = if (alt.isFinite()) "${alt.toInt()} m" else "?"
            val velS = if (vel.isFinite()) "${vel.toInt()} m/s" else ""
            val route = routePhrase(icao, call)
            bits.add("$call $altS $velS$route".trim())
            if (n >= 4) break
        }
        if (bits.isEmpty()) return
        onAlert(
            JSONObject()
                .put("kind", "context")
                .put("source", "flight")
                .put("event", "overhead")
                .put("text", bits.joinToString("; "))
                .put("hhmm", nowHhmm()),
        )
    }

    private fun routePhrase(icao: String, call: String): String {
        val key = icao.lowercase().ifBlank { call.uppercase() }
        routeCache[key]?.let { return it }
        val phrase = lookupAdsbdb(call) ?: lookupOpenSkyRoute(icao) ?: ""
        routeCache[key] = phrase
        return phrase
    }

    private fun airportLabel(obj: JSONObject?): String {
        if (obj == null) return ""
        val city = obj.optString("municipality").ifBlank { obj.optString("name") }
        val iata = obj.optString("iata_code").ifBlank { obj.optString("iata") }
        val icao = obj.optString("icao_code").ifBlank { obj.optString("icao") }
        return when {
            city.isNotBlank() && iata.isNotBlank() -> "$city $iata"
            city.isNotBlank() -> city
            iata.isNotBlank() -> iata
            icao.isNotBlank() -> icao
            else -> ""
        }
    }

    private fun lookupAdsbdb(call: String): String? {
        val cs = call.replace(" ", "").uppercase()
        if (cs.isBlank() || cs == "AIRCRAFT") return null
        val body = httpGet("https://api.adsbdb.com/v0/callsign/$cs", "ProjectTricorder/0.6.21") ?: return null
        val fr = JSONObject(body).optJSONObject("response")?.optJSONObject("flightroute") ?: return null
        val dep = airportLabel(fr.optJSONObject("origin") ?: fr.optJSONObject("departure"))
        val arr = airportLabel(fr.optJSONObject("destination") ?: fr.optJSONObject("arrival"))
        if (dep.isBlank() && arr.isBlank()) return null
        return buildString {
            if (dep.isNotBlank()) append(" from ").append(dep)
            if (arr.isNotBlank()) append(" to ").append(arr)
        }
    }

    private fun lookupOpenSkyRoute(icao: String): String? {
        if (icao.isBlank()) return null
        val end = System.currentTimeMillis() / 1000
        val begin = end - 16 * 3600
        val body = httpGet(
            "https://opensky-network.org/api/flights/aircraft?icao24=${icao.lowercase()}&begin=$begin&end=$end",
            "ProjectTricorder/0.6.21",
        ) ?: return null
        val arr = try { JSONArray(body) } catch (_: Exception) { return null }
        if (arr.length() == 0) return null
        val last = arr.optJSONObject(arr.length() - 1) ?: return null
        val dep = last.optString("estDepartureAirport", "")
        val dest = last.optString("estArrivalAirport", "")
        if (dep.isBlank() && dest.isBlank()) return null
        return buildString {
            if (dep.isNotBlank()) append(" from ").append(dep)
            if (dest.isNotBlank()) append(" to ").append(dest)
        }
    }

    private val civicEvents = setOf(
        "civil emergency message", "civil danger warning", "law enforcement warning",
        "child abduction emergency", "amber alert", "911 telephone outage emergency",
        "shelter in place warning", "evacuation immediate", "fire warning",
        "hazardous materials warning", "nuclear power plant warning",
        "radiological hazard warning", "emergency action notification",
        "local area emergency", "administrative message",
    )

    private fun pollCitizen(onAlert: (JSONObject) -> Unit) {
        val loc = lastFix() ?: return
        // Public-safety CAP via NWS (IPAWS) — Citizen Inc. has no public API.
        val nws = httpGet(
            "https://api.weather.gov/alerts/active?point=${loc.latitude},${loc.longitude}",
            "ProjectTricorder/0.6.0 (field instrument; civic.alerts)",
        )
        if (nws != null) {
            val features = JSONObject(nws).optJSONArray("features") ?: JSONArray()
            for (i in 0 until features.length()) {
                val f = features.optJSONObject(i) ?: continue
                val id = f.optString("id", "c$i")
                val p = f.optJSONObject("properties") ?: continue
                val event = p.optString("event", "")
                val evl = event.lowercase()
                val civic = civicEvents.any { evl.contains(it) } ||
                    p.optString("category").equals("Safety", true) ||
                    p.optString("category").equals("Security", true) ||
                    evl.contains("amber") || evl.contains("civil")
                if (!civic) continue
                if (!seen.add("cz:$id")) continue
                val headline = p.optString("headline", event)
                val area = p.optString("areaDesc", "")
                onAlert(
                    JSONObject()
                        .put("kind", "context")
                        .put("source", "citizen")
                        .put("event", event)
                        .put("text", listOf(headline, area).filter { it.isNotBlank() }.joinToString(" — "))
                        .put("hhmm", nowHhmm()),
                )
            }
        }
        val quake = httpGet(
            "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson" +
                "&latitude=${loc.latitude}&longitude=${loc.longitude}&maxradiuskm=200&minmagnitude=3.5&limit=5&orderby=time",
            "ProjectTricorder/0.6.0",
        )
        if (quake != null) {
            val feats = JSONObject(quake).optJSONArray("features") ?: JSONArray()
            for (i in 0 until feats.length()) {
                val f = feats.optJSONObject(i) ?: continue
                val id = f.optString("id", "q$i")
                if (!seen.add("eq:$id")) continue
                val p = f.optJSONObject("properties") ?: continue
                val mag = p.optDouble("mag", Double.NaN)
                val place = p.optString("place", "quake")
                if (!mag.isFinite() || mag < 3.5) continue
                onAlert(
                    JSONObject()
                        .put("kind", "context")
                        .put("source", "citizen")
                        .put("event", "earthquake")
                        .put("text", "Magnitude ${"%.1f".format(mag)} earthquake — $place")
                        .put("hhmm", nowHhmm()),
                )
            }
        }
    }

    private fun nowHhmm(): String {
        val c = java.util.Calendar.getInstance()
        return "%02d:%02d".format(c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE))
    }

    private fun httpGet(url: String, userAgent: String): String? {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        return try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", userAgent)
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }
}
