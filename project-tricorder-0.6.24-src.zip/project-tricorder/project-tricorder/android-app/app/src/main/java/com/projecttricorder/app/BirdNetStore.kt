package com.projecttricorder.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import org.tensorflow.lite.Interpreter
import java.io.File
import java.io.FileInputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.MappedByteBuffer
import java.nio.channels.FileChannel
import kotlin.math.max

/**
 * Optional BirdNET v2.4 FP16. Downloaded on demand — not baked into the APK.
 * 3 s @ 48 kHz. Only invoked when YAMNet already said "Bird".
 */
class BirdNetStore(private val context: Context) {

    private val dir: File get() = File(context.filesDir, "models").also { it.mkdirs() }
    val modelFile: File get() = File(dir, "BirdNET_GLOBAL_6K_V2.4_Model_FP16.tflite")
    val labelFile: File get() = File(dir, "BirdNET_GLOBAL_6K_V2.4_Labels.txt")

    fun ready(): Boolean = modelFile.exists() && modelFile.length() > 1_000_000 &&
        labelFile.exists() && labelFile.length() > 1000

    fun status(): JSONObject = JSONObject()
        .put("ready", ready())
        .put("model_bytes", if (modelFile.exists()) modelFile.length() else 0)
        .put("labels", if (labelFile.exists()) labelFile.readLines().size else 0)

    fun download(onProgress: (String) -> Unit = {}): String {
        val modelUrl = "https://raw.githubusercontent.com/woheller69/whoBIRD-TFlite/master/BirdNET_GLOBAL_6K_V2.4_Model_FP16.tflite"
        val labelUrl = "https://raw.githubusercontent.com/acenet-arc/birdnet/main/BirdNET_GLOBAL_6K_V2.4_Labels.txt"
        onProgress("fetching labels")
        try { pull(labelUrl, labelFile) } catch (t: Throwable) {
            pull("https://huggingface.co/tphakala/BirdNET-v2.4/resolve/main/labels.txt?download=true", labelFile)
        }
        onProgress("fetching BirdNET model (~25MB)")
        try { pull(modelUrl, modelFile) } catch (t: Throwable) {
            pull("https://cdn.jsdelivr.net/gh/woheller69/whoBIRD-TFlite@master/BirdNET_GLOBAL_6K_V2.4_Model_FP16.tflite", modelFile)
        }
        return if (ready()) "BirdNET ready" else "download incomplete"
    }

    fun classifyPcm16k(pcm: ShortArray, topN: Int = 3): JSONArray {
        val out = JSONArray()
        if (!ready() || pcm.isEmpty()) return out
        val labels = labelFile.readLines()
        val interp = Interpreter(loadModel(modelFile), Interpreter.Options().setNumThreads(2))
        try {
            val inputSize = 144000 // 3s * 48k
            val x = resample16to48(pcm, inputSize)
            val input = Array(1) { x }
            val scores = Array(1) { FloatArray(labels.size.coerceAtLeast(1)) }
            interp.run(input, scores)
            val ranked = scores[0].mapIndexed { i, v -> i to v }
                .sortedByDescending { it.second }
                .take(topN)
            for ((i, v) in ranked) {
                if (v < 0.15f) continue
                val raw = labels.getOrNull(i) ?: continue
                val parts = raw.split("_", limit = 2)
                val obj = JSONObject().put("score", v.toDouble()).put("raw", raw)
                if (parts.size == 2) {
                    obj.put("sci", parts[0]).put("en", parts[1])
                } else {
                    obj.put("en", raw)
                }
                out.put(obj)
            }
        } catch (_: Exception) {
            // leave empty — YAMNet row still stands
        } finally {
            interp.close()
        }
        return out
    }

    private fun resample16to48(pcm: ShortArray, outLen: Int): FloatArray {
        val src = if (pcm.size > 16000 * 3) pcm.copyOfRange(pcm.size - 16000 * 3, pcm.size) else pcm
        val up = FloatArray(src.size * 3)
        for (i in src.indices) {
            val v = src[i] / 32768f
            val j = i * 3
            if (j < up.size) up[j] = v
            if (j + 1 < up.size) up[j + 1] = v
            if (j + 2 < up.size) up[j + 2] = v
        }
        val out = FloatArray(outLen)
        val n = minOf(outLen, up.size)
        System.arraycopy(up, max(0, up.size - n), out, outLen - n, n)
        return out
    }

    private fun loadModel(f: File): MappedByteBuffer {
        FileInputStream(f).use { fis ->
            val ch = fis.channel
            return ch.map(FileChannel.MapMode.READ_ONLY, 0, ch.size())
        }
    }

    private fun pull(url: String, dest: File) {
        val tmp = File(dest.absolutePath + ".part")
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 120000
        conn.instanceFollowRedirects = true
        conn.connect()
        if (conn.responseCode >= 400) throw IllegalStateException("HTTP ${conn.responseCode} $url")
        conn.inputStream.use { input ->
            tmp.outputStream().use { output -> input.copyTo(output) }
        }
        tmp.renameTo(dest)
    }
}
