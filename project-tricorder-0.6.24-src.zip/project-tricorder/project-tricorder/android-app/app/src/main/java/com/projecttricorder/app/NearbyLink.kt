package com.projecttricorder.app

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONObject

/**
 * Opt-in camp link. Payload is a JSON log row, not a raw wav stream.
 */
class NearbyLink(
    private val context: Context,
    private val onIncoming: (String) -> Unit,
    private val onStatus: (String) -> Unit,
) {
    private val client = Nearby.getConnectionsClient(context)
    private val connected = HashSet<String>()
    @Volatile var running = false
        private set

    fun start(name: String) {
        stop()
        running = true
        val optsAdv = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        val optsDisc = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_STAR).build()
        client.startAdvertising(name, SERVICE, lifecycle, optsAdv)
            .addOnSuccessListener { onStatus("advertising") }
            .addOnFailureListener { onStatus("adv fail ${it.message}") }
        client.startDiscovery(SERVICE, discovery, optsDisc)
            .addOnSuccessListener { onStatus("discovering") }
            .addOnFailureListener { onStatus("disc fail ${it.message}") }
    }

    fun stop() {
        running = false
        try { client.stopAdvertising() } catch (_: Exception) {}
        try { client.stopDiscovery() } catch (_: Exception) {}
        try { client.stopAllEndpoints() } catch (_: Exception) {}
        connected.clear()
        onStatus("link off")
    }

    fun send(row: JSONObject) {
        if (connected.isEmpty()) return
        val payload = Payload.fromBytes(row.toString().toByteArray(Charsets.UTF_8))
        connected.forEach { id ->
            client.sendPayload(id, payload)
        }
    }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            client.acceptConnection(endpointId, payloadCb)
        }
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            if (result.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                connected.add(endpointId)
                onStatus("linked $endpointId")
            }
        }
        override fun onDisconnected(endpointId: String) {
            connected.remove(endpointId)
            onStatus("dropped $endpointId")
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            client.requestConnection(android.os.Build.MODEL, endpointId, lifecycle)
        }
        override fun onEndpointLost(endpointId: String) {}
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            onIncoming(String(bytes, Charsets.UTF_8))
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    companion object {
        const val SERVICE = "com.projecttricorder.hits"
    }
}
