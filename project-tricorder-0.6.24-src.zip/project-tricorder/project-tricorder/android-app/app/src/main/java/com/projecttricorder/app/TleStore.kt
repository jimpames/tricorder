package com.projecttricorder.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * Celestrak TLE packs fetched on earth-link init.
 * Starlink mega-catalog is opt-in (thousands of rows).
 */
class TleStore(private val context: Context) {

    data class Pack(val id: String, val label: String, val group: String, val defaultOn: Boolean)

    val packs = listOf(
        Pack("stations", "Stations / ISS", "stations", true),
        Pack("amateur", "Amateur Part 97", "amateur", true),
        Pack("iridium", "Iridium NEXT", "iridium-NEXT", true),
        Pack("globalstar", "Globalstar", "globalstar", true),
        Pack("orbcomm", "Orbcomm", "orbcomm", false),
        Pack("geo", "GEO / Inmarsat-class", "geo", false),
        Pack("gps", "GPS ops", "gps-ops", false),
        Pack("visual", "100 brightest", "visual", false),
    )

    private val dir: File get() = File(context.filesDir, "tle").also { it.mkdirs() }

    fun fileFor(id: String) = File(dir, "$id.tle")

    fun ready(id: String): Boolean = fileFor(id).let { it.exists() && it.length() > 80 }

    fun status(): JSONObject {
        val arr = JSONArray()
        var n = 0
        for (p in packs) {
            val f = fileFor(p.id)
            val bytes = if (f.exists()) f.length() else 0
            if (bytes > 80) n++
            arr.put(
                JSONObject()
                    .put("id", p.id)
                    .put("label", p.label)
                    .put("ready", bytes > 80)
                    .put("bytes", bytes)
                    .put("default_on", p.defaultOn),
            )
        }
        return JSONObject().put("ready", n > 0).put("packs_ready", n).put("packs", arr)
    }

    fun text(id: String): String {
        val f = fileFor(id)
        return if (f.exists()) f.readText() else ""
    }

    fun download(onNote: (String) -> Unit): String {
        var ok = 0
        for (p in packs) {
            onNote("TLE ${p.label}")
            val url = "https://celestrak.org/NORAD/elements/gp.php?GROUP=${p.group}&FORMAT=tle"
            try {
                pull(url, fileFor(p.id))
                if (ready(p.id)) ok++
            } catch (t: Throwable) {
                try {
                    pull(
                        "https://raw.githubusercontent.com/satvisorcom/satvisor-data/master/celestrak/tle/${p.group}.tle",
                        fileFor(p.id),
                    )
                    if (ready(p.id)) ok++
                } catch (_: Throwable) {
                    onNote("TLE ${p.id} fail")
                }
            }
        }
        return "TLE packs $ok/${packs.size} on device"
    }

    private fun pull(url: String, dest: File) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 20000
            conn.readTimeout = 40000
            conn.setRequestProperty("User-Agent", "ProjectTricorder/0.6.4 (field instrument; tle.fetch)")
            conn.setRequestProperty("Accept", "text/plain")
            if (conn.responseCode !in 200..299) throw RuntimeException("HTTP ${conn.responseCode}")
            val bytes = conn.inputStream.use { it.readBytes() }
            if (bytes.size < 80) throw RuntimeException("short TLE")
            dest.writeBytes(bytes)
        } finally {
            conn.disconnect()
        }
    }
}
