package com.projecttricorder.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL

/**
 * NOAA SWPC + HamQSL + NWS snapshot at earth-link init.
 */
class SolStore(private val context: Context) {

    private val dir: File get() = File(context.filesDir, "sol").also { it.mkdirs() }
    private val snapFile get() = File(dir, "snapshot.json")

    fun ready(): Boolean = snapFile.exists() && snapFile.length() > 40

    fun snapshot(): String = if (snapFile.exists()) snapFile.readText() else "{}"

    fun download(lat: Double?, lon: Double?, onNote: (String) -> Unit): String {
        onNote("SOL weather from NOAA SWPC")
        val scales = getJson("https://services.swpc.noaa.gov/json/noaa_scales.json")
            ?: getJson("https://services.swpc.noaa.gov/products/noaa-scales.json")
        val kp = getJsonArr("https://services.swpc.noaa.gov/json/planetary_k_index_1m.json")
        val xray = getJsonArr("https://services.swpc.noaa.gov/json/goes/primary/xrays-6-hour.json")
        val cycle = getJsonArr("https://services.swpc.noaa.gov/json/solar-cycle/observed-solar-cycle-indices.json")
        val forecast3 = getText("https://services.swpc.noaa.gov/text/3-day-forecast.txt")
        val drap = getText("https://services.swpc.noaa.gov/text/drap_global_frequencies.txt")
        onNote("SOL ham bands from HamQSL")
        val hamXml = getText("https://www.hamqsl.com/solarxml.php")
        var earth: JSONObject? = null
        if (lat != null && lon != null && lat.isFinite() && lon.isFinite()) {
            onNote("EARTH weather from NWS")
            earth = fetchNws(lat, lon)
        }
        val out = JSONObject()
            .put("at", System.currentTimeMillis())
            .put("source", "NOAA SWPC + HamQSL + NWS")
            .put("scales", scales ?: JSONObject.NULL)
            .put("kp_latest", lastObj(kp))
            .put("xray_latest", lastObj(xray))
            .put("cycle_latest", lastObj(cycle))
            .put("forecast3", forecast3?.take(1200) ?: JSONObject.NULL)
            .put("drap", drap?.take(800) ?: JSONObject.NULL)
            .put("ham", parseHam(hamXml))
            .put("earth", earth ?: JSONObject.NULL)
            .put("lat", lat ?: JSONObject.NULL)
            .put("lon", lon ?: JSONObject.NULL)
        snapFile.writeText(out.toString())
        return "SOL snapshot stored"
    }

    private fun lastObj(arr: JSONArray?): JSONObject? {
        if (arr == null || arr.length() == 0) return null
        val v = arr.opt(arr.length() - 1)
        return v as? JSONObject
    }

    private fun parseHam(xml: String?): JSONObject {
        val o = JSONObject()
        if (xml.isNullOrBlank()) return o
        fun tag(name: String): String {
            val re = Regex("<$name[^>]*>([^<]*)</$name>", RegexOption.IGNORE_CASE)
            return re.find(xml)?.groupValues?.getOrNull(1)?.trim().orEmpty()
        }
        o.put("solarflux", tag("solarflux"))
        o.put("aindex", tag("aindex"))
        o.put("kindex", tag("kindex"))
        o.put("xray", tag("xray"))
        o.put("sunspots", tag("sunspots"))
        o.put("heliumline", tag("heliumline"))
        o.put("protonflux", tag("protonflux"))
        o.put("electonflux", tag("electonflux").ifBlank { tag("electronflux") })
        o.put("aurora", tag("aurora"))
        o.put("normalization", tag("normalization"))
        o.put("latdegree", tag("latdegree"))
        o.put("solarwind", tag("solarwind"))
        o.put("magneticfield", tag("magneticfield"))
        o.put("calculatedconditions", tag("calculatedconditions"))
        val bands = JSONObject()
        Regex("<band\\s+name=\"([^\"]+)\"\\s+time=\"([^\"]+)\"[^>]*>([^<]*)</band>", RegexOption.IGNORE_CASE)
            .findAll(xml)
            .forEach { m ->
                val name = m.groupValues[1].trim()
                val time = m.groupValues[2].lowercase()
                val cond = m.groupValues[3].trim()
                bands.put(name + "_" + time, cond)
                name.split('-').forEach { part ->
                    bands.put(part + "_" + time, cond)
                }
            }
        o.put("bands", bands)
        val vhf = JSONObject()
        Regex("<phenomenon\\s+name=\"([^\"]+)\"\\s+location=\"([^\"]+)\"[^>]*>([^<]*)</phenomenon>", RegexOption.IGNORE_CASE)
            .findAll(xml)
            .forEach { m ->
                vhf.put(m.groupValues[1] + "/" + m.groupValues[2], m.groupValues[3].trim())
            }
        o.put("vhf", vhf)
        o.put("vhfaurora", vhf.optString("vhf-aurora/northern_hemi").ifBlank { tag("vhfaurora") })
        o.put("vhfskip", vhf.optString("E-Skip/north_america").ifBlank { tag("vhfskip") })
        o.put("euhf", "line of sight / local")
        o.put("geomagfield", tag("geomagfield"))
        o.put("signalnoise", tag("signalnoise"))
        o.put("fof2", tag("fof2"))
        o.put("muf", tag("muf"))
        return o
    }

    private fun fetchNws(lat: Double, lon: Double): JSONObject? {
        val points = getJson("https://api.weather.gov/points/${"%.4f".format(lat)},${"%.4f".format(lon)}") ?: return null
        val props = points.optJSONObject("properties") ?: return null
        val hourlyUrl = props.optString("forecastHourly")
        val dailyUrl = props.optString("forecast")
        val hourly = if (hourlyUrl.isNotBlank()) getJson(hourlyUrl) else null
        val daily = if (dailyUrl.isNotBlank()) getJson(dailyUrl) else null
        val hours = JSONArray()
        hourly?.optJSONObject("properties")?.optJSONArray("periods")?.let { arr ->
            for (i in 0 until minOf(24, arr.length())) {
                val p = arr.optJSONObject(i) ?: continue
                hours.put(
                    JSONObject()
                        .put("t", p.optString("startTime"))
                        .put("temp", p.opt("temperature"))
                        .put("unit", p.optString("temperatureUnit"))
                        .put("wind", p.optString("windSpeed") + " " + p.optString("windDirection"))
                        .put("wx", p.optString("shortForecast")),
                )
            }
        }
        val outlook = JSONArray()
        daily?.optJSONObject("properties")?.optJSONArray("periods")?.let { arr ->
            for (i in 0 until minOf(6, arr.length())) {
                val p = arr.optJSONObject(i) ?: continue
                outlook.put(
                    JSONObject()
                        .put("name", p.optString("name"))
                        .put("temp", p.opt("temperature"))
                        .put("wx", p.optString("shortForecast"))
                        .put("detail", p.optString("detailedForecast").take(220)),
                )
            }
        }
        return JSONObject()
            .put("office", props.optString("cwa"))
            .put("city", props.optJSONObject("relativeLocation")?.optJSONObject("properties")?.optString("city"))
            .put("hourly", hours)
            .put("outlook", outlook)
    }

    private fun getJson(url: String): JSONObject? = getText(url)?.let {
        try { JSONObject(it) } catch (_: Exception) { null }
    }

    private fun getJsonArr(url: String): JSONArray? = getText(url)?.let {
        try { JSONArray(it) } catch (_: Exception) { null }
    }

    private fun getText(url: String): String? {
        val conn = URL(url).openConnection() as HttpURLConnection
        return try {
            conn.connectTimeout = 16000
            conn.readTimeout = 20000
            conn.setRequestProperty("User-Agent", "ProjectTricorder/0.6.5 (n2nhu@arrl.net; field instrument)")
            conn.setRequestProperty("Accept", "application/json, application/geo+json, text/xml, text/plain, */*")
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }
}
