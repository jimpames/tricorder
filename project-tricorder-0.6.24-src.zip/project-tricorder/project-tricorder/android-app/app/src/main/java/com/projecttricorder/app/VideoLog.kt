package com.projecttricorder.app

import android.graphics.SurfaceTexture
import android.hardware.Camera
import android.media.MediaRecorder
import java.io.File

@Suppress("DEPRECATION")
class VideoLog(private val fieldLog: FieldLog) {

    private var camera: Camera? = null
    private var recorder: MediaRecorder? = null
    private var file: File? = null
    private var startedAt = 0L
    @Volatile var running = false
        private set

    fun start(): String {
        if (running) return "already recording"
        val out = File(fieldLog.videoDir(), "v-${System.currentTimeMillis()}.mp4")
        val cam = openFront() ?: openAny() ?: throw IllegalStateException("no camera")
        cam.unlock()
        val rec = MediaRecorder()
        try {
            rec.setCamera(cam)
            rec.setAudioSource(MediaRecorder.AudioSource.CAMCORDER)
            rec.setVideoSource(MediaRecorder.VideoSource.CAMERA)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            rec.setVideoEncoder(MediaRecorder.VideoEncoder.H264)
            rec.setVideoSize(640, 480)
            rec.setVideoFrameRate(24)
            rec.setVideoEncodingBitRate(1_200_000)
            rec.setOutputFile(out.absolutePath)
            rec.prepare()
            rec.start()
        } catch (t: Throwable) {
            try { rec.release() } catch (_: Exception) {}
            try { cam.lock(); cam.release() } catch (_: Exception) {}
            throw t
        }
        camera = cam
        recorder = rec
        file = out
        startedAt = System.currentTimeMillis()
        running = true
        return out.name
    }

    fun stop(): String {
        if (!running) return "not recording"
        running = false
        val dur = System.currentTimeMillis() - startedAt
        try { recorder?.stop() } catch (_: Exception) {}
        try { recorder?.release() } catch (_: Exception) {}
        recorder = null
        try { camera?.lock(); camera?.release() } catch (_: Exception) {}
        camera = null
        val f = file
        file = null
        if (f != null && f.exists() && f.length() > 1000) {
            fieldLog.markVideo(f.absolutePath, dur)
            return "saved ${f.name} (${f.length() / 1024}KB)"
        }
        return "recording ended, file empty"
    }

    private fun openFront(): Camera? {
        val info = Camera.CameraInfo()
        for (i in 0 until Camera.getNumberOfCameras()) {
            Camera.getCameraInfo(i, info)
            if (info.facing == Camera.CameraInfo.CAMERA_FACING_FRONT) {
                val c = Camera.open(i)
                try {
                    c.setPreviewTexture(SurfaceTexture(10))
                    c.startPreview()
                } catch (_: Exception) { }
                return c
            }
        }
        return null
    }

    private fun openAny(): Camera? {
        if (Camera.getNumberOfCameras() <= 0) return null
        val c = Camera.open(0)
        try {
            c.setPreviewTexture(SurfaceTexture(10))
            c.startPreview()
        } catch (_: Exception) { }
        return c
    }
}
