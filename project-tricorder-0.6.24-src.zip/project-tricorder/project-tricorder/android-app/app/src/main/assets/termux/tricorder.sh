#!/data/data/com.termux/files/usr/bin/bash
# Project Tricorder Mk I — Termux stack helper
# Copy to ~/bin/tricorder and: chmod +x ~/bin/tricorder
set -e
HOME="${HOME:-/data/data/com.termux/files/home}"
LOG="$HOME/tricorder-logs"
BIN_CHAT="${CHAT:-$HOME/llama.cpp/build/bin/llama-server}"
BIN_SD="${SD:-$HOME/stable-diffusion.cpp/build/bin/sd-server}"
KOKORO="$HOME/kokoro"
mkdir -p "$LOG" "$HOME/bin"
cmd="${1:-status}"

start_one() {
  local name="$1"; shift
  if pgrep -f "$name" >/dev/null 2>&1; then echo "$name already up"; return; fi
  nohup "$@" >"$LOG/$name.log" 2>&1 &
  echo "starting $name pid $! log $LOG/$name.log"
}

case "$cmd" in
  start)
    command -v sshd >/dev/null && sshd || true
    echo "starting sshd on 8022 (if installed)"
    # Edit model paths to match this device.
    # start_one chat "$BIN_CHAT" -m "$HOME/models/gemma-3-4b-it-Q4_K_M.gguf" --host 127.0.0.1 --port 8080
    # start_one vision "$BIN_CHAT" -m "$HOME/models/smolvlm*.gguf" --mmproj "$HOME/models/*mmproj*" --host 127.0.0.1 --port 8081
    # start_one image "$BIN_SD" -m "$HOME/models/*turbo*" --listen-ip 127.0.0.1 --listen-port 8188 --cfg-scale 1 --steps 4
    # start_one tts python3 "$KOKORO/server.py"
    echo "edit $0 with your model paths, then rerun: tricorder start"
    ;;
  stop)
    pkill -f llama-server || true
    pkill -f sd-server || true
    pkill -f 'kokoro' || true
    echo stopped
    ;;
  status)
    echo "chat    :8080"; (command -v curl >/dev/null && curl -sS --max-time 1 http://127.0.0.1:8080/health) || echo down
    echo "vision  :8081"; (command -v curl >/dev/null && curl -sS --max-time 1 http://127.0.0.1:8081/health) || echo down
    echo "image   :8188"; (command -v curl >/dev/null && curl -sS --max-time 1 http://127.0.0.1:8188/) || echo down
    echo "tts     :5000"; (command -v curl >/dev/null && curl -sS --max-time 1 http://127.0.0.1:5000/health) || echo down
    ;;
  *) echo "usage: tricorder start|stop|status" ;;
esac
