/* Project Tricorder Mk I — SATELLITES / STARS live plot
   SGP4 via satellite.js + Celestrak TLEs. Stars: bright-star RA/Dec. */
(function () {
  const STARS = [
    ['Sirius', 101.287, -16.716, -1.46],
    ['Canopus', 95.988, -52.696, -0.74],
    ['Rigil Kentaurus', 219.902, -60.834, -0.27],
    ['Arcturus', 213.915, 19.182, -0.05],
    ['Vega', 279.234, 38.784, 0.03],
    ['Capella', 79.172, 45.998, 0.08],
    ['Rigel', 78.634, -8.202, 0.13],
    ['Procyon', 114.825, 5.225, 0.34],
    ['Betelgeuse', 88.793, 7.407, 0.50],
    ['Achernar', 24.429, -57.237, 0.46],
    ['Hadar', 210.956, -60.373, 0.61],
    ['Altair', 297.696, 8.868, 0.77],
    ['Acrux', 186.650, -63.099, 0.77],
    ['Aldebaran', 68.980, 16.509, 0.85],
    ['Antares', 247.352, -26.432, 1.09],
    ['Spica', 201.298, -11.161, 0.97],
    ['Pollux', 116.329, 28.026, 1.14],
    ['Fomalhaut', 344.413, -29.622, 1.16],
    ['Deneb', 310.358, 45.280, 1.25],
    ['Regulus', 152.093, 11.967, 1.35],
    ['Adhara', 104.656, -28.972, 1.50],
    ['Castor', 113.650, 31.888, 1.58],
    ['Bellatrix', 81.283, 6.350, 1.64],
    ['Elnath', 81.573, 28.608, 1.65],
    ['Miaplacidus', 138.300, -69.717, 1.68],
    ['Alnilam', 84.053, -1.202, 1.69],
    ['Alnair', 332.058, -46.961, 1.74],
    ['Alioth', 193.507, 55.960, 1.77],
    ['Regor', 122.383, -47.337, 1.78],
    ['Dubhe', 165.932, 61.751, 1.79],
    ['Mirfak', 51.081, 49.861, 1.82],
    ['Wezen', 107.098, -26.393, 1.84],
    ['Alkaid', 206.885, 49.313, 1.86],
    ['Polaris', 37.954, 89.264, 1.98],
    ['Mirzam', 95.675, -17.956, 1.98],
    ['Alphard', 141.897, -8.659, 1.98],
    ['Hamal', 31.793, 23.462, 2.00],
    ['Alphecca', 233.672, 26.715, 2.23],
    ['Rasalhague', 263.734, 12.560, 2.08],
    ['Denebola', 177.265, 14.572, 2.14],
  ];

  let mode = 'off'; // off | sats | stars
  let records = {}; // group -> satrec[]
  let enabled = { stations: true, amateur: true, iridium: true, globalstar: true };
  let raf = 0;

  function $(id) { return document.getElementById(id); }

  function observer() {
    let lat = 41.50, lon = -74.01;
    try {
      const raw = window.TricorderNative && TricorderNative.observerFix && TricorderNative.observerFix();
      const o = raw ? JSON.parse(raw) : null;
      if (o && o.ok) { lat = Number(o.lat); lon = Number(o.lon); }
    } catch {}
    return { lat: lat, lon: lon };
  }

  function parseTle(text, group) {
    const lines = String(text || '').split(/\r?\n/).map((s) => s.trim()).filter(Boolean);
    const out = [];
    if (typeof satellite === 'undefined') return out;
    for (let i = 0; i < lines.length - 1; i++) {
      if (lines[i].indexOf('1 ') === 0 && lines[i + 1].indexOf('2 ') === 0) {
        const name = (i > 0 && lines[i - 1].indexOf('1 ') !== 0) ? lines[i - 1] : 'SAT';
        try {
          const rec = satellite.twoline2satrec(lines[i], lines[i + 1]);
          out.push({ name: name.replace(/^0 /, ''), group: group, rec: rec });
        } catch {}
        i++;
      }
    }
    return out;
  }

  function loadGroups() {
    records = {};
    if (!(window.TricorderNative && TricorderNative.tleText)) return;
    ['stations', 'amateur', 'iridium', 'globalstar', 'orbcomm', 'geo', 'gps', 'visual'].forEach((id) => {
      try {
        const txt = TricorderNative.tleText(id);
        if (txt && txt.length > 80) records[id] = parseTle(txt, id);
      } catch {}
    });
  }

  function gstDeg(date) {
    const jd = date.getTime() / 86400000 + 2440587.5;
    const T = (jd - 2451545.0) / 36525;
    let gst = 280.46061837 + 360.98564736629 * (jd - 2451545.0) + 0.000387933 * T * T;
    gst = ((gst % 360) + 360) % 360;
    return gst;
  }

  function raDecToAltAz(raDeg, decDeg, lat, lon, date) {
    const lst = (gstDeg(date) + lon + 360) % 360;
    const ha = ((lst - raDeg + 540) % 360) - 180;
    const hr = ha * Math.PI / 180, dr = decDeg * Math.PI / 180, lr = lat * Math.PI / 180;
    const sinAlt = Math.sin(dr) * Math.sin(lr) + Math.cos(dr) * Math.cos(lr) * Math.cos(hr);
    const alt = Math.asin(Math.max(-1, Math.min(1, sinAlt)));
    const cosAz = (Math.sin(dr) - Math.sin(lr) * sinAlt) / (Math.cos(lr) * Math.cos(alt));
    let az = Math.acos(Math.max(-1, Math.min(1, cosAz)));
    if (Math.sin(hr) > 0) az = 2 * Math.PI - az;
    return { alt: alt * 180 / Math.PI, az: az * 180 / Math.PI };
  }

  function lookSat(sat, date, lat, lon) {
    if (typeof satellite === 'undefined') return null;
    try {
      const pv = satellite.propagate(sat.rec, date);
      if (!pv || !pv.position) return null;
      const gmst = satellite.gstime(date);
      const geo = satellite.eciToGeodetic(pv.position, gmst);
      const observerGd = {
        longitude: lon * Math.PI / 180,
        latitude: lat * Math.PI / 180,
        height: 0.05,
      };
      const posEcf = satellite.eciToEcf(pv.position, gmst);
      const look = satellite.ecfToLookAngles(observerGd, posEcf);
      return {
        name: sat.name,
        group: sat.group,
        az: look.azimuth * 180 / Math.PI,
        el: look.elevation * 180 / Math.PI,
        rangeKm: look.rangeSat,
      };
    } catch {
      return null;
    }
  }

  function heading() {
    const L = (window.sensorArray && sensorArray.latest) || {};
    return typeof L.heading === 'number' ? L.heading : 0;
  }

  function paintButton() {
    const b = $('skyBtn');
    if (!b) return;
    b.classList.toggle('horizon-on', mode !== 'off');
    b.classList.toggle('horizon-off', mode === 'off');
    const tiny = b.querySelector('.tiny');
    if (tiny) tiny.textContent = mode === 'sats' ? 'sats' : (mode === 'stars' ? 'stars' : 'off');
  }

  function showUi() {
    const cv = $('skyCanvas');
    const grp = $('skyGroups');
    if (cv) cv.style.display = mode === 'off' ? 'none' : 'block';
    if (grp) grp.style.display = mode === 'sats' ? 'flex' : 'none';
    paintButton();
    if (typeof setScreen === 'function') {
      if (mode === 'sats') setScreen('SATELLITES · Celestrak TLE · SGP4 live\nCheck groups. Rise = above horizon.');
      else if (mode === 'stars') setScreen('STARS · major catalog\nHold the face to the sky. Map follows heading.');
    }
  }

  function polar(ctx, az, el, w, h, hdg) {
    const rMax = Math.min(w, h) * 0.42;
    const zenithR = (90 - el) / 90 * rMax;
    const ang = (az - hdg) * Math.PI / 180;
    return { x: w / 2 + Math.sin(ang) * zenithR, y: h / 2 - Math.cos(ang) * zenithR, rMax: rMax };
  }

  function drawFrame() {
    const c = $('skyCanvas');
    if (!c || mode === 'off') return;
    const ctx = c.getContext('2d');
    const w = c.width, h = c.height;
    ctx.fillStyle = '#050a12';
    ctx.fillRect(0, 0, w, h);
    const obs = observer();
    const now = new Date();
    const hdg = heading();
    const mid = { x: w / 2, y: h / 2 };
    const rMax = Math.min(w, h) * 0.42;
    ctx.strokeStyle = '#1c4a33';
    ctx.beginPath(); ctx.arc(mid.x, mid.y, rMax, 0, Math.PI * 2); ctx.stroke();
    ctx.beginPath(); ctx.arc(mid.x, mid.y, rMax * 0.5, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = '#7dffb0';
    ctx.font = '9px "IBM Plex Mono", monospace';
    ctx.fillText('N', mid.x - 3, mid.y - rMax - 4);
    ctx.fillText('zenith', mid.x + 6, mid.y - 4);
    ctx.fillText(obs.lat.toFixed(2) + '  ' + obs.lon.toFixed(2), 6, 12);

    if (mode === 'stars') {
      let n = 0;
      STARS.forEach((s) => {
        const p = raDecToAltAz(s[1], s[2], obs.lat, obs.lon, now);
        if (p.alt < 0) return;
        const xy = polar(ctx, p.az, p.alt, w, h, hdg);
        const mag = s[3];
        const rad = mag < 0 ? 3.2 : (mag < 1 ? 2.4 : 1.6);
        ctx.fillStyle = '#e8f4ff';
        ctx.beginPath(); ctx.arc(xy.x, xy.y, rad, 0, Math.PI * 2); ctx.fill();
        if (mag < 1.2) {
          ctx.fillStyle = '#9ad4b0';
          ctx.fillText(s[0], xy.x + 4, xy.y - 2);
        }
        n++;
      });
      ctx.fillStyle = '#7dffb0';
      ctx.fillText(n + ' up  HDG ' + hdg.toFixed(0) + '°', 6, h - 8);
    } else {
      const colors = {
        stations: '#7dffb0', amateur: '#ffb454', iridium: '#6ec8ff',
        globalstar: '#e07aff', orbcomm: '#d8c070', geo: '#ff5b3d',
        gps: '#b0ff7d', visual: '#ffffff',
      };
      const vis = [];
      Object.keys(enabled).forEach((g) => {
        if (!enabled[g] || !records[g]) return;
        const list = records[g];
        const cap = g === 'geo' ? 40 : list.length;
        for (let i = 0; i < Math.min(list.length, cap); i++) {
          const look = lookSat(list[i], now, obs.lat, obs.lon);
          if (!look || look.el < 0) continue;
          vis.push(look);
          const xy = polar(ctx, look.az, look.el, w, h, hdg);
          ctx.fillStyle = colors[g] || '#7dffb0';
          ctx.beginPath(); ctx.arc(xy.x, xy.y, 2.2, 0, Math.PI * 2); ctx.fill();
          if (look.el > 30 || g === 'stations') {
            ctx.fillText(look.name.slice(0, 14), xy.x + 4, xy.y - 2);
          }
        }
      });
      vis.sort((a, b) => b.el - a.el);
      ctx.fillStyle = '#7dffb0';
      ctx.fillText(vis.length + ' above horizon', 6, h - 8);
      if (vis[0]) {
        const top = vis[0];
        ctx.fillText(top.name.slice(0, 18) + '  el ' + top.el.toFixed(0) + '°  ' + Math.round(top.rangeKm) + ' km', 6, 24);
      }
    }
  }

  function loop() {
    if (mode === 'off') { raf = 0; return; }
    drawFrame();
    raf = requestAnimationFrame(loop);
  }

  function cycle() {
    if (mode === 'off') mode = 'sats';
    else if (mode === 'sats') mode = 'stars';
    else mode = 'off';
    if (mode === 'sats') loadGroups();
    showUi();
    if (mode !== 'off' && !raf) loop();
  }

  function wire() {
    const b = $('skyBtn');
    if (b) b.addEventListener('click', cycle);
    document.querySelectorAll('#skyGroups input[type=checkbox]').forEach((cb) => {
      cb.addEventListener('change', () => {
        enabled[cb.getAttribute('data-g')] = cb.checked;
      });
    });
    const fetch = $('fetchTle');
    if (fetch) fetch.addEventListener('click', () => {
      try { TricorderNative.fetchTles(); } catch {}
    });
  }

  window.__tricorderSkyCycle = cycle;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire);
  else wire();
})();
