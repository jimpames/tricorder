package com.projecttricorder.app

import android.content.Context
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Persistent overhead / civic queues. Not RAM. */
object WatchBook {
    private fun dir(context: Context) = File(context.filesDir, "logs").also { it.mkdirs() }

    fun save(context: Context, name: String, json: String): String {
        val safe = name.replace(Regex("[^a-z0-9_-]"), "")
        if (safe.isBlank()) return """{"ok":false}"""
        return try {
            File(dir(context), "$safe.json").writeText(json)
            """{"ok":true,"bytes":${json.length}}"""
        } catch (e: Exception) {
            """{"ok":false,"error":"${e.message}"}"""
        }
    }

    fun load(context: Context, name: String): String {
        val safe = name.replace(Regex("[^a-z0-9_-]"), "")
        val f = File(dir(context), "$safe.json")
        if (!f.exists()) return "[]"
        return try { f.readText() } catch (_: Exception) { "[]" }
    }

    fun parseLen(raw: String): Int = try { JSONArray(raw).length() } catch (_: Exception) { 0 }

    fun loadFlights(context: Context): String {
        val live = load(context, "flights")
        if (parseLen(live) > 0) return live
        val log = File(dir(context), "field.jsonl")
        if (!log.exists()) return "[]"
        val byId = LinkedHashMap<String, JSONObject>()
        log.readLines().forEach { line ->
            if (line.isBlank()) return@forEach
            try {
                val o = JSONObject(line)
                if (o.optString("kind") != "flight") return@forEach
                val id = o.optString("icao24").ifBlank {
                    o.optString("registration").ifBlank {
                        o.optString("callsign").ifBlank { o.optString("id") }
                    }
                }
                val card = JSONObject()
                    .put("icao24", o.optString("icao24"))
                    .put("registration", o.optString("registration"))
                    .put("callsign", o.optString("callsign"))
                    .put("type", o.optString("type"))
                    .put("icao_type", o.optString("icao_type"))
                    .put("owner", o.optString("owner"))
                    .put("manufacturer", o.optString("manufacturer"))
                    .put("origin_city", o.optString("origin_city"))
                    .put("dest_city", o.optString("dest_city"))
                    .put("origin_label", o.optString("origin_label"))
                    .put("dest_label", o.optString("dest_label"))
                    .put("photo_url", o.optString("photo_url"))
                    .put("text", o.optString("text"))
                    .put("t_ms", o.optLong("t_ms"))
                    .put("t_local", o.optString("t_local"))
                val snap = o.optString("snap")
                if (snap.isNotBlank()) card.put("snap", snap)
                byId[id] = card
            } catch (_: Exception) {}
        }
        val out = JSONArray()
        byId.values.toList().takeLast(80).forEach { out.put(it) }
        if (out.length() > 0) save(context, "flights", out.toString())
        return out.toString()
    }
}
