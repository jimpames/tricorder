#!/usr/bin/env python3
"""Build Project-Tricorder-MkI-Field-Manual-0.6.78.pdf from on-device manual.html."""
from pathlib import Path
import re
from reportlab.lib.pagesizes import letter
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import inch
from reportlab.lib.colors import HexColor, white, black
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, KeepTogether, HRFlowable,
)
from reportlab.lib.enums import TA_LEFT

ROOT = Path(__file__).resolve().parent
HTML = ROOT.parent / "android-app/app/src/main/assets/www/manual.html"
OUT = ROOT / "Project-Tricorder-MkI-Field-Manual-0.6.78.pdf"
OUT2 = Path("/home/workdir/artifacts/Project-Tricorder-MkI-Field-Manual-0.6.78.pdf")

PHOS = HexColor("#0d1712")
GREEN = HexColor("#1a3d2a")
AMBER = HexColor("#8a4b12")
RED = HexColor("#6a2018")
INK = HexColor("#102018")


def tidy(s: str) -> str:
    s = s.replace("<code>", "<font face='Courier' color='#0a3d24'>").replace("</code>", "</font>")
    s = s.replace("<b>", "<b>").replace("</b>", "</b>")
    s = re.sub(r"<[^>]+>", lambda m: m.group(0) if m.group(0).startswith(("<b", "</b", "<i", "</i", "<font", "</font")) else "", s)
    s = s.replace("&gt;", "&gt;").replace("&lt;", "&lt;")
    return s.strip()


def parse(html: str):
    body = html.split("<body>", 1)[-1]
    blocks = []
    for raw in re.split(r"(?=<h[12]|<p>|<div class=\"warn\")", body):
        raw = raw.strip()
        if not raw or raw.startswith("<div><a"):
            continue
        if raw.startswith("<h1"):
            blocks.append(("h1", tidy(re.sub(r"</?h1>", "", raw.split("</h1>")[0] + "</h1>"))))
        elif raw.startswith("<h2"):
            blocks.append(("h2", tidy(re.sub(r"</?h2>", "", raw.split("</h2>")[0] + "</h2>"))))
        elif raw.startswith("<div class=\"warn\""):
            inner = raw.split("</div>")[0]
            inner = re.sub(r"^<div class=\"warn\">", "", inner)
            blocks.append(("warn", tidy(inner)))
        elif raw.startswith("<p>"):
            inner = raw.split("</p>")[0][3:]
            blocks.append(("p", tidy(inner)))
    return blocks


def main():
    html = HTML.read_text(encoding="utf-8")
    blocks = parse(html)
    styles = {
        "h1": ParagraphStyle("h1", fontName="Times-Bold", fontSize=13, leading=16, textColor=INK, spaceAfter=8, spaceBefore=0),
        "meta": ParagraphStyle("meta", fontName="Times-Roman", fontSize=9, leading=12, textColor=INK, spaceAfter=8),
        "h2": ParagraphStyle("h2", fontName="Times-Bold", fontSize=10.5, leading=13, textColor=HexColor("#6a3a08"), spaceBefore=10, spaceAfter=4),
        "p": ParagraphStyle("p", fontName="Times-Roman", fontSize=9.5, leading=12.2, textColor=INK, spaceAfter=5),
        "warn": ParagraphStyle("warn", fontName="Times-Roman", fontSize=8.5, leading=11, textColor=HexColor("#3a1008"), spaceAfter=6, leftIndent=4, rightIndent=4),
        "foot": ParagraphStyle("foot", fontName="Times-Roman", fontSize=8, leading=10, textColor=HexColor("#334433")),
    }
    story = []
    first = True
    for kind, text in blocks:
        if not text:
            continue
        if kind == "h1":
            story.append(Paragraph(text, styles["h1"]))
        elif kind == "h2":
            story.append(Paragraph(text, styles["h2"]))
        elif kind == "warn":
            story.append(Paragraph(text, styles["warn"]))
            story.append(Spacer(1, 4))
        else:
            if first:
                story.append(Paragraph(text, styles["meta"]))
                first = False
            else:
                story.append(Paragraph(text, styles["p"]))

    def header_footer(canv, doc):
        canv.saveState()
        canv.setFillColor(HexColor("#8b1a12"))
        canv.rect(0, letter[1] - 18, letter[0], 18, fill=1, stroke=0)
        canv.setFillColor(white)
        canv.setFont("Times-Bold", 8)
        canv.drawString(0.7 * inch, letter[1] - 13, "PROJECT TRICORDER MK. I  ·  FIELD MANUAL  ·  0.6.78")
        canv.setFillColor(HexColor("#d8ffe8"))
        canv.rect(0, 0, letter[0], 22, fill=1, stroke=0)
        canv.setFillColor(HexColor("#1a3d2a"))
        canv.setFont("Times-Roman", 8)
        canv.drawString(0.7 * inch, 8, "N2NHU Labs · Newburgh NY 12550 · Ames · Grok · Claude · GPL3")
        canv.drawRightString(letter[0] - 0.7 * inch, 8, f"page {doc.page}")
        canv.restoreState()

    OUT.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(OUT),
        pagesize=letter,
        leftMargin=0.7 * inch,
        rightMargin=0.7 * inch,
        topMargin=0.45 * inch,
        bottomMargin=0.4 * inch,
        title="Project Tricorder Mk I Field Manual 0.6.78",
        author="N2NHU Labs",
    )
    doc.build(story, onFirstPage=header_footer, onLaterPages=header_footer)
    print("wrote", OUT, OUT.stat().st_size)
    OUT2.parent.mkdir(parents=True, exist_ok=True)
    import shutil
    shutil.copyfile(OUT, OUT2)
    print("copied", OUT2, OUT2.stat().st_size)


if __name__ == "__main__":
    main()
