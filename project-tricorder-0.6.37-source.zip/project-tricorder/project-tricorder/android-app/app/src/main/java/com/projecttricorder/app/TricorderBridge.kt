package com.projecttricorder.app

import android.content.Context
import android.os.Build
import android.webkit.JavascriptInterface
import org.json.JSONObject

class TricorderBridge(private val activity: MainActivity) {

    @Volatile
    private var postureJson: String = """{"state":"UNKNOWN","orientation":"UNKNOWN","source":"none"}"""

    fun updatePosture(state: String, orientation: String, source: String) {
        postureJson = JSONObject()
            .put("state", state)
            .put("orientation", orientation)
            .put("source", source)
            .toString()
    }

    @JavascriptInterface
    fun getCapabilities(): String {
        return JSONObject()
            .put("platform", "android")
            .put("wrapper", "webview")
            .put("version", BuildConfig.VERSION_NAME)
            .put("sdk", Build.VERSION.SDK_INT)
            .put("manufacturer", Build.MANUFACTURER)
            .put("model", Build.MODEL)
            .put("device", Build.DEVICE)
            .put("foldPosture", true)
            .put("speech", true)
            .put("uwb", false)
            .put("nfc", false)
            .put("ambientBle", false)
            .toString()
    }

    @JavascriptInterface
    fun getFoldPosture(): String = postureJson

    @JavascriptInterface
    fun getDeviceInfo(): String {
        return JSONObject()
            .put("manufacturer", Build.MANUFACTURER)
            .put("model", Build.MODEL)
            .put("device", Build.DEVICE)
            .put("product", Build.PRODUCT)
            .put("release", Build.VERSION.RELEASE)
            .put("sdk", Build.VERSION.SDK_INT)
            .toString()
    }

    @JavascriptInterface
    fun vibrate(ms: Int) {
        val ctx = activity
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val mgr = ctx.getSystemService(android.os.VibratorManager::class.java)
            mgr?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
        }
        vibrator?.vibrate(
            android.os.VibrationEffect.createOneShot(
                ms.coerceIn(10, 400).toLong(),
                android.os.VibrationEffect.DEFAULT_AMPLITUDE,
            ),
        )
    }

    @JavascriptInterface
    fun startListening() {
        activity.runOnUiThread { activity.startNativeListen() }
    }

    @JavascriptInterface
    fun stopListening() {
        activity.runOnUiThread { activity.stopNativeListen() }
    }

    @JavascriptInterface
    fun speakKokoro(text: String) {
        activity.speakKokoro(text)
    }

    @JavascriptInterface
    fun stopKokoro() {
        activity.stopKokoro()
    }

    @JavascriptInterface
    fun stopRobo() {
        activity.stopRobo()
    }

    @JavascriptInterface
    fun speakRobo(text: String) {
        activity.speakRobo(text)
    }

    @JavascriptInterface
    fun playAlertTone(kind: String) {
        activity.playAlertTone(kind)
    }

    @JavascriptInterface
    fun getShipStatus(): String = activity.shipStatusJson()

    @JavascriptInterface
    fun startAudioSense(dwellMs: Int, intervalMs: Int) {
        activity.startAudioSense(dwellMs, intervalMs)
    }

    @JavascriptInterface
    fun stopAudioSense() {
        activity.stopAudioSense()
    }

    @JavascriptInterface
    fun setAudioDuty(dwellMs: Int, intervalMs: Int) {
        activity.setAudioDuty(dwellMs, intervalMs)
    }

    @JavascriptInterface
    fun getAudioLog(n: Int): String = activity.getAudioLog(n)

    @JavascriptInterface
    fun birdNetStatus(): String = activity.birdNetStatus()

    @JavascriptInterface
    fun fetchBirdNet() {
        activity.fetchBirdNet()
    }

    @JavascriptInterface
    fun startAudioLink() {
        activity.startAudioLink()
    }

    @JavascriptInterface
    fun stopAudioLink() {
        activity.stopAudioLink()
    }

    @JavascriptInterface
    fun floraStatus(): String = activity.floraStatus()

    @JavascriptInterface
    fun fetchFlora() {
        activity.fetchFlora()
    }

    @JavascriptInterface
    fun classifyFlora(dataUrl: String): String = activity.classifyFlora(dataUrl)

    @JavascriptInterface
    fun logVisionCaption(text: String) {
        activity.logVisionCaption(text)
    }

    @JavascriptInterface
    fun logField(kind: String, text: String, imageDataUrl: String): String = activity.logField(kind, text, imageDataUrl)

    @JavascriptInterface
    fun fieldLogSummary(): String = activity.fieldLogSummary()

    @JavascriptInterface
    fun fieldLogGet(index: Int): String = activity.fieldLogGet(index)

    @JavascriptInterface
    fun fieldLogGetById(id: String): String = activity.fieldLogGetById(id)

    @JavascriptInterface
    fun fieldLogCount(): Int = activity.fieldLogCount()

    @JavascriptInterface
    fun startVideoLog(): String = activity.startVideoLog()

    @JavascriptInterface
    fun stopVideoLog(): String = activity.stopVideoLog()

    @JavascriptInterface
    fun translateStatus(): String = activity.translateStatus()

    @JavascriptInterface
    fun translateLangs(): String = activity.translateLangs()

    @JavascriptInterface
    fun fetchTranslatePacks() { activity.fetchTranslatePacks() }

    @JavascriptInterface
    fun fetchTranslatePair(src: String, tgt: String) { activity.fetchTranslatePair(src, tgt) }

    @JavascriptInterface
    fun setTranslateLangs(src: String, tgt: String) { activity.setTranslateLangs(src, tgt) }

    @JavascriptInterface
    fun setTranslateAuto(on: Boolean) { activity.setTranslateAuto(on) }

    @JavascriptInterface
    fun startTranslator(src: String, tgt: String) { activity.startTranslator(src, tgt) }

    @JavascriptInterface
    fun stopTranslator() { activity.stopTranslator() }

    @JavascriptInterface
    fun startContextWatch(flagsJson: String) { activity.startContextWatch(flagsJson) }

    @JavascriptInterface
    fun stopContextWatch() { activity.stopContextWatch() }

    @JavascriptInterface
    fun packStatus(): String = activity.packStatusJson()

    @JavascriptInterface
    fun playFieldLog(index: Int): String = activity.playFieldLog(index)

    @JavascriptInterface
    fun openManual() { activity.openManual() }

    @JavascriptInterface
    fun openFDroidTermux() { activity.openFDroidTermux() }

    @JavascriptInterface
    fun termuxInstalled(): Boolean = try {
        activity.packageManager.getPackageInfo("com.termux", 0)
        true
    } catch (_: Exception) { false }

    @JavascriptInterface
    fun groundSpeed(): String = activity.groundSpeedJson()

    @JavascriptInterface
    fun tleStatus(): String = activity.tleStatus()

    @JavascriptInterface
    fun tleText(id: String): String = activity.tleText(id)

    @JavascriptInterface
    fun fetchTles() { activity.fetchTles() }

    @JavascriptInterface
    fun observerFix(): String = activity.observerFixJson()

    @JavascriptInterface
    fun solSnapshot(): String = activity.solSnapshot()

    @JavascriptInterface
    fun fetchSol() { activity.fetchSol() }

    @JavascriptInterface
    fun dictationList(): String = activity.dictationList()

    @JavascriptInterface
    fun dictationGet(id: String): String = activity.dictationGet(id)

    @JavascriptInterface
    fun dictationCreate(title: String): String = activity.dictationCreate(title)

    @JavascriptInterface
    fun dictationSave(id: String, body: String): String = activity.dictationSave(id, body)

    @JavascriptInterface
    fun dictationKill(id: String): Boolean = activity.dictationKill(id)

    @JavascriptInterface
    fun dictationSummarizeLocal(id: String): String = activity.dictationSummarizeLocal(id)

    @JavascriptInterface
    fun dictationMindmap(keyword: String): String = activity.dictationMindmap(keyword)

    @JavascriptInterface
    fun dictationStatus(): String = activity.dictationStatus()

    @JavascriptInterface
    fun fetchDictationEmbed() { activity.fetchDictationEmbed() }

    @JavascriptInterface
    fun lastFlight(): String = activity.lastFlight()

    @JavascriptInterface
    fun knowledgeSearch(bank: String, query: String) { activity.knowledgeSearch(bank, query) }

    @JavascriptInterface
    fun cityFacts(name: String) { activity.cityFacts(name) }

    @JavascriptInterface
    fun aircraftFacts(payloadJson: String) { activity.aircraftFacts(payloadJson) }

    @JavascriptInterface
    fun knowledgeStatus(): String = activity.knowledgeStatus()

    @JavascriptInterface
    fun gnssClock(): String = activity.gnssClockJson()

    @JavascriptInterface
    fun placeNow(): String = activity.placeJson()
}
