/* Hands-free top-level menu: say TRICORDER + function. */
(function () {
  function norm(s) {
    return String(s || '')
      .toLowerCase()
      .replace(/[.!?]+$/g, '')
      .replace(/[^a-z0-9\s]/g, ' ')
      .replace(/\b(trick order|tric order|try corder|tree corder|try quarter|trick corder)\b/g, 'tricorder')
      .replace(/\s+/g, ' ')
      .trim();
  }

  window.parseTricorderCmd = function (s) {
    const t = norm(s);
    if (!t) return null;
    const m = t.match(/^(please |open |start |engage |go to )?(the )?(tricorder)\s+(.+)$/);
    if (!m) return null;
    let rest = (m[4] || '').trim();
    rest = rest.replace(/^(the |a )/, '');
    if (/^(sensor|sensors|scan|scanning)$/.test(rest)) return { act: 'sensor' };
    if (/^(audio|sound|listen)$/.test(rest)) return { act: 'audio' };
    if (/^(sentry|guard|guarding)$/.test(rest)) return { act: 'sentry' };
    if (/^(translator|translate|xlate|xlat)$/.test(rest)) return { act: 'translator' };
    if (/^(horizon|artificial horizon)$/.test(rest)) return { act: 'horizon' };
    if (/^(satellites?|stars?|sat stars|sat star)$/.test(rest)) return { act: 'sky' };
    if (/^(sol|solar|sol system|sun)$/.test(rest)) return { act: 'sol' };
    if (/^(clock|satellite clock)$/.test(rest)) return { act: 'clock' };
    if (/^(dictation|dictate)$/.test(rest)) return { act: 'dictation' };
    if (/^(diagnostics?|diagnostic)$/.test(rest)) return { act: 'diagnostics' };
    if (/^(settings?)$/.test(rest)) return { act: 'settings' };
    if (/^(back\s*end|backend|camera|backend and camera)$/.test(rest)) return { act: 'backend' };
    if (/^summarize readings\b/.test(rest) || /^readings\b/.test(rest)) {
      let rc = null;
      try { rc = parseReadingsCmd(rest.replace(/^tricorder\s+/, '')); } catch (e) {}
      if (!rc) {
        try { rc = parseReadingsCmd(rest); } catch (e) {}
      }
      return { act: 'readings', rc: rc || { cat: 'all', tf: 'day' } };
    }
    if (/^help$/.test(rest)) return { act: 'help' };
    return { act: 'unknown', rest: rest };
  };

  window.runTricorderCmd = function (cmd) {
    if (!cmd) return false;
    const say = (t) => {
      try { if (typeof setScreen === 'function') setScreen(t); } catch (e) {}
      try { if (typeof speak === 'function') speak(t.replace(/\n/g, '. '), { force: true }); } catch (e) {}
    };
    try {
      if (cmd.act === 'sensor') { engageSensor(); say('Sensor.'); return true; }
      if (cmd.act === 'audio') { engageAudio(); say('Audio sense.'); return true; }
      if (cmd.act === 'sentry') { engageSentry(); say('Sentry.'); return true; }
      if (cmd.act === 'translator') { engageTranslator(); say('Translator.'); return true; }
      if (cmd.act === 'horizon') {
        const b = document.getElementById('horizonBtn');
        if (b) b.click();
        say('Horizon.');
        return true;
      }
      if (cmd.act === 'sky') {
        if (typeof window.__tricorderSkyCycle === 'function') window.__tricorderSkyCycle();
        else {
          const b = document.getElementById('skyBtn');
          if (b) b.click();
        }
        say('Satellites and stars.');
        return true;
      }
      if (cmd.act === 'sol') {
        const b = document.getElementById('solBtn');
        if (b) b.click();
        say('Sol.');
        return true;
      }
      if (cmd.act === 'clock') {
        if (typeof openClock === 'function') openClock();
        return true;
      }
      if (cmd.act === 'dictation') { enterDictation(); return true; }
      if (cmd.act === 'diagnostics') { runDiagnostics(); return true; }
      if (cmd.act === 'settings') { openSettingsSheet(); say('Settings.'); return true; }
      if (cmd.act === 'backend') { openBackendSheet(); say('Backend.'); return true; }
      if (cmd.act === 'readings') {
        openReadings(cmd.rc.cat, cmd.rc.tf);
        return true;
      }
      if (cmd.act === 'help') {
        try { openSheet('sheetHelp'); } catch (e) {}
        say('Help. Say tricorder and a function. Sensor, audio, sentry, translator, horizon, satellites, sol, clock, dictation, settings, back end, diagnostics, summarize readings.');
        return true;
      }
      say('Tricorder menu. Say tricorder sensor, audio, sentry, translator, horizon, satellites, sol, clock, dictation, settings, back end, diagnostics, or summarize readings.');
      return true;
    } catch (e) {
      console.log(e);
      say('Voice menu error.');
      return true;
    }
  };
})();
