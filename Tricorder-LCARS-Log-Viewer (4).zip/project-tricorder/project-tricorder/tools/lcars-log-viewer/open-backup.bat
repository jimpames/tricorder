@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1 && set PY=py || set PY=python
if "%~1"=="" (
  start "" "%~dp0Tricorder-LCARS.html"
  exit /b 0
)
"%PY%" "%~dp0open-backup.py" "%~1"
if errorlevel 1 start "" "%~dp0Tricorder-LCARS.html"
endlocal
