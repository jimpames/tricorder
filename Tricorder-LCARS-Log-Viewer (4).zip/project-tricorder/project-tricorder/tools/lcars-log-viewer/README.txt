PROJECT TRICORDER MK. I — LCARS log viewer
N2NHU Labs · Windows 11 companion for tricorder-backup-v2.zip

Drop the zip on open-backup.bat
  or double-click Tricorder-LCARS.html and drop the zip on the orange well
  or:  python open-backup.py "C:\Users\you\Downloads\tricorder-backup-v2.zip"

Needs a current Edge / Chrome / Firefox. Python is optional (only for the
.bat drop-target that preloads the archive).

Decodes schema 2:
  meta.json     callsign, prefs, face
  field.jsonl   sensor / sentry / spoken book
  audio.jsonl   YAMNet + BirdNET
  flights.json  overhead cards
  civic.json    CityAlert / IPAWS / watch
  memos.json    dictation (if present)

Photos: embedded JPEG (photo / snap) first, else a promoted full still from
the stored URL. List pages 400 at a time and says showing N of M.
open-backup.py writes under %TEMP% and removes any old _last-opened.html.
