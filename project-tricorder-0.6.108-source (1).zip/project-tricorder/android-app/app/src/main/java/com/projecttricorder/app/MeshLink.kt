package com.projecttricorder.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import org.json.JSONObject
import java.util.UUID

/**
 * Meshtastic BLE bearer for T1000-E / any Meshtastic node.
 * Settings (prefs): lora_on, lora_pin, lora_region, lora_dest, lora_filter.
 */
@SuppressLint("MissingPermission")
class MeshLink(
    private val context: Context,
    private val onIncoming: (JSONObject) -> Unit,
    private val onStatus: (String) -> Unit,
) {
    @Volatile var running = false
        private set
    @Volatile var linked = false
        private set
    @Volatile var radioName = ""
        private set
    @Volatile var lastStatus = "idle"
        private set
    private val diag = ArrayDeque<String>()

    private fun mark(s: String) {
        lastStatus = s
        val line = android.text.format.DateFormat.format("HH:mm:ss", System.currentTimeMillis()).toString() + " " + s
        synchronized(diag) {
            diag.addLast(line)
            while (diag.size > 12) diag.removeFirst()
        }
        onStatus(s)
    }

    private val ui = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var toRadio: BluetoothGattCharacteristic? = null
    private var fromRadio: BluetoothGattCharacteristic? = null
    private var fromNum: BluetoothGattCharacteristic? = null
    private var scanning = false
    private var seen = 0

    fun start() {
        if (!pref("lora_on", "0").equals("1") && !pref("lora_on", "0").equals("true", true)) {
            mark("LoRa off in settings")
            return
        }
        stop()
        running = true
        val adapter = adapter() ?: run {
            mark("Bluetooth off")
            return
        }
        val scanner = adapter.bluetoothLeScanner ?: run {
            mark("no LE scanner")
            return
        }
        scanning = true
        seen = 0
        namedSeen = 0
        mark("LoRa scanning raw+bonded")
        tryBonded(adapter)
        if (gatt != null) return
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .setCallbackType(ScanSettings.CALLBACK_TYPE_ALL_MATCHES)
            .setMatchMode(ScanSettings.MATCH_MODE_AGGRESSIVE)
            .setNumOfMatches(ScanSettings.MATCH_NUM_MAX_ADVERTISEMENT)
            .setLegacy(true)
            .setReportDelay(0)
            .build()
        try {
            scanner.startScan(null, settings, scanCb)
        } catch (t: Exception) {
            mark("scan fail ${t.message}")
        }
        ui.postDelayed({
            if (scanning && gatt == null) {
                try { scanner.stopScan(scanCb) } catch (_: Exception) {}
                scanning = false
                mark("LoRa heard $seen radios, none matched. Wake the card, unpair Meshtastic, rescan")
            }
        }, 18_000)
    }

    fun stop() {
        running = false
        linked = false
        scanning = false
        try { adapter()?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {}
        try { gatt?.disconnect() } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        toRadio = null
        fromRadio = null
        fromNum = null
        radioName = ""
        mark("LoRa off")
    }

    private val txQueue = ArrayDeque<String>()
    private var txDrip = false

    fun sendText(text: String) {
        val clip = text.trim().replace(Regex("\\s+"), " ")
        if (clip.isEmpty() || !linked) return
        // Subspace frames are already MTU-sized. PTT stays one short packet.
        val line = if (clip.startsWith("TF|")) clip.take(200) else clip.take(180)
        synchronized(txQueue) { txQueue.addLast(line) }
        drip()
    }

    private fun drip() {
        if (txDrip || !linked) return
        val line = synchronized(txQueue) { if (txQueue.isEmpty()) null else txQueue.removeFirst() } ?: return
        txDrip = true
        val dest = parseDest(pref("lora_dest", "ffffffff"))
        writeToRadio(MeshProto.textToRadio(line, dest))
        ui.postDelayed({ gatt?.let { drain(it) } }, 500)
        ui.postDelayed({
            txDrip = false
            drip()
            gatt?.let { drain(it) }
        }, 700)
    }

    fun send(row: JSONObject) {
        if (row.optString("kind") == "ptt") {
            val who = row.optString("from").ifBlank { "REMOTE" }.replace("|", "/")
            val msg = row.optString("text").replace("|", "/").trim().take(140)
            sendText("PTT|$who|$msg")
            return
        }
        val line = listOf(
            row.optString("from"),
            row.optString("source"),
            row.optString("text"),
        ).filter { it.isNotBlank() }.joinToString(" · ")
        sendText(if (line.length > 8) line else row.toString())
    }

    fun statusJson(): JSONObject = JSONObject()
        .put("running", running)
        .put("linked", linked)
        .put("radio", radioName)
        .put("on", pref("lora_on", "0"))
        .put("region", pref("lora_region", "US"))
        .put("pin", pref("lora_pin", "123456"))
        .put("dest", pref("lora_dest", "ffffffff"))
        .put("filter", pref("lora_filter", "T1000"))
        .put("last", lastStatus)
        .put("diag", org.json.JSONArray().also { arr -> synchronized(diag) { diag.forEach { arr.put(it) } } })

    private fun pref(k: String, d: String) =
        context.getSharedPreferences("tricorder", Context.MODE_PRIVATE).getString(k, d) ?: d

    private fun adapter(): BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (!running || gatt != null) return
            val dev = result.device ?: return
            val name = advName(result)
            val mesh = hasMeshUuid(result)
            seen += 1
            if (name.isNotBlank() && namedSeen < 8) {
                namedSeen += 1
                mark("named $name mesh=$mesh")
            } else if (seen <= 4) {
                mark("heard ${dev.address} mesh=$mesh")
            }
            if (!looksLikeRadio(name) && !mesh) return
            pair(dev, name.ifBlank { dev.address })
        }
        override fun onScanFailed(errorCode: Int) {
            mark("LoRa scan error $errorCode")
        }
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                mark("LoRa GATT up")
                g.requestMtu(512)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                linked = false
                mark("LoRa dropped status=$status")
                if (running) ui.postDelayed({ if (running && gatt == null) start() }, 4000)
            }
        }
        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            g.discoverServices()
        }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(SVC)
            if (svc == null) {
                mark("LoRa service missing")
                return
            }
            toRadio = svc.getCharacteristic(TORADIO)
            fromRadio = svc.getCharacteristic(FROMRADIO)
            fromNum = svc.getCharacteristic(FROMNUM)
            val fn = fromNum
            if (fn != null) {
                g.setCharacteristicNotification(fn, true)
                val cccd = fn.getDescriptor(CCCD)
                if (cccd != null) {
                    cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    g.writeDescriptor(cccd)
                } else {
                    afterNotifyReady(g)
                }
            } else {
                afterNotifyReady(g)
            }
        }
        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            afterNotifyReady(g)
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
            if (ch.uuid == FROMNUM) drain(g)
        }
        override fun onCharacteristicRead(g: BluetoothGatt, ch: BluetoothGattCharacteristic, status: Int) {
            gattBusy = false
            if (ch.uuid == FROMRADIO && status == BluetoothGatt.GATT_SUCCESS) {
                val v = ch.value ?: ByteArray(0)
                if (v.isNotEmpty()) handleFromRadio(v)
                if (v.isNotEmpty()) {
                    drain(g)
                    return
                }
            }
            pumpGatt(g)
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, ch: BluetoothGattCharacteristic, status: Int) {
            gattBusy = false
            pumpGatt(g)
        }
    }

    private fun afterNotifyReady(g: BluetoothGatt) {
        linked = toRadio != null
        if (linked) mark("LoRa linked ${radioName.ifBlank { "radio" }}")
        writeToRadio(MeshProto.wantConfig((System.currentTimeMillis() and 0x7fffffff).toInt()))
        ui.postDelayed({ drain(g) }, 300)
        ui.postDelayed(object : Runnable {
            override fun run() {
                if (!running || gatt == null) return
                gatt?.let { drain(it) }
                ui.postDelayed(this, 2000)
            }
        }, 2000)
    }

    private var gattBusy = false
    private var readQueued = false
    private val gattWrites = ArrayDeque<ByteArray>()

    private fun drain(g: BluetoothGatt) {
        if (gattBusy) {
            readQueued = true
            return
        }
        val fr = fromRadio ?: return
        gattBusy = true
        try {
            if (!g.readCharacteristic(fr)) {
                gattBusy = false
                ui.postDelayed({ drain(g) }, 250)
            }
        } catch (_: Exception) {
            gattBusy = false
        }
    }

    private fun pumpGatt(g: BluetoothGatt) {
        if (gattBusy) return
        if (readQueued) {
            readQueued = false
            drain(g)
            return
        }
        val next = synchronized(gattWrites) { if (gattWrites.isEmpty()) null else gattWrites.removeFirst() } ?: return
        writeNow(g, next)
    }

    private fun writeToRadio(bytes: ByteArray) {
        val g = gatt ?: return
        if (gattBusy || readQueued) {
            synchronized(gattWrites) { gattWrites.addLast(bytes) }
            return
        }
        writeNow(g, bytes)
    }

    private fun writeNow(g: BluetoothGatt, bytes: ByteArray) {
        val ch = toRadio ?: return
        ch.value = bytes
        ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        gattBusy = true
        try {
            if (!g.writeCharacteristic(ch)) {
                gattBusy = false
                synchronized(gattWrites) { gattWrites.addFirst(bytes) }
                ui.postDelayed({ pumpGatt(g) }, 250)
            }
        } catch (_: Exception) {
            gattBusy = false
        }
    }

    private fun handleFromRadio(bytes: ByteArray) {
        val texts = MeshProto.extractTexts(bytes).ifEmpty { sniffText(bytes) }
        if (texts.isEmpty()) {
            mark("LoRa rx ${bytes.size}b no text")
            return
        }
        texts.forEach { raw ->
            mark("LoRa rx " + raw.take(48))
            val obj = try {
                JSONObject(raw)
            } catch (_: Exception) {
                JSONObject()
                    .put("kind", "context")
                    .put("source", "lora")
                    .put("from", radioName.ifBlank { "LORA" })
                    .put("text", raw)
                    .put("remote", true)
            }
            if (!obj.has("kind")) obj.put("kind", "context")
            if (!obj.has("source")) obj.put("source", "lora")
            if (!obj.has("from")) obj.put("from", radioName.ifBlank { "LORA" })
            obj.put("via", "lora")
            onIncoming(obj)
        }
    }

    private fun sniffText(bytes: ByteArray): List<String> {
        val s = String(bytes, Charsets.ISO_8859_1)
        val out = ArrayList<String>()
        for (tag in listOf("PTT|", "TF|", "TC|")) {
            var i = s.indexOf(tag)
            while (i >= 0) {
                var end = i
                while (end < s.length && end - i < 180 && s[end].code in 32..126) end++
                if (end > i + tag.length) out.add(s.substring(i, end))
                i = s.indexOf(tag, i + tag.length)
            }
        }
        return out
    }

    private fun parseDest(s: String): Int {
        val h = s.trim().removePrefix("0x").removePrefix("0X")
        return try { (h.toLong(16) and 0xffffffffL).toInt() } catch (_: Exception) { MeshProto.BROADCAST }
    }

    private var namedSeen = 0

    private fun tryBonded(adapter: BluetoothAdapter) {
        val bonded = try { adapter.bondedDevices } catch (_: Exception) { null } ?: return
        val names = bonded.mapNotNull { it.name?.trim() }.filter { it.isNotBlank() }.take(6)
        if (names.isNotEmpty()) mark("bonded " + names.joinToString(","))
        val hit = bonded.firstOrNull { looksLikeRadio(it.name ?: "") } ?: return
        pair(hit, hit.name ?: hit.address)
    }

    private fun pair(dev: BluetoothDevice, name: String) {
        if (!running || gatt != null) return
        scanning = false
        try { adapter()?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {}
        radioName = name
        mark("LoRa pairing $radioName")
        try {
            val pin = pref("lora_pin", "123456")
            try { dev.setPin(pin.toByteArray(Charsets.UTF_8)) } catch (_: Exception) {}
            try { dev.createBond() } catch (_: Exception) {}
        } catch (_: Exception) {}
        ui.post {
            if (gatt == null) gatt = dev.connectGatt(context, false, gattCb, BluetoothDevice.TRANSPORT_LE)
        }
    }

    private fun looksLikeRadio(name: String): Boolean {
        val filt = pref("lora_filter", "T1000").trim()
        return name.contains("T1000", true) ||
            name.contains("meshtastic", true) ||
            name.contains("sensecap", true) ||
            (filt.isNotBlank() && name.contains(filt, true))
    }

    private fun advName(result: ScanResult): String {
        val rec = result.scanRecord
        val parsed = (result.device?.name ?: rec?.deviceName ?: "").trim()
        if (parsed.isNotEmpty()) return parsed
        return localName(rec?.bytes)
    }

    private fun hasMeshUuid(result: ScanResult): Boolean {
        val rec = result.scanRecord ?: return false
        val listed = rec.serviceUuids
        if (listed != null && listed.any { it.uuid == SVC }) return true
        return containsBytes(rec.bytes, MESH_UUID_LE)
    }

    private fun localName(bytes: ByteArray?): String {
        if (bytes == null) return ""
        var i = 0
        var best = ""
        while (i < bytes.size) {
            val len = bytes[i].toInt() and 0xff
            if (len == 0 || i + len >= bytes.size) break
            val type = bytes[i + 1].toInt() and 0xff
            if ((type == 0x08 || type == 0x09) && len > 1) {
                val n = String(bytes, i + 2, len - 1, Charsets.UTF_8).trim().trim('\u0000')
                if (n.length > best.length) best = n
            }
            i += len + 1
        }
        return best
    }

    private fun containsBytes(hay: ByteArray?, needle: ByteArray): Boolean {
        if (hay == null || hay.size < needle.size) return false
        for (i in 0..hay.size - needle.size) {
            var ok = true
            for (j in needle.indices) {
                if (hay[i + j] != needle[j]) { ok = false; break }
            }
            if (ok) return true
        }
        return false
    }

    companion object {
        val SVC: UUID = UUID.fromString("6ba1b218-15a8-461f-9fa8-5dcae273eafd")
        // Meshtastic puts this 128-bit UUID in the scan response, little-endian.
        private val MESH_UUID_LE = byteArrayOf(
            0xfd.toByte(), 0xea.toByte(), 0x73, 0xe2.toByte(), 0xca.toByte(), 0x5d,
            0xa8.toByte(), 0x9f.toByte(), 0x1f, 0x46, 0xa8.toByte(), 0x15,
            0x18, 0xb2.toByte(), 0xa1.toByte(), 0x6b,
        )
        val TORADIO: UUID = UUID.fromString("f75c76d2-129e-4dad-a1dd-7866124401e7")
        val FROMRADIO: UUID = UUID.fromString("2c55e69e-4993-11ed-b878-0242ac120002")
        val FROMNUM: UUID = UUID.fromString("ed9da18c-a800-4f66-a670-aa7547e34453")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }
}
