/* Voice CLOCK — GNSS face + labeled timers. Existing field-log stamps stay wall-clock. */
(function () {
  let on = false;
  let analog = true;
  let h24 = true;
  let tickT = 0;
  const timers = []; // {id, label, endMs, fired}
  let lastClock = { locked: false, utc_ms: Date.now(), unc_ns: null, sats: 0, source: 'device', leap_s: 18 };

  function $(id) { return document.getElementById(id); }
  function speakSafe(t) {
    try { if (typeof speak === 'function') speak(t, { force: true }); } catch {}
    try { if (window.TricorderNative && TricorderNative.speakRobo) TricorderNative.speakRobo(t); } catch {}
  }
  function tone() {
    try { if (window.TricorderNative && TricorderNative.playAlertTone) TricorderNative.playAlertTone('chime'); } catch {}
    try { if (window.TricorderNative && TricorderNative.vibrate) TricorderNative.vibrate(180); } catch {}
  }

  function pullClock() {
    try {
      if (window.TricorderNative && TricorderNative.gnssClock) {
        lastClock = JSON.parse(TricorderNative.gnssClock() || '{}');
      }
    } catch {}
    return lastClock;
  }

  function fmtTime(ms, withMs) {
    const d = new Date(ms);
    let h = d.getHours();
    const m = d.getMinutes();
    const s = d.getSeconds();
    const cs = d.getMilliseconds();
    let suffix = '';
    if (!h24) {
      suffix = h >= 12 ? ' PM' : ' AM';
      h = h % 12; if (h === 0) h = 12;
    }
    const pad = (n, w) => String(n).padStart(w || 2, '0');
    return pad(h) + ':' + pad(m) + ':' + pad(s) + (withMs ? '.' + pad(cs, 3) : '') + suffix;
  }

  function drawAnalog(ctx, w, h, ms) {
    const d = new Date(ms);
    const cx = w / 2, cy = h / 2 + 4, r = Math.min(w, h) * 0.36;
    ctx.fillStyle = '#05080f';
    ctx.fillRect(0, 0, w, h);
    ctx.strokeStyle = '#3f8a63';
    ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    for (let i = 0; i < 12; i++) {
      const a = (i / 12) * Math.PI * 2 - Math.PI / 2;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * (r - 8), cy + Math.sin(a) * (r - 8));
      ctx.lineTo(cx + Math.cos(a) * r, cy + Math.sin(a) * r);
      ctx.strokeStyle = i % 3 === 0 ? '#7dffb0' : '#3f8a63';
      ctx.stroke();
    }
    const sec = d.getSeconds() + d.getMilliseconds() / 1000;
    const min = d.getMinutes() + sec / 60;
    const hour = (d.getHours() % 12) + min / 60;
    function hand(frac, len, col, width) {
      const a = frac * Math.PI * 2 - Math.PI / 2;
      ctx.strokeStyle = col; ctx.lineWidth = width;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(a) * r * len, cy + Math.sin(a) * r * len);
      ctx.stroke();
    }
    hand(hour / 12, 0.55, '#d8ffe8', 3);
    hand(min / 60, 0.78, '#7dffb0', 2);
    hand(sec / 60, 0.9, '#ffb454', 1);
    ctx.fillStyle = '#ffb454';
    ctx.beginPath(); ctx.arc(cx, cy, 3, 0, Math.PI * 2); ctx.fill();
  }

  function paint() {
    if (!on) return;
    const clk = lastClock;
    const ms = clk.utc_ms || Date.now();
    const face = $('clockFace');
    const dig = $('clockDigits');
    const meta = $('clockMeta');
    const list = $('clockTimers');
    if (face) {
      face.style.display = analog ? 'block' : 'none';
      if (analog) {
        const ctx = face.getContext('2d');
        if (ctx) drawAnalog(ctx, face.width, face.height, ms);
      }
    }
    if (dig) {
      dig.style.display = analog ? 'none' : 'block';
      dig.textContent = fmtTime(ms, true);
    }
    if (meta) {
      const unc = clk.unc_ns;
      const uncTxt = (typeof unc === 'number' && isFinite(unc))
        ? (unc >= 1000 ? (unc / 1000).toFixed(0) + ' µs' : unc.toFixed(0) + ' ns')
        : 'n/a';
      meta.textContent = (clk.locked ? 'GNSS UTC' : 'DEVICE CLOCK') +
        ' · ' + (clk.sats || 0) + ' meas' +
        ' · ±' + uncTxt +
        ' · leap ' + (clk.leap_s || 18) + 's' +
        ' · face 4 Hz · GNSS ~1 Hz';
    }
    if (list) {
      const now = Date.now();
      list.innerHTML = timers.length ? timers.map((t) => {
        const left = Math.max(0, t.endMs - now);
        const sec = Math.ceil(left / 1000);
        return '<div class="clock-t">' + t.label + '  ' + sec + 's' + (t.fired ? '  DONE' : '') + '</div>';
      }).join('') : '<div class="clock-t">no timers — say TIMER coffee 5 minutes</div>';
    }
  }

  function fireTimers() {
    const now = Date.now();
    timers.forEach((t) => {
      if (!t.fired && now >= t.endMs) {
        t.fired = true;
        tone();
        speakSafe('Timer ' + t.label + ' complete.');
        try { if (typeof setScreen === 'function') setScreen('TIMER DONE  ' + t.label); } catch {}
      }
    });
  }

  function loop() {
    if (!on) { tickT = 0; return; }
    pullClock();
    fireTimers();
    paint();
    tickT = setTimeout(loop, 250);
  }

  function explainer() {
    const c = lastClock || {};
    return [
      'Satellite clock. When the GNSS receiver has a lock we use Android GnssClock.',
      'GPS time is TimeNanos minus full bias minus bias, then leap seconds to UTC.',
      'The API reports nanoseconds. The chip uncertainty on a Fold 3 is typically tens to a few hundred nanoseconds in open sky, not a laboratory clock.',
      c.locked ? 'Receiver is locked. Uncertainty ' + (c.unc_ns || 'unreported') + ' nanoseconds. ' + (c.sats || 0) + ' measurements this epoch.' : 'Receiver is not locked. Showing the phone device clock at one millisecond until GNSS bias is available.',
      'Screen updates four times per second. The GNSS hardware epoch is about one hertz; we interpolate with elapsed realtime between epochs.',
      'Field log timestamps are unchanged. They still use the ordinary millisecond wall clock.',
      'Say analog or digital. Say twelve hour or twenty four hour. Say timer, a label, and a duration. Say cancel timer and the label. Say terminate to leave.',
    ].join(' ');
  }

  function parseDuration(s) {
    const t = String(s || '').toLowerCase();
    let sec = 0;
    const hm = t.match(/(\d+(?:\.\d+)?)\s*(hours?|hrs?)\b/);
    const mm = t.match(/(\d+(?:\.\d+)?)\s*(minutes?|mins?)\b/);
    const ss = t.match(/(\d+(?:\.\d+)?)\s*(seconds?|secs?)\b/);
    if (hm) sec += parseFloat(hm[1]) * 3600;
    if (mm) sec += parseFloat(mm[1]) * 60;
    if (ss) sec += parseFloat(ss[1]);
    if (!sec) {
      const words = { one:1, two:2, three:3, four:4, five:5, six:6, seven:7, eight:8, nine:9, ten:10, fifteen:15, twenty:20, thirty:30, forty:40, fortyfive:45, sixty:60 };
      for (const [w, n] of Object.entries(words)) {
        if (t.includes(w + ' minute')) sec += n * 60;
        else if (t.includes(w + ' hour')) sec += n * 3600;
        else if (t.includes(w + ' second')) sec += n;
      }
    }
    if (!sec) {
      const bare = t.match(/\b(\d+)\b/);
      if (bare) sec = parseInt(bare[1], 10) * 60;
    }
    return sec;
  }

  function parseLabel(s) {
    let t = String(s || '');
    t = t.replace(/^(set |start |create |new )?(a |the )?timer( for| called| named)?/i, '');
    t = t.replace(/\d+(?:\.\d+)?\s*(hours?|hrs?|minutes?|mins?|seconds?|secs?)/gi, '');
    t = t.replace(/\b(one|two|three|four|five|six|seven|eight|nine|ten|fifteen|twenty|thirty)\s+(hours?|minutes?|seconds?)\b/gi, '');
    t = t.replace(/\b(for|called|named|in)\b/gi, ' ');
    t = t.replace(/\s+/g, ' ').trim();
    return t || ('timer-' + (timers.length + 1));
  }


  function afterCmd() {
    try { if (typeof matrix !== 'undefined' && matrix.sensorLine) matrix.sensorLine('CLOCK  analog digital 12 24 timer terminate'); } catch (e) {}
    try { if (typeof window.clockListenSoon === 'function') window.clockListenSoon(); } catch (e) {}
  }
  window.isClockOpen = function () { return !!on; };

  window.handleClockUtterance = function (text) {
    if (!on) return false;
    const raw = String(text || '').replace(/[.!?]+$/g, '').trim();
    const t = raw.toLowerCase().replace(/\s+/g, ' ');
    if (!t) { afterCmd(); return true; }
    if (/^(terminate|close|clock off|leave clock|exit clock|done)$/.test(t)) { closeClock(); return true; }
    if (/analog|analogue/.test(t) && !/digital/.test(t)) { analog = true; paint(); speakSafe('Analog face.'); afterCmd(); return true; }
    if (/digital|digits/.test(t)) { analog = false; paint(); speakSafe('Digital face.'); afterCmd(); return true; }
    if (/switch face|toggle face/.test(t)) { analog = !analog; paint(); speakSafe(analog ? 'Analog face.' : 'Digital face.'); afterCmd(); return true; }
    if (/twelve|12 hour|12-hour/.test(t) && !/twenty|24/.test(t)) { h24 = false; paint(); speakSafe('Twelve hour.'); afterCmd(); return true; }
    if (/twenty four|twenty-four|24 hour|24-hour/.test(t)) { h24 = true; paint(); speakSafe('Twenty four hour.'); afterCmd(); return true; }
    if (/explain|source|resolution|how accurate|explainer/.test(t)) {
      const e = explainer();
      try { if (typeof setScreen === 'function') setScreen(e); } catch (e2) {}
      speakSafe(e);
      afterCmd();
      return true;
    }
    if (/cancel all/.test(t)) { timers.splice(0, timers.length); paint(); speakSafe('All timers cancelled.'); afterCmd(); return true; }
    const can = t.match(/cancel (?:the )?(?:timer|time(?:r| her| or))(?: named| called)?\s+(.+)/);
    if (can) {
      const lab = can[1].trim();
      const n = timers.length;
      for (let i = timers.length - 1; i >= 0; i--) if (timers[i].label.toLowerCase() === lab) timers.splice(i, 1);
      speakSafe(timers.length === n ? 'No timer ' + lab : 'Cancelled ' + lab);
      paint();
      afterCmd();
      return true;
    }
    if (/\b(timer|time her|time or|time of)\b/.test(t) || /^set .*\b(minute|second|hour)/.test(t)) {
      const sec = parseDuration(t);
      if (!sec) { speakSafe('Say timer, a label, and a duration. Example: timer coffee five minutes.'); afterCmd(); return true; }
      const label = parseLabel(raw);
      timers.push({ id: Date.now(), label: label, endMs: Date.now() + sec * 1000, fired: false });
      speakSafe('Timer ' + label + ' ' + sec + ' seconds.');
      paint();
      afterCmd();
      return true;
    }
    speakSafe('Clock is listening. Say analog, digital, twelve hour, twenty four hour, timer coffee five minutes, explain, or terminate.');
    afterCmd();
    return true;
  };

  window.isClockWake = function (s) {
    const t = String(s || '').toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
    return /^(please |show |open |the )?(satellite |gnss |gps )?(clock)$/.test(t) || t === 'clock';
  };

  window.openClock = function () {
    on = true;
    const sh = $('sheetClock');
    if (sh) sh.classList.add('show');
    pullClock();
    paint();
    if (!tickT) loop();
    try { if (typeof setScreen === 'function') setScreen('CLOCK\n' + (lastClock.locked ? 'GNSS UTC locked' : 'Device clock until GNSS lock') + '\nSay analog, digital, twelve hour, twenty four hour, timer, explain, terminate.'); } catch (e) {}
    speakSafe(lastClock.locked ? 'Satellite clock online. Say a command.' : 'Clock online. Waiting for GNSS lock. Device time shown. Say a command.');
    afterCmd();
  };

  function closeClock() {
    const was = on;
    on = false;
    const sh = $('sheetClock');
    if (sh) sh.classList.remove('show');
    if (tickT) { clearTimeout(tickT); tickT = 0; }
    if (was) speakSafe('Clock closed.');
  }
  window.closeClock = closeClock;
})();
