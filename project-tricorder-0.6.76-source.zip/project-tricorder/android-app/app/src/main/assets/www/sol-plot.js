/* SOL SYSTEM — press 1 space, 2 earth, 3 moon, 4 sun, 5 luna rise/set, 6 off */
(function () {
  const PLANETS = [
    { name: 'Mercury', a: 0.387, p: 87.969, L0: 252.25, col: '#b8b0a0' },
    { name: 'Venus', a: 0.723, p: 224.701, L0: 181.98, col: '#e8c98a' },
    { name: 'Earth', a: 1.000, p: 365.256, L0: 100.46, col: '#6ec8ff' },
    { name: 'Mars', a: 1.524, p: 686.980, L0: 355.45, col: '#ff6b4a' },
    { name: 'Jupiter', a: 5.203, p: 4332.59, L0: 34.40, col: '#d4a574' },
    { name: 'Saturn', a: 9.537, p: 10759.2, L0: 50.00, col: '#e6d9a8' },
  ];
  const GROUPS = [
    ['80m-40m', '80 / 40'],
    ['30m-20m', '30 / 20'],
    ['17m-15m', '17 / 15'],
    ['12m-10m', '12 / 10'],
  ];
  let mode = 'off';
  let snap = null;
  let raf = 0;

  function $(id) { return document.getElementById(id); }
  function loadSnap() {
    try {
      const raw = window.TricorderNative && TricorderNative.solSnapshot && TricorderNative.solSnapshot();
      snap = raw ? JSON.parse(raw) : null;
    } catch { snap = null; }
    return snap;
  }
  function daysJ2000(d) { return (d.getTime() / 86400000) - 10957.5; }
  function lonDeg(pl, date) {
    return ((pl.L0 + (360 / pl.p) * daysJ2000(date)) % 360 + 360) % 360;
  }
  function band(ham, name, time) {
    const b = (ham && ham.bands) || {};
    return b[name + '_' + time] || b[name.split('-')[0] + '_' + time] || '—';
  }
  function kpNum(ham, kp) {
    const v = parseFloat((ham && ham.kindex) || (kp && (kp.kp_index || kp.estimated_kp)) || 'NaN');
    return isFinite(v) ? v : 0;
  }
  function uhfLine(ham, kp) {
    const k = kpNum(ham, kp);
    if (k >= 7) return 'UHF aurora  scintillation likely';
    if (k >= 5) return 'UHF aurora  possible scintillation';
    return 'UHF aurora  quiet / line of sight';
  }

  const PHASES = [
    'New Moon', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous',
    'Full Moon', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent',
  ];
  function moonState(date) {
    const syn = 29.530588853;
    const known = Date.UTC(2000, 0, 6, 18, 14, 0);
    let age = ((date.getTime() - known) / 86400000) % syn;
    if (age < 0) age += syn;
    const slice = syn / 8;
    const idx = Math.min(7, Math.floor(age / slice + 0.5) % 8);
    // nearest-center index: use floor of age/slice for "current phase window"
    const win = Math.min(7, Math.floor(age / slice));
    const into = age - win * slice;
    const left = slice - into;
    const prev = PHASES[(win + 7) % 8];
    const next = PHASES[(win + 1) % 8];
    const illum = (1 - Math.cos(2 * Math.PI * age / syn)) / 2;
    return { age, syn, slice, win, name: PHASES[win], prev, next, into, left, illum };
  }
  function moonLine() {
    const m = moonState(new Date());
    return m.name + '  ' + Math.round(m.illum * 100) + '% lit  next ' + m.next + ' in ' + m.left.toFixed(1) + ' d';
  }
  function moonBrief() {
    const m = moonState(new Date());
    return ('Moon phase ' + m.name +
      ' Illumination ' + Math.round(m.illum * 100) + ' percent' +
      ' Age ' + m.age.toFixed(1) + ' days of ' + m.syn.toFixed(2) +
      ' This phase lasts about ' + m.slice.toFixed(2) + ' days' +
      ' ' + m.into.toFixed(1) + ' days into it' +
      ' ' + m.left.toFixed(1) + ' days remain' +
      ' Phase just ended ' + m.prev +
      ' Next phase ' + m.next).replace(/\./g, ' ');
  }
  function paintMoon(ctx, w, h) {
    const m = moonState(new Date());
    ctx.fillStyle = '#05080f';
    ctx.fillRect(0, 0, w, h);
    const cx = w * 0.28, cy = h * 0.46, r = Math.min(w, h) * 0.22;
    ctx.fillStyle = '#d8c9a0';
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#05080f';
    const phase = (m.age / m.syn);
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, r + 1, 0, Math.PI * 2); ctx.clip();
    if (phase <= 0.5) {
      const k = 1 - phase * 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, Math.abs(k) * r, r, 0, -Math.PI / 2, Math.PI / 2, k < 0);
      ctx.rect(cx - r, cy - r, r, 2 * r);
      ctx.fill();
    } else {
      const k = (phase - 0.5) * 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, k * r, r, 0, Math.PI / 2, 3 * Math.PI / 2, false);
      ctx.rect(cx, cy - r, r, 2 * r);
      ctx.fill();
    }
    ctx.restore();
    ctx.strokeStyle = '#7dffb0';
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.font = '11px "IBM Plex Mono", monospace';
    const x = w * 0.52;
    let y = 22;
    const line = (t, col) => { ctx.fillStyle = col || '#d8ffe8'; ctx.fillText(String(t).slice(0, 42), x, y); y += 14; };
    line('MOON PHASE', '#7dffb0');
    line(m.name, '#ffb454');
    line(Math.round(m.illum * 100) + '% illuminated');
    line('age ' + m.age.toFixed(1) + ' d  /  ' + m.syn.toFixed(2) + ' d');
    line('this phase ~' + m.slice.toFixed(2) + ' d');
    line(m.into.toFixed(1) + ' d in   ' + m.left.toFixed(1) + ' d left');
    line('ended  ' + m.prev);
    line('next   ' + m.next);
  }

  function sind(d) { return Math.sin(d * Math.PI / 180); }
  function cosd(d) { return Math.cos(d * Math.PI / 180); }
  function siteFix() {
    try {
      if (window.navState && navState.lastFix && isFinite(navState.lastFix.lat)) return navState.lastFix;
    } catch {}
    try {
      if (window.TricorderNative && TricorderNative.placeNow) {
        const o = JSON.parse(TricorderNative.placeNow() || '{}');
        if (isFinite(Number(o.lat)) && isFinite(Number(o.lon))) return { lat: Number(o.lat), lon: Number(o.lon) };
      }
    } catch {}
    return null;
  }
  function julianDate(d) { return d.getTime() / 86400000 + 2440587.5; }
  function dateFromJulian(j) { return new Date((j - 2440587.5) * 86400000); }
  function sunTimes(lat, lon, date) {
    // NOAA / Wikipedia sunrise equation.
    // GPS lon is east-positive. Formula wants longitude west-positive.
    const lw = -Number(lon);
    const localNoon = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 12, 0, 0, 0);
    const J = julianDate(localNoon);
    const n = Math.round(J - 2451545.0009 - lw / 360);
    const Jstar = 2451545.0009 + n + lw / 360;
    const M = ((357.5291 + 0.98560028 * (Jstar - 2451545)) % 360 + 360) % 360;
    const C = 1.9148 * sind(M) + 0.02 * sind(2 * M) + 0.0003 * sind(3 * M);
    const lambda = ((M + 102.9372 + C + 180) % 360 + 360) % 360;
    const Jtransit = Jstar + 0.0053 * sind(M) - 0.0069 * sind(2 * lambda);
    const delta = Math.asin(Math.sin(lambda * Math.PI / 180) * Math.sin(23.4397 * Math.PI / 180));
    const phi = Number(lat) * Math.PI / 180;
    const arg = (Math.sin(-0.833 * Math.PI / 180) - Math.sin(phi) * Math.sin(delta)) / (Math.cos(phi) * Math.cos(delta));
    if (arg <= -1) return { polar: 'up', transit: dateFromJulian(Jtransit) };
    if (arg >= 1) return { polar: 'down', transit: dateFromJulian(Jtransit) };
    const w0 = Math.acos(Math.max(-1, Math.min(1, arg)));
    const Jrise = Jtransit - w0 / (2 * Math.PI);
    const Jset = Jtransit + w0 / (2 * Math.PI);
    return {
      polar: null,
      rise: dateFromJulian(Jrise),
      set: dateFromJulian(Jset),
      transit: dateFromJulian(Jtransit),
      hours: (Jset - Jrise) * 24,
    };
  }
  function fmtClock(d) {
    if (!d) return '—';
    try {
      return d.toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit', hour12: true, timeZoneName: 'short' });
    } catch {
      return d.toLocaleTimeString();
    }
  }
  function sunLine() {
    const fix = siteFix();
    if (!fix) return 'SUN  no GPS yet';
    const s = sunTimes(fix.lat, fix.lon, new Date());
    if (s.polar === 'up') return 'SUN  polar day — no set';
    if (s.polar === 'down') return 'SUN  polar night — no rise';
    return 'SUN  rise ' + fmtClock(s.rise) + '  set ' + fmtClock(s.set) + '  ' + s.hours.toFixed(1) + ' h light';
  }
  function sunBrief() {
    const fix = siteFix();
    if (!fix) return 'Sunrise and sunset need a GPS fix';
    const s = sunTimes(fix.lat, fix.lon, new Date());
    if (s.polar === 'up') return 'Polar day at this latitude The sun does not set';
    if (s.polar === 'down') return 'Polar night at this latitude The sun does not rise';
    return ('Sunrise ' + fmtClock(s.rise) + ' Sunset ' + fmtClock(s.set) +
      ' Daylight ' + s.hours.toFixed(1) + ' hours Solar noon ' + fmtClock(s.transit) +
      ' From last GPS ' + fix.lat.toFixed(3) + ' ' + fix.lon.toFixed(3)).replace(/\./g, ' ');
  }
  function paintSunDisc(ctx, cx, cy, r, sinking) {
    const grd = ctx.createRadialGradient(cx - r * 0.3, cy - r * 0.3, r * 0.1, cx, cy, r);
    if (sinking) {
      grd.addColorStop(0, '#fff3c4');
      grd.addColorStop(0.45, '#ff8a3d');
      grd.addColorStop(1, '#c42812');
    } else {
      grd.addColorStop(0, '#fffbe6');
      grd.addColorStop(0.4, '#ffd36a');
      grd.addColorStop(1, '#ff9a1f');
    }
    ctx.fillStyle = grd;
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = sinking ? '#ffb08a' : '#ffe7a0';
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 12; i++) {
      const a = i * Math.PI / 6;
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(a) * (r + 3), cy + Math.sin(a) * (r + 3));
      ctx.lineTo(cx + Math.cos(a) * (r + 11), cy + Math.sin(a) * (r + 11));
      ctx.stroke();
    }
  }
  function paintSun(ctx, w, h) {
    const fix = siteFix();
    const now = new Date();
    const s = fix ? sunTimes(fix.lat, fix.lon, now) : null;
    ctx.fillStyle = '#05080f';
    ctx.fillRect(0, 0, w, h);
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, '#1a2a4a');
    sky.addColorStop(0.45, '#c45a2a');
    sky.addColorStop(0.72, '#6a2a18');
    sky.addColorStop(1, '#0a120d');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h * 0.62);
    ctx.fillStyle = '#0d1712';
    ctx.fillRect(0, h * 0.58, w, h * 0.42);
    ctx.strokeStyle = '#3f8a63';
    ctx.beginPath(); ctx.moveTo(8, h * 0.58); ctx.lineTo(w - 8, h * 0.58); ctx.stroke();
    const yH = h * 0.58;
    paintSunDisc(ctx, w * 0.22, yH - 18, 22, false);
    paintSunDisc(ctx, w * 0.22, yH + 10, 22, true);
    ctx.fillStyle = '#0d1712';
    ctx.fillRect(w * 0.22 - 28, yH + 2, 56, 40);
    ctx.font = '11px "IBM Plex Mono", monospace';
    const x = w * 0.42;
    let y = 22;
    const line = (t, col) => { ctx.fillStyle = col || '#d8ffe8'; ctx.fillText(String(t).slice(0, 44), x, y); y += 14; };
    line('SUNRISE / SUNSET', '#7dffb0');
    if (!fix || !s) {
      line('waiting for GPS', '#ffb454');
      line('last fix not yet on file');
      return;
    }
    line(fix.lat.toFixed(4) + '  ' + fix.lon.toFixed(4), '#9fe8bf');
    if (s.polar === 'up') { line('polar day — sun does not set', '#ffb454'); return; }
    if (s.polar === 'down') { line('polar night — sun does not rise', '#ffb454'); return; }
    line('RISE   ' + fmtClock(s.rise), '#ffd36a');
    line('NOON   ' + fmtClock(s.transit), '#ffe7a0');
    line('SET    ' + fmtClock(s.set), '#ff8a3d');
    line('LIGHT  ' + s.hours.toFixed(2) + ' hours');
    const nowMs = now.getTime();
    if (nowMs < s.rise.getTime()) line('next event  sunrise', '#7dffb0');
    else if (nowMs < s.set.getTime()) line('next event  sunset', '#ffb454');
    else line('sun is down', '#9fe8bf');
    line('NOAA sunrise equation', '#3f8a63');
  }

  function moonGeom(date) {
    const d = (date.getTime() - Date.UTC(2000, 0, 1, 12, 0, 0)) / 86400000;
    const wrap = (x) => ((x % 360) + 360) % 360;
    const L = wrap(218.316 + 13.176396 * d);
    const M = wrap(134.963 + 13.064993 * d);
    const F = wrap(93.272 + 13.229350 * d);
    const D = wrap(297.850 + 12.190749 * d);
    const lonE = L + 6.289 * sind(M) + 1.274 * sind(2 * D - M) + 0.658 * sind(2 * D) + 0.214 * sind(2 * M);
    const latE = 5.128 * sind(F) + 0.280 * sind(M + F) + 0.277 * sind(M - F);
    const dist = 385001 - 20905 * cosd(M) - 3699 * cosd(2 * D - M) - 2956 * cosd(2 * D);
    const eps = 23.4397 - 0.0000004 * d;
    const ra = Math.atan2(sind(lonE) * cosd(eps) - Math.tan(latE * Math.PI / 180) * sind(eps), cosd(lonE)) * 180 / Math.PI;
    const dec = Math.asin(Math.max(-1, Math.min(1, sind(latE) * cosd(eps) + cosd(latE) * sind(eps) * sind(lonE)))) * 180 / Math.PI;
    const gmst = wrap(280.46061837 + 360.98564736629 * d);
    return { d: d, ra: ra, dec: dec, dist: dist, gmst: gmst };
  }
  function moonAppAlt(lat, lon, date) {
    const g = moonGeom(date);
    const lst = ((g.gmst + lon) % 360 + 360) % 360;
    let ha = lst - g.ra;
    ha = ((ha + 540) % 360) - 180;
    const alt = Math.asin(Math.max(-1, Math.min(1, sind(lat) * sind(g.dec) + cosd(lat) * cosd(g.dec) * cosd(ha)))) * 180 / Math.PI;
    const hp = Math.asin(Math.min(0.99, 6378.14 / g.dist)) * 180 / Math.PI;
    return alt - hp * cosd(Math.max(-89, Math.min(89, alt)));
  }
  function moonTimes(lat, lon, date) {
    const start = new Date(date.getFullYear(), date.getMonth(), date.getDate(), 0, 0, 0, 0);
    const HOR = -0.57;
    const step = 2 * 60 * 1000;
    let rise = null, set = null;
    let prevA = moonAppAlt(lat, lon, start);
    let prevT = start.getTime();
    for (let i = 1; i <= 24 * 30; i++) {
      const t = new Date(start.getTime() + i * step);
      const a = moonAppAlt(lat, lon, t);
      if (prevA < HOR && a >= HOR && !rise) {
        const f = (HOR - prevA) / (a - prevA || 1);
        rise = new Date(prevT + f * step);
      }
      if (prevA > HOR && a <= HOR && !set) {
        const f = (prevA - HOR) / (prevA - a || 1);
        set = new Date(prevT + f * step);
      }
      prevA = a;
      prevT = t.getTime();
    }
    const nowAlt = moonAppAlt(lat, lon, date);
    return {
      rise: rise,
      set: set,
      riseAz: rise ? moonAz(lat, lon, rise) : null,
      setAz: set ? moonAz(lat, lon, set) : null,
      up: nowAlt >= HOR,
      alt: nowAlt,
    };
  }
  function moonAz(lat, lon, date) {
    const g = moonGeom(date);
    const lst = ((g.gmst + lon) % 360 + 360) % 360;
    let ha = ((lst - g.ra + 540) % 360) - 180;
    let az = Math.atan2(
      -cosd(g.dec) * sind(ha),
      sind(g.dec) * cosd(lat) - cosd(g.dec) * sind(lat) * cosd(ha),
    ) * 180 / Math.PI;
    return ((az % 360) + 360) % 360;
  }
  function fmtAz(az) {
    if (az == null || !isFinite(az)) return '';
    const pts = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    const i = Math.round(az / 45) % 8;
    return Math.round(az) + '° ' + pts[i];
  }
  function azWords(az) {
    if (az == null || !isFinite(az)) return '';
    const pts = ['north', 'northeast', 'east', 'southeast', 'south', 'southwest', 'west', 'northwest'];
    const i = Math.round(az / 45) % 8;
    return Math.round(az) + ' degrees ' + pts[i];
  }
  function lunaLine() {
    const fix = siteFix();
    if (!fix) return 'LUNA  no GPS yet';
    const t = moonTimes(fix.lat, fix.lon, new Date());
    const bits = [];
    if (t.set) bits.push('set ' + fmtClock(t.set) + ' ' + fmtAz(t.setAz));
    if (t.rise) bits.push('rise ' + fmtClock(t.rise) + ' ' + fmtAz(t.riseAz));
    if (!bits.length) bits.push(t.up ? 'above all day' : 'below all day');
    return 'LUNA  ' + bits.join('  ');
  }
  function lunaBrief() {
    const fix = siteFix();
    if (!fix) return 'Moonrise and moonset need a GPS fix';
    const t = moonTimes(fix.lat, fix.lon, new Date());
    const m = moonState(new Date());
    let s = 'Moon ' + m.name + ' ';
    if (t.set) s += 'Moonset ' + fmtClock(t.set) + ' heading ' + azWords(t.setAz) + ' ';
    if (t.rise) s += 'Moonrise ' + fmtClock(t.rise) + ' heading ' + azWords(t.riseAz) + ' ';
    s += 'Times approximate plus or minus three minutes ';
    if (!t.rise && !t.set) s += t.up ? 'Moon stays up all day ' : 'Moon stays down all day ';
    s += t.up ? 'Moon is up now' : 'Moon is down now';
    return s.replace(/\./g, ' ');
  }
  function paintLunaDisc(ctx, cx, cy, r, sinking) {
    ctx.fillStyle = sinking ? '#c8b894' : '#e8dcc0';
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = sinking ? '#05080f' : '#05080f';
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, r + 1, 0, Math.PI * 2); ctx.clip();
    const k = sinking ? 0.35 : -0.15;
    ctx.beginPath();
    ctx.ellipse(cx + k * r, cy, r * 0.92, r, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = '#d8c9a0';
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
  }
  function paintLuna(ctx, w, h) {
    const fix = siteFix();
    const now = new Date();
    ctx.fillStyle = '#05080f';
    ctx.fillRect(0, 0, w, h);
    const sky = ctx.createLinearGradient(0, 0, 0, h);
    sky.addColorStop(0, '#070b18');
    sky.addColorStop(0.5, '#1a2240');
    sky.addColorStop(0.7, '#3a2a18');
    sky.addColorStop(1, '#0a120d');
    ctx.fillStyle = sky;
    ctx.fillRect(0, 0, w, h * 0.62);
    ctx.fillStyle = '#0d1712';
    ctx.fillRect(0, h * 0.58, w, h * 0.42);
    ctx.strokeStyle = '#3f8a63';
    ctx.beginPath(); ctx.moveTo(8, h * 0.58); ctx.lineTo(w - 8, h * 0.58); ctx.stroke();
    const yH = h * 0.58;
    paintLunaDisc(ctx, w * 0.22, yH - 16, 20, false);
    paintLunaDisc(ctx, w * 0.22, yH + 12, 20, true);
    ctx.fillStyle = '#0d1712';
    ctx.fillRect(w * 0.22 - 26, yH + 2, 52, 40);
    ctx.font = '11px "IBM Plex Mono", monospace';
    const x = w * 0.42;
    let y = 22;
    const line = (t, col) => { ctx.fillStyle = col || '#d8ffe8'; ctx.fillText(String(t).slice(0, 44), x, y); y += 14; };
    line('MOONRISE / MOONSET', '#7dffb0');
    if (!fix) { line('waiting for GPS', '#ffb454'); return; }
    const t = moonTimes(fix.lat, fix.lon, now);
    const m = moonState(now);
    line(fix.lat.toFixed(4) + '  ' + fix.lon.toFixed(4), '#9fe8bf');
    line(m.name + '  ' + Math.round(m.illum * 100) + '% lit', '#d8c9a0');
    if (t.set) line('SET    ' + fmtClock(t.set), '#c8b894');
    else line('SET    none today', '#ffb454');
    if (t.setAz != null) line('       hd ' + fmtAz(t.setAz), '#c8b894');
    if (t.rise) line('RISE   ' + fmtClock(t.rise), '#e8dcc0');
    else line('RISE   none today', '#ffb454');
    if (t.riseAz != null) line('       hd ' + fmtAz(t.riseAz), '#e8dcc0');
    line(t.up ? 'Moon is UP now' : 'Moon is DOWN now', t.up ? '#7dffb0' : '#9fe8bf');
    line('approx  ±3 min   not USNO', '#ffb454');
    paintLunaRose(ctx, 36, h - 36, 22, t.riseAz, t.setAz);
  }
  function paintLunaRose(ctx, cx, cy, rad, riseAz, setAz) {
    ctx.save();
    ctx.strokeStyle = '#3f8a63';
    ctx.beginPath(); ctx.arc(cx, cy, rad, 0, Math.PI * 2); ctx.stroke();
    ctx.fillStyle = '#7dffb0';
    ctx.font = '8px "IBM Plex Mono", monospace';
    ctx.textAlign = 'center';
    ctx.fillText('N', cx, cy - rad - 3);
    function tick(az, col, lab) {
      if (az == null || !isFinite(az)) return;
      const a = (az - 90) * Math.PI / 180;
      ctx.strokeStyle = col;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      ctx.lineTo(cx + Math.cos(a) * rad, cy + Math.sin(a) * rad);
      ctx.stroke();
      ctx.fillStyle = col;
      ctx.fillText(lab, cx + Math.cos(a) * (rad + 9), cy + Math.sin(a) * (rad + 9) + 3);
    }
    tick(riseAz, '#e8dcc0', 'R');
    tick(setAz, '#c8b894', 'S');
    ctx.restore();
  }

  function briefing() {
    const s = snap || {};
    const ham = s.ham || {};
    const earth = s.earth || {};
    if (mode === 'moon') return moonBrief();
    if (mode === 'luna') return lunaBrief();
    if (mode === 'sun') return sunBrief();
    if (mode === 'earth') {
      const city = earth.city || 'this site';
      const hours = (earth.hourly || []).slice(0, 6).map((p) => {
        const hh = String(p.t || '').slice(11, 16);
        return hh + ' ' + p.temp + (p.unit || '') + ' ' + p.wx;
      }).join(' ');
      const days = (earth.outlook || []).slice(0, 6).map((p) => (p.name || '') + ' ' + (p.wx || '')).join(' ');
      return ('Earth weather at ' + city + ' Next hours ' + hours + ' Outlook ' + days).replace(/\./g, ' ');
    }
    const hf = GROUPS.map((g) => g[1] + ' day ' + band(ham, g[0], 'day') + ' night ' + band(ham, g[0], 'night')).join(' ');
    return ('Sol system Solar flux ' + (ham.solarflux || '—') + ' sunspots ' + (ham.sunspots || '—')
      + ' K index ' + (ham.kindex || '—') + ' X ray ' + (ham.xray || '—')
      + ' HF ' + hf + ' VHF aurora ' + (ham.vhfaurora || '—') + ' ' + uhfLine(ham, s.kp_latest)).replace(/\./g, ' ');
  }

  function drawOrbits(ctx, w, h) {
    const cx = w * 0.28, cy = h * 0.52, maxR = Math.min(w * 0.26, h * 0.44);
    const now = new Date();
    ctx.fillStyle = '#ffcc66';
    ctx.beginPath(); ctx.arc(cx, cy, 7, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffb454';
    ctx.font = '9px "IBM Plex Mono", monospace';
    ctx.fillText('SOL', cx - 8, cy + 18);
    PLANETS.forEach((pl) => {
      const r = 12 + (pl.a / 9.6) * (maxR - 12);
      ctx.strokeStyle = '#1c4a33';
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      const th = lonDeg(pl, now) * Math.PI / 180;
      const x = cx + Math.cos(th) * r;
      const y = cy + Math.sin(th) * r;
      ctx.fillStyle = pl.col;
      ctx.beginPath(); ctx.arc(x, y, (pl.name === 'Jupiter' || pl.name === 'Saturn') ? 4 : 2.6, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#9ad4b0';
      ctx.fillText(pl.name[0], x + 5, y - 3);
    });
  }

  function paintSpace(ctx, w, h) {
    drawOrbits(ctx, w, h);
    const s = snap || {};
    const ham = s.ham || {};
    const kp = s.kp_latest || {};
    ctx.font = '10px "IBM Plex Mono", monospace';
    const x = w * 0.52;
    let y = 14;
    const line = (t, col) => { ctx.fillStyle = col || '#d8ffe8'; ctx.fillText(String(t).slice(0, 44), x, y); y += 13; };
    line('SOL CYCLE / SPACE WX  NOAA SWPC', '#7dffb0');
    line('SFI ' + (ham.solarflux || '—') + '  SSN ' + (ham.sunspots || '—') + '  A ' + (ham.aindex || '—'));
    line('Kp ' + (ham.kindex || kp.kp_index || '—') + '  Bz ' + (ham.magneticfield || '—') + '  wind ' + (ham.solarwind || '—'));
    line('X-ray ' + (ham.xray || '—') + '  aurora ' + (ham.aurora || '—'));
    y += 4;
    line('HF PROPAGATION  HamQSL', '#ffb454');
    GROUPS.forEach((g) => {
      line(g[1] + '  day ' + band(ham, g[0], 'day') + '   night ' + band(ham, g[0], 'night'));
    });
    y += 4;
    line('VHF aurora  ' + (ham.vhfaurora || '—'), '#6ec8ff');
    line(uhfLine(ham, kp), '#6ec8ff');
    line('geomag ' + (ham.geomagfield || '—') + '  S/N ' + (ham.signalnoise || '—'));
    if (!s.at) line('No snapshot — Fetch SOL wx', '#ffb454');
  }

  function fillEarth() {
    const box = $('solEarth');
    if (!box) return;
    const s = snap || {};
    const earth = s.earth || {};
    const lines = [];
    lines.push('EARTH WEATHER  NWS');
    lines.push((earth.city || '') + '  office ' + (earth.office || ''));
    lines.push('');
    lines.push('Next six hours');
    (earth.hourly || []).slice(0, 6).forEach((p) => {
      const hh = String(p.t || '').slice(11, 16);
      lines.push(hh + '   ' + p.temp + (p.unit || '') + '   ' + (p.wind || '') + '   ' + (p.wx || ''));
    });
    lines.push('');
    lines.push('Today + next 2 days');
    (earth.outlook || []).slice(0, 6).forEach((p) => {
      lines.push((p.name || '') + '  ' + p.temp + '  ' + (p.wx || ''));
      if (p.detail) lines.push('  ' + p.detail);
    });
    if (!earth.hourly) lines.push('No NWS snapshot — Fetch SOL wx');
    box.textContent = lines.join('\n');
  }

  function tick() {
    if (mode === 'off') { raf = 0; return; }
    const c = $('solCanvas');
    if (!c) return;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#05080f';
    ctx.fillRect(0, 0, c.width, c.height);
    if (mode === 'space') paintSpace(ctx, c.width, c.height);
    if (mode === 'moon') paintMoon(ctx, c.width, c.height);
    if (mode === 'sun') paintSun(ctx, c.width, c.height);
    if (mode === 'luna') paintLuna(ctx, c.width, c.height);
    raf = requestAnimationFrame(tick);
  }

  function paintButton() {
    const b = $('solBtn');
    const lab = $('solModeLbl');
    if (b) {
      b.classList.toggle('horizon-on', mode !== 'off');
      b.classList.toggle('horizon-off', mode === 'off');
    }
    if (lab) {
      lab.textContent = ({ off: 'off', space: 'sol', earth: 'wx', moon: 'moon', sun: 'sun', luna: 'luna' })[mode] || mode;
    }
  }

  function cycle() {
    if (mode === 'off') mode = 'space';
    else if (mode === 'space') mode = 'earth';
    else if (mode === 'earth') mode = 'moon';
    else if (mode === 'moon') mode = 'sun';
    else if (mode === 'sun') mode = 'luna';
    else mode = 'off';
    loadSnap();
    const c = $('solCanvas');
    const bar = $('solBar');
    const earth = $('solEarth');
    if (c) c.style.display = (mode === 'space' || mode === 'moon' || mode === 'sun' || mode === 'luna') ? 'block' : 'none';
    if (earth) earth.style.display = mode === 'earth' ? 'block' : 'none';
    if (bar) bar.style.display = mode === 'off' ? 'none' : 'flex';
    if (mode === 'earth') fillEarth();
    paintButton();
    if (typeof setScreen === 'function') {
      if (mode === 'space') setScreen('SOL SYSTEM\norbits + space weather + HF/VHF/UHF');
      else if (mode === 'earth') setScreen('EARTH WEATHER\nsix hours + today and next two days');
      else if (mode === 'moon') setScreen('MOON PHASE\n' + moonLine());
      else if (mode === 'sun') setScreen('SUNRISE / SUNSET\n' + sunLine());
      else if (mode === 'luna') setScreen('MOONRISE / MOONSET\n' + lunaLine());
    }
    if (mode !== 'off') {
      try { if (typeof speak === 'function') speak(briefing(), { force: true }); } catch {}
      if (!raf) tick();
    }
  }

  function wire() {
    const b = $('solBtn');
    if (b) b.addEventListener('click', cycle);
    const f = $('fetchSol');
    if (f) f.addEventListener('click', () => { try { TricorderNative.fetchSol(); } catch {} });
    paintButton();
  }
  window.__tricorderSol = (raw) => { try { snap = JSON.parse(raw); } catch { loadSnap(); } };
  window.solModeNow = () => mode;
  window.solCycle = cycle;
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire);
  else wire();
})();
