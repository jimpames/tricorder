package com.projecttricorder.app

/**
 * Minimal Meshtastic protobuf codec for TEXT_MESSAGE_APP over BLE.
 * Field numbers from meshtastic/mesh.proto (ToRadio, FromRadio, MeshPacket, Data).
 */
object MeshProto {
    const val TEXT_MESSAGE_APP = 1
    const val BROADCAST = -1 // 0xFFFFFFFF as signed fixed32

    fun wantConfig(id: Int): ByteArray = varintField(3, id.toLong() and 0xffffffffL)

    fun textToRadio(text: String, dest: Int = BROADCAST, hop: Int = 3): ByteArray {
        val payload = text.toByteArray(Charsets.UTF_8)
        val data = varintField(1, TEXT_MESSAGE_APP.toLong()) + ld(2, payload)
        val id = (System.currentTimeMillis() and 0xffffffffL).toInt()
        val pkt = f32(2, dest) + ld(4, data) + f32(6, id) + varintField(9, hop.toLong())
        return ld(1, pkt)
    }

    fun extractTexts(fromRadio: ByteArray): List<String> {
        val out = ArrayList<String>()
        parse(fromRadio).forEach { f ->
            if (f.num == 2 && f.bytes != null) {
                val pkt = parse(f.bytes)
                val decoded = pkt.firstOrNull { it.num == 4 }?.bytes ?: return@forEach
                val data = parse(decoded)
                val port = data.firstOrNull { it.num == 1 }?.varint ?: 0L
                val body = data.firstOrNull { it.num == 2 }?.bytes ?: return@forEach
                if (port.toInt() == TEXT_MESSAGE_APP) {
                    out.add(String(body, Charsets.UTF_8))
                }
            }
        }
        return out
    }

    private data class Field(val num: Int, val varint: Long? = null, val bytes: ByteArray? = null)

    private fun parse(buf: ByteArray): List<Field> {
        val out = ArrayList<Field>()
        var i = 0
        while (i < buf.size) {
            val (tag, n1) = readVarint(buf, i) ?: break
            i = n1
            val field = (tag shr 3).toInt()
            val wt = (tag and 7L).toInt()
            when (wt) {
                0 -> {
                    val (v, n2) = readVarint(buf, i) ?: break
                    i = n2
                    out.add(Field(field, varint = v))
                }
                1 -> {
                    if (i + 8 > buf.size) break
                    i += 8
                }
                2 -> {
                    val (len, n2) = readVarint(buf, i) ?: break
                    i = n2
                    val n = len.toInt().coerceAtLeast(0)
                    if (i + n > buf.size) break
                    out.add(Field(field, bytes = buf.copyOfRange(i, i + n)))
                    i += n
                }
                5 -> {
                    if (i + 4 > buf.size) break
                    i += 4
                }
                else -> break
            }
        }
        return out
    }

    private fun readVarint(buf: ByteArray, start: Int): Pair<Long, Int>? {
        var i = start
        var shift = 0
        var acc = 0L
        while (i < buf.size && shift <= 63) {
            val b = buf[i].toInt() and 0xff
            i++
            acc = acc or ((b and 0x7f).toLong() shl shift)
            if (b and 0x80 == 0) return acc to i
            shift += 7
        }
        return null
    }

    private fun uvar(v0: Long): ByteArray {
        var v = v0
        val out = ArrayList<Byte>()
        while (true) {
            var b = (v and 0x7f).toInt()
            v = v ushr 7
            if (v != 0L) b = b or 0x80
            out.add(b.toByte())
            if (v == 0L) break
        }
        return out.toByteArray()
    }

    private fun tag(field: Int, wt: Int) = uvar(((field shl 3) or wt).toLong())
    private fun ld(field: Int, data: ByteArray) = tag(field, 2) + uvar(data.size.toLong()) + data
    private fun varintField(field: Int, v: Long) = tag(field, 0) + uvar(v)
    private fun f32(field: Int, v: Int): ByteArray {
        val b = ByteArray(4)
        b[0] = (v and 0xff).toByte()
        b[1] = ((v shr 8) and 0xff).toByte()
        b[2] = ((v shr 16) and 0xff).toByte()
        b[3] = ((v shr 24) and 0xff).toByte()
        return tag(field, 5) + b
    }
}
