package com.projecttricorder.app

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothProfile
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import org.json.JSONObject
import java.util.UUID

/**
 * Meshtastic BLE bearer for T1000-E / any Meshtastic node.
 * Settings (prefs): lora_on, lora_pin, lora_region, lora_dest, lora_filter.
 */
@SuppressLint("MissingPermission")
class MeshLink(
    private val context: Context,
    private val onIncoming: (JSONObject) -> Unit,
    private val onStatus: (String) -> Unit,
) {
    @Volatile var running = false
        private set
    @Volatile var linked = false
        private set
    @Volatile var radioName = ""
        private set

    private val ui = Handler(Looper.getMainLooper())
    private var gatt: BluetoothGatt? = null
    private var toRadio: BluetoothGattCharacteristic? = null
    private var fromRadio: BluetoothGattCharacteristic? = null
    private var fromNum: BluetoothGattCharacteristic? = null
    private var scanning = false

    fun start() {
        if (!pref("lora_on", "0").equals("1") && !pref("lora_on", "0").equals("true", true)) {
            onStatus("LoRa off in settings")
            return
        }
        stop()
        running = true
        val adapter = adapter() ?: run {
            onStatus("Bluetooth off")
            return
        }
        val scanner = adapter.bluetoothLeScanner ?: run {
            onStatus("no LE scanner")
            return
        }
        scanning = true
        onStatus("LoRa scanning")
        val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SVC)).build()
        val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY).build()
        try {
            scanner.startScan(listOf(filter), settings, scanCb)
        } catch (_: Exception) {
            try { scanner.startScan(scanCb) } catch (t: Exception) { onStatus("scan fail ${t.message}") }
        }
        ui.postDelayed({
            if (scanning && gatt == null) {
                try { scanner.stopScan(scanCb) } catch (_: Exception) {}
                scanning = false
                onStatus("LoRa no radio in range")
            }
        }, 18_000)
    }

    fun stop() {
        running = false
        linked = false
        scanning = false
        try { adapter()?.bluetoothLeScanner?.stopScan(scanCb) } catch (_: Exception) {}
        try { gatt?.disconnect() } catch (_: Exception) {}
        try { gatt?.close() } catch (_: Exception) {}
        gatt = null
        toRadio = null
        fromRadio = null
        fromNum = null
        radioName = ""
        onStatus("LoRa off")
    }

    fun sendText(text: String) {
        val clip = text.trim().replace(Regex("\\s+"), " ").take(180)
        if (clip.isEmpty() || !linked) return
        val dest = parseDest(pref("lora_dest", "ffffffff"))
        val bytes = MeshProto.textToRadio(clip, dest)
        writeToRadio(bytes)
    }

    fun send(row: JSONObject) {
        val line = listOf(
            row.optString("from"),
            row.optString("source"),
            row.optString("text"),
        ).filter { it.isNotBlank() }.joinToString(" · ")
        sendText(if (line.length > 8) line else row.toString())
    }

    fun statusJson(): JSONObject = JSONObject()
        .put("running", running)
        .put("linked", linked)
        .put("radio", radioName)
        .put("on", pref("lora_on", "0"))
        .put("region", pref("lora_region", "US"))
        .put("pin", pref("lora_pin", "123456"))
        .put("dest", pref("lora_dest", "ffffffff"))
        .put("filter", pref("lora_filter", "T1000"))

    private fun pref(k: String, d: String) =
        context.getSharedPreferences("tricorder", Context.MODE_PRIVATE).getString(k, d) ?: d

    private fun adapter(): BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private val scanCb = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            if (!running || gatt != null) return
            val dev = result.device ?: return
            val name = (dev.name ?: result.scanRecord?.deviceName ?: "").trim()
            val filt = pref("lora_filter", "T1000").trim()
            val okName = filt.isBlank() ||
                name.contains(filt, true) ||
                name.contains("meshtastic", true) ||
                name.contains("sensecap", true) ||
                name.isBlank()
            if (!okName && result.scanRecord?.serviceUuids?.none { it.uuid == SVC } == true) return
            scanning = false
            try { adapter()?.bluetoothLeScanner?.stopScan(this) } catch (_: Exception) {}
            radioName = name.ifBlank { dev.address }
            onStatus("LoRa pairing $radioName")
            try {
                val pin = pref("lora_pin", "123456")
                try { dev.setPin(pin.toByteArray(Charsets.UTF_8)) } catch (_: Exception) {}
                try { dev.createBond() } catch (_: Exception) {}
            } catch (_: Exception) {}
            ui.post {
                gatt = dev.connectGatt(context, false, gattCb, BluetoothDevice.TRANSPORT_LE)
            }
        }
        override fun onScanFailed(errorCode: Int) {
            onStatus("LoRa scan error $errorCode")
        }
    }

    private val gattCb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                onStatus("LoRa GATT up")
                g.requestMtu(512)
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                linked = false
                onStatus("LoRa dropped")
                if (running) ui.postDelayed({ if (running && gatt == null) start() }, 4000)
            }
        }
        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            g.discoverServices()
        }
        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            val svc = g.getService(SVC)
            if (svc == null) {
                onStatus("LoRa service missing")
                return
            }
            toRadio = svc.getCharacteristic(TORADIO)
            fromRadio = svc.getCharacteristic(FROMRADIO)
            fromNum = svc.getCharacteristic(FROMNUM)
            val fn = fromNum
            if (fn != null) {
                g.setCharacteristicNotification(fn, true)
                val cccd = fn.getDescriptor(CCCD)
                if (cccd != null) {
                    cccd.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    g.writeDescriptor(cccd)
                } else {
                    afterNotifyReady(g)
                }
            } else {
                afterNotifyReady(g)
            }
        }
        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            afterNotifyReady(g)
        }
        override fun onCharacteristicChanged(g: BluetoothGatt, ch: BluetoothGattCharacteristic) {
            if (ch.uuid == FROMNUM) drain(g)
        }
        override fun onCharacteristicRead(g: BluetoothGatt, ch: BluetoothGattCharacteristic, status: Int) {
            if (ch.uuid == FROMRADIO) {
                val v = ch.value ?: ByteArray(0)
                if (v.isNotEmpty()) {
                    handleFromRadio(v)
                    g.readCharacteristic(fromRadio)
                }
            }
        }
        override fun onCharacteristicWrite(g: BluetoothGatt, ch: BluetoothGattCharacteristic, status: Int) {}
    }

    private fun afterNotifyReady(g: BluetoothGatt) {
        linked = toRadio != null
        if (linked) onStatus("LoRa linked ${radioName.ifBlank { "radio" }}")
        writeToRadio(MeshProto.wantConfig((System.currentTimeMillis() and 0x7fffffff).toInt()))
        ui.postDelayed({ drain(g) }, 300)
    }

    private fun drain(g: BluetoothGatt) {
        val fr = fromRadio ?: return
        try { g.readCharacteristic(fr) } catch (_: Exception) {}
    }

    private fun writeToRadio(bytes: ByteArray) {
        val g = gatt ?: return
        val ch = toRadio ?: return
        ch.value = bytes
        ch.writeType = BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        try { g.writeCharacteristic(ch) } catch (_: Exception) {}
    }

    private fun handleFromRadio(bytes: ByteArray) {
        MeshProto.extractTexts(bytes).forEach { raw ->
            val obj = try {
                JSONObject(raw)
            } catch (_: Exception) {
                JSONObject()
                    .put("kind", "context")
                    .put("source", "lora")
                    .put("from", radioName.ifBlank { "LORA" })
                    .put("text", raw)
                    .put("remote", true)
            }
            if (!obj.has("kind")) obj.put("kind", "context")
            if (!obj.has("source")) obj.put("source", "lora")
            if (!obj.has("from")) obj.put("from", radioName.ifBlank { "LORA" })
            obj.put("via", "lora")
            onIncoming(obj)
        }
    }

    private fun parseDest(s: String): Int {
        val h = s.trim().removePrefix("0x").removePrefix("0X")
        return try { (h.toLong(16) and 0xffffffffL).toInt() } catch (_: Exception) { MeshProto.BROADCAST }
    }

    companion object {
        val SVC: UUID = UUID.fromString("6ba1b218-15a8-461f-9fa8-5dcae273eafd")
        val TORADIO: UUID = UUID.fromString("f75c76d2-129e-4dad-a1dd-7866124401e7")
        val FROMRADIO: UUID = UUID.fromString("2c55e69e-4993-11ed-b878-0242ac120002")
        val FROMNUM: UUID = UUID.fromString("ed9da18c-a800-4f66-a670-aa7547e34453")
        val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")
    }
}
