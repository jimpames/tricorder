package com.projecttricorder.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.LinkedHashSet
import java.util.Locale

/**
 * Memory Alpha (Simple English Wikipedia) and MEDICAL (WikiMed / MDWiki)
 * plus city / aircraft fact cards. Online REST with a local JSON cache.
 *
 * There is no ~30 MB Simple English Wikipedia ZIM with images.
 * Current Kiwix editions (2025-11): simple-all-mini ~434 MB (images),
 * simple-all-nopic ~903 MB, WikiMed mini ~155 MB. Those are not bundled
 * or auto-fetched at init — they would stall first boot and fill storage.
 * Voice banks work immediately over earth link and cache articles locally.
 */
class KnowledgeStore(private val context: Context) {

    private val cacheDir: File
        get() = File(context.filesDir, "knowledge").also { it.mkdirs() }
    private val articleDir: File
        get() = File(cacheDir, "articles").also { it.mkdirs() }

    fun status(): JSONObject {
        val n = articleDir.listFiles()?.count { it.name.endsWith(".json") } ?: 0
        return JSONObject()
            .put("ready", true)
            .put("cached", n)
            .put("alpha", "simple.wikipedia.org REST + local cache")
            .put("medical", "mdwiki.org REST + local cache")
            .put("zim_note", "Simple English mini-with-images is ~434 MB; WikiMed mini ~155 MB. Not auto-installed.")
    }

    fun warm(onProgress: (String) -> Unit) {
        onProgress("Memory Alpha bank online — say MEMORY ALPHA")
        onProgress("MEDICAL bank online — say MEDICAL")
        onProgress("ZIM note: no 30 MB Simple English-with-images edition exists (mini is ~434 MB). REST + cache used.")
        try {
            ping("https://simple.wikipedia.org/api/rest_v1/page/summary/Earth")
            ping("https://mdwiki.org/api/rest_v1/page/summary/Fever")
        } catch (_: Exception) { }
        File(cacheDir, "warmed").writeText(System.currentTimeMillis().toString())
    }

    fun search(bank: String, query: String): JSONObject {
        val q = query.trim()
        if (q.isBlank()) return JSONObject().put("ok", false).put("error", "empty query")
        val medical = bank.equals("medical", true)
        val label = if (medical) "MEDICAL" else "MEMORY ALPHA"
        // mdwiki REST summaries are Cloudflare-blocked from the device. Use
        // mdwiki only as a title catalog; load extracts + photos from Wikipedia.
        val titles = LinkedHashSet<String>()
        if (medical) {
            titles.addAll(opensearch("https://mdwiki.org", q))
            titles.addAll(opensearch("https://en.wikipedia.org", q))
        } else {
            titles.addAll(opensearch("https://simple.wikipedia.org", q))
            if (titles.isEmpty()) titles.addAll(opensearch("https://en.wikipedia.org", q))
        }
        if (titles.isEmpty()) {
            return JSONObject()
                .put("ok", false)
                .put("bank", label)
                .put("query", q)
                .put("error", "no hits")
        }
        return assemble(label, medical, q, titles.toList())
    }

    fun cityCard(name: String): JSONObject {
        val city = name.trim()
        if (city.isBlank()) return JSONObject().put("ok", false).put("error", "empty city")
        val wiki = summary("https://en.wikipedia.org", city)
            ?: summary("https://simple.wikipedia.org", city)
            ?: JSONObject()
        val countryGuess = guessCountry(wiki)
        val country = if (countryGuess.isNotBlank()) restCountry(countryGuess) else JSONObject()
        val fact = if (countryGuess.isNotBlank()) factbookSnippet(countryGuess) else ""
        val out = JSONObject()
            .put("ok", wiki.optString("title").isNotBlank())
            .put("kind", "city")
            .put("name", wiki.optString("title", city))
            .put("extract", wiki.optString("extract"))
            .put("description", wiki.optString("description"))
            .put("thumb", wiki.optJSONObject("thumbnail")?.optString("source") ?: "")
            .put("source", wiki.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page") ?: "")
            .put("country", country)
            .put("factbook", fact)
        cacheArticle("city", city, out)
        return out
    }

    fun aircraftCard(type: String, registration: String, extra: JSONObject = JSONObject()): JSONObject {
        val titleGuess = type.ifBlank { extra.optString("manufacturer") }
        val wiki = when {
            titleGuess.isBlank() -> null
            else -> summary("https://en.wikipedia.org", titleGuess)
                ?: summary("https://simple.wikipedia.org", titleGuess)
        }
        val bits = JSONArray()
        fun card(k: String, v: String) {
            if (v.isNotBlank()) bits.put(JSONObject().put("k", k).put("v", v))
        }
        card("Registration", registration)
        card("Type", extra.optString("type").ifBlank { type })
        card("ICAO type", extra.optString("icao_type"))
        card("Manufacturer", extra.optString("manufacturer"))
        card("Owner", extra.optString("owner"))
        card("Country", extra.optString("owner_country"))
        card("Mode S", extra.optString("mode_s"))
        val extract = wiki?.optString("extract") ?: ""
        val out = JSONObject()
            .put("ok", bits.length() > 0 || extract.isNotBlank())
            .put("kind", "aircraft")
            .put("title", wiki?.optString("title")?.ifBlank { type } ?: type.ifBlank { registration })
            .put("cards", bits)
            .put("extract", extract)
            .put("description", wiki?.optString("description") ?: "")
            .put("thumb", wiki?.optJSONObject("thumbnail")?.optString("source") ?: extra.optString("photo_url"))
            .put("source", wiki?.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page") ?: "")
        cacheArticle("craft", registration.ifBlank { type }, out)
        return out
    }

    private fun assemble(label: String, medical: Boolean, q: String, titles: List<String>): JSONObject {
        val hits = JSONArray()
        titles.take(8).forEach { t ->
            hits.put(articleCard(t, medical))
        }
        val top = (0 until hits.length())
            .map { hits.optJSONObject(it) }
            .firstOrNull { it != null && it.optString("extract").isNotBlank() }
            ?: hits.optJSONObject(0)
            ?: JSONObject()
        val out = JSONObject()
            .put("ok", top.optString("extract").isNotBlank() || hits.length() > 0)
            .put("bank", label)
            .put("query", q)
            .put("title", top.optString("title", q))
            .put("extract", top.optString("extract"))
            .put("description", top.optString("description"))
            .put("thumb", top.optString("thumb"))
            .put("source", top.optString("source"))
            .put("hits", hits)
        cacheArticle(label.lowercase(Locale.US).replace(" ", "-"), q, out)
        return out
    }

    private fun articleCard(title: String, medical: Boolean): JSONObject {
        val hosts = if (medical) {
            listOf("https://en.wikipedia.org", "https://simple.wikipedia.org")
        } else {
            listOf("https://simple.wikipedia.org", "https://en.wikipedia.org")
        }
        for (host in hosts) {
            val rest = summary(host, title)
            if (rest != null && rest.optString("extract").isNotBlank()) {
                return flattenSummary(rest)
            }
            val query = queryExtract(host, title)
            if (query != null && query.optString("extract").isNotBlank()) return query
        }
        return JSONObject().put("title", title).put("extract", "").put("thumb", "")
    }

    private fun flattenSummary(o: JSONObject): JSONObject {
        return JSONObject()
            .put("title", o.optString("title"))
            .put("extract", o.optString("extract"))
            .put("description", o.optString("description"))
            .put("thumb", o.optJSONObject("thumbnail")?.optString("source") ?: "")
            .put("source", o.optJSONObject("content_urls")?.optJSONObject("desktop")?.optString("page") ?: "")
    }

    private fun queryExtract(host: String, title: String): JSONObject? {
        val enc = URLEncoder.encode(title, "UTF-8")
        val url = "$host/w/api.php?action=query&redirects=1&format=json" +
            "&prop=extracts|pageimages|description&exintro=1&explaintext=1&pithumbsize=400" +
            "&titles=$enc"
        val body = httpGet(url) ?: return null
        return try {
            val pages = JSONObject(body).optJSONObject("query")?.optJSONObject("pages") ?: return null
            val keys = pages.keys()
            if (!keys.hasNext()) return null
            val page = pages.optJSONObject(keys.next()) ?: return null
            if (page.has("missing")) return null
            val extract = page.optString("extract")
            if (extract.isBlank()) return null
            JSONObject()
                .put("title", page.optString("title", title))
                .put("extract", extract)
                .put("description", page.optString("description"))
                .put("thumb", page.optJSONObject("thumbnail")?.optString("source") ?: "")
                .put("source", "$host/wiki/" + URLEncoder.encode(page.optString("title", title).replace(' ', '_'), "UTF-8"))
        } catch (_: Exception) {
            null
        }
    }

    private fun opensearch(host: String, q: String): List<String> {
        val enc = URLEncoder.encode(q, "UTF-8")
        val url = "$host/w/api.php?action=opensearch&search=$enc&limit=8&namespace=0&format=json"
        val body = httpGet(url) ?: return emptyList()
        return try {
            val arr = JSONArray(body)
            val titles = arr.optJSONArray(1) ?: JSONArray()
            (0 until titles.length()).map { titles.optString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun summary(host: String, title: String): JSONObject? {
        val enc = URLEncoder.encode(title.replace(' ', '_'), "UTF-8")
        val body = httpGet("$host/api/rest_v1/page/summary/$enc") ?: return null
        return try {
            val o = JSONObject(body)
            if (o.optString("type") == "https://mediawiki.org/wiki/HyperSwitch/errors/not_found") null else o
        } catch (_: Exception) {
            null
        }
    }

    private fun restCountry(name: String): JSONObject {
        val enc = URLEncoder.encode(name, "UTF-8")
        val body = httpGet("https://restcountries.com/v3.1/name/$enc?fields=name,capital,region,subregion,population,currencies,languages,flags")
            ?: return JSONObject()
        return try {
            val arr = JSONArray(body)
            val c = arr.optJSONObject(0) ?: return JSONObject()
            val currencies = c.optJSONObject("currencies")
            val cur = currencies?.keys()?.asSequence()?.firstOrNull() ?: ""
            val langs = c.optJSONObject("languages")
            val lang = langs?.keys()?.asSequence()?.map { langs.optString(it) }?.joinToString(", ") ?: ""
            JSONObject()
                .put("name", c.optJSONObject("name")?.optString("common") ?: name)
                .put("capital", c.optJSONArray("capital")?.optString(0) ?: "")
                .put("region", listOf(c.optString("region"), c.optString("subregion")).filter { it.isNotBlank() }.joinToString(" / "))
                .put("population", c.optLong("population"))
                .put("currency", cur)
                .put("languages", lang)
                .put("flag", c.optJSONObject("flags")?.optString("png") ?: "")
        } catch (_: Exception) {
            JSONObject()
        }
    }

    private fun factbookSnippet(country: String): String {
        val code = gec[country.lowercase(Locale.US)] ?: return ""
        val (region, id) = code
        val body = httpGet("https://raw.githubusercontent.com/factbook/factbook.json/master/$region/$id.json") ?: return ""
        return try {
            val o = JSONObject(body)
            val intro = o.optJSONObject("Introduction")?.optJSONObject("Background")?.optString("text") ?: ""
            val geo = o.optJSONObject("Geography")?.optJSONObject("Location")?.optString("text") ?: ""
            listOf(geo, intro.take(420)).filter { it.isNotBlank() }.joinToString(" ")
        } catch (_: Exception) {
            ""
        }
    }

    private fun guessCountry(wiki: JSONObject): String {
        val desc = (wiki.optString("description") + " " + wiki.optString("extract")).lowercase(Locale.US)
        gec.keys.forEach { name ->
            if (desc.contains(name)) return name
        }
        val m = Regex("(?:city|capital|town) (?:in|of) ([A-Z][A-Za-z ]+)").find(wiki.optString("extract"))
        return m?.groupValues?.getOrNull(1)?.trim() ?: ""
    }

    private fun cacheArticle(bank: String, key: String, obj: JSONObject) {
        try {
            val safe = key.lowercase(Locale.US).replace(Regex("[^a-z0-9]+"), "-").take(48)
            File(articleDir, "$bank-$safe.json").writeText(obj.toString())
        } catch (_: Exception) { }
    }

    private fun ping(url: String) { httpGet(url) }

    private fun httpGet(url: String): String? {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        return try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode !in 200..299) return null
            val text = conn.inputStream.bufferedReader().use { it.readText() }
            if (text.trimStart().startsWith("<")) return null
            text
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        private const val UA = "ProjectTricorder/0.6.26 (field instrument; +https://github.com/project-tricorder)"
        // CIA World Factbook GEC codes used by factbook.json
        private val gec = mapOf(
            "united states" to ("north-america" to "us"),
            "usa" to ("north-america" to "us"),
            "canada" to ("north-america" to "ca"),
            "mexico" to ("north-america" to "mx"),
            "united kingdom" to ("europe" to "uk"),
            "england" to ("europe" to "uk"),
            "france" to ("europe" to "fr"),
            "germany" to ("europe" to "gm"),
            "spain" to ("europe" to "sp"),
            "italy" to ("europe" to "it"),
            "netherlands" to ("europe" to "nl"),
            "ireland" to ("europe" to "ei"),
            "switzerland" to ("europe" to "sz"),
            "sweden" to ("europe" to "sw"),
            "norway" to ("europe" to "no"),
            "denmark" to ("europe" to "da"),
            "poland" to ("europe" to "pl"),
            "portugal" to ("europe" to "po"),
            "greece" to ("europe" to "gr"),
            "turkey" to ("middle-east" to "tu"),
            "japan" to ("east-n-southeast-asia" to "ja"),
            "china" to ("east-n-southeast-asia" to "ch"),
            "south korea" to ("east-n-southeast-asia" to "ks"),
            "india" to ("south-asia" to "in"),
            "australia" to ("australia-oceania" to "as"),
            "new zealand" to ("australia-oceania" to "nz"),
            "brazil" to ("south-america" to "br"),
            "argentina" to ("south-america" to "ar"),
            "chile" to ("south-america" to "ci"),
            "colombia" to ("south-america" to "co"),
            "peru" to ("south-america" to "pe"),
            "south africa" to ("africa" to "sf"),
            "egypt" to ("africa" to "eg"),
            "nigeria" to ("africa" to "ni"),
            "kenya" to ("africa" to "ke"),
            "united arab emirates" to ("middle-east" to "ae"),
            "saudi arabia" to ("middle-east" to "sa"),
            "israel" to ("middle-east" to "is"),
            "qatar" to ("middle-east" to "qa"),
            "singapore" to ("east-n-southeast-asia" to "sn"),
            "thailand" to ("east-n-southeast-asia" to "th"),
            "indonesia" to ("east-n-southeast-asia" to "id"),
            "philippines" to ("east-n-southeast-asia" to "rp"),
            "russia" to ("central-asia" to "rs"),
        )
    }
}
