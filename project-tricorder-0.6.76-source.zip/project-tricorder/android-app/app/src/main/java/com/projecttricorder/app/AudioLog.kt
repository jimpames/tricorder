package com.projecttricorder.app

import android.content.Context
import android.location.Location
import android.location.LocationManager
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID

class AudioLog(private val context: Context) {

    private val file: File
        get() {
            val dir = File(context.filesDir, "logs")
            dir.mkdirs()
            return File(dir, "audio.jsonl")
        }

    fun append(yamnet: JSONArray, birdnet: JSONArray, extra: JSONObject = JSONObject()): JSONObject {
        val loc = lastFix()
        val now = System.currentTimeMillis()
        val row = JSONObject()
            .put("id", UUID.randomUUID().toString().take(8))
            .put("t_utc", iso(now))
            .put("t_local", local(now))
            .put("t_ms", now)
            .put("yamnet", yamnet)
            .put("birdnet", birdnet)
            .put("src", android.os.Build.MODEL)
        extra.keys().forEach { row.put(it, extra.get(it)) }
        if (loc != null) {
            row.put("lat", loc.latitude)
            row.put("lon", loc.longitude)
            row.put("acc_m", loc.accuracy.toDouble())
            val pl = PlaceHub.get(context).snapshot(loc.latitude, loc.longitude)
            row.put("plus", pl.optString("plus"))
            row.put("place", pl.optString("place"))
            row.put("w3w", pl.optString("w3w"))
            row.put("place_label", pl.optString("label"))
        }
        file.appendText(row.toString() + "\n")
        return row
    }

    fun tail(n: Int): String {
        if (!file.exists()) return "(no audio log yet)"
        val lines = file.readLines()
        return lines.takeLast(n.coerceIn(1, 200)).asReversed().joinToString("\n")
    }

    fun lastRow(): JSONObject? {
        if (!file.exists()) return null
        val line = file.readLines().lastOrNull() ?: return null
        return try { JSONObject(line) } catch (_: Exception) { null }
    }

    fun path(): String = file.absolutePath

    private fun lastFix(): Location? {
        return try {
            val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            providers.mapNotNull { p ->
                try { lm.getLastKnownLocation(p) } catch (_: SecurityException) { null }
            }.maxByOrNull { it.time }
        } catch (_: Exception) {
            null
        }
    }

    private fun iso(ms: Long): String {
        val fmt = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US)
        fmt.timeZone = TimeZone.getTimeZone("UTC")
        return fmt.format(Date(ms))
    }

    private fun local(ms: Long): String {
        val fmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return fmt.format(Date(ms))
    }
}
