package com.projecttricorder.app

import android.content.Context
import android.provider.Settings
import java.security.MessageDigest
import java.io.File
import java.util.Locale

/**
 * Landing-party identity. Not IMEI (restricted, often empty) and not a
 * hardware MAC (randomized). ANDROID_ID is stable for this app+user+device.
 */
object ComlinkId {
    fun guid(context: Context): String {
        val raw = Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "none"
        val md = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray())
        val hex = md.take(5).joinToString("") { "%02x".format(it) }.uppercase(Locale.US)
        return "TC-$hex"
    }

    fun callsign(context: Context): String {
        val p = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
        var s = p.getString("comlink_name", "")?.trim().orEmpty()
        if (s.isBlank()) {
            s = try { File(context.filesDir, "comlink-name.txt").takeIf { it.exists() }?.readText()?.trim().orEmpty() } catch (_: Exception) { "" }
        }
        return if (s.isBlank()) "UNIT" else s.take(18)
    }

    fun setCallsign(context: Context, name: String) {
        val clean = name.trim().replace(Regex("\\s+"), " ").take(18).ifBlank { "UNIT" }
        context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
            .edit().putString("comlink_name", clean).commit()
        try { File(context.filesDir, "comlink-name.txt").writeText(clean) } catch (_: Exception) {}
    }

    fun advertiseName(context: Context): String = callsign(context) + "|" + guid(context)

    fun parseAdvertise(name: String): Pair<String, String> {
        val parts = name.split("|", limit = 2)
        return if (parts.size == 2) parts[0] to parts[1] else name to name
    }

    fun muted(context: Context): Set<String> {
        val raw = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
            .getString("comlink_muted", "") ?: ""
        return raw.split(',').map { it.trim() }.filter { it.isNotBlank() }.toSet()
    }

    fun setMuted(context: Context, guid: String, mute: Boolean) {
        val cur = muted(context).toMutableSet()
        if (mute) cur.add(guid) else cur.remove(guid)
        context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
            .edit().putString("comlink_muted", cur.joinToString(",")).apply()
    }
}
