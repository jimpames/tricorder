package com.projecttricorder.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupStore {
    const val SCHEMA = 2
    const val DIR_NAME = "backup"
    const val META = "meta.json"
    const val ZIP_NAME = "tricorder-backup-v2.zip"

    fun export(context: Context, faceJson: String?): JSONObject {
        val dir = File(context.filesDir, DIR_NAME).also { it.mkdirs() }
        val prefs = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
        val prefObj = JSONObject()
        prefs.all.forEach { (k, v) -> if (v != null) prefObj.put(k, v.toString()) }
        val meta = JSONObject()
            .put("schema", SCHEMA)
            .put("app", "project-tricorder")
            .put("t_ms", System.currentTimeMillis())
            .put("prefs", prefObj)
            .put("face", faceJson ?: "")
        File(dir, META).writeText(meta.toString())
        copyFile(File(context.filesDir, "logs/field.jsonl"), File(dir, "field.jsonl"))
        copyFile(File(context.filesDir, "logs/audio.jsonl"), File(dir, "audio.jsonl"))
        copyFile(File(context.filesDir, "logs/flights.json"), File(dir, "flights.json"))
        copyFile(File(context.filesDir, "logs/civic.json"), File(dir, "civic.json"))
        copyFile(File(context.filesDir, "dictation/memos.json"), File(dir, "memos.json"))

        val zipInternal = File(dir, ZIP_NAME)
        zipDir(dir, zipInternal, skipName = ZIP_NAME)
        val extDir = context.getExternalFilesDir(null)?.let { File(it, DIR_NAME).also { d -> d.mkdirs() } }
        val zipExt = extDir?.let { File(it, ZIP_NAME) }
        if (zipExt != null) copyFile(zipInternal, zipExt)
        val public = writePublicZip(context, zipInternal)

        return JSONObject()
            .put("ok", true)
            .put("schema", SCHEMA)
            .put("bytes", zipInternal.length())
            .put("internal", dir.absolutePath)
            .put("public", public.ifBlank { zipExt?.absolutePath ?: "" })
    }

    fun import(context: Context): JSONObject {
        val tried = mutableListOf<String>()

        val internalMeta = File(context.filesDir, "$DIR_NAME/$META")
        if (internalMeta.exists() && internalMeta.length() > 8) {
            val r = applyMetaAndSiblings(context, internalMeta.parentFile!!, "internal-dir")
            if (r.optBoolean("ok")) return r
            tried.add(r.optString("error", "internal-dir"))
        }

        val zips = mutableListOf<File>()
        File(context.filesDir, "$DIR_NAME/$ZIP_NAME").takeIf { it.exists() }?.let { zips.add(it) }
        context.getExternalFilesDir(null)?.let { File(it, "$DIR_NAME/$ZIP_NAME") }?.takeIf { it.exists() }?.let { zips.add(it) }
        try {
            File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ProjectTricorder/$ZIP_NAME",
            ).takeIf { it.exists() }?.let { zips.add(it) }
        } catch (_: Exception) {}

        for (z in zips) {
            tried.add("zip " + z.name + " " + z.length() + "b")
            val unpacked = File(context.cacheDir, "restore-unpack").also {
                it.deleteRecursively()
                it.mkdirs()
            }
            try {
                unzip(z, unpacked)
                val r = applyMetaAndSiblings(context, unpacked, z.name)
                if (r.optBoolean("ok")) return r
                tried.add(r.optString("error", z.name))
            } catch (e: Exception) {
                tried.add(z.name + " " + (e.message ?: "unzip"))
            }
        }

        val legacy = File(context.filesDir, "backup/tricorder-backup-v1.json")
        if (legacy.exists()) {
            tried.add("legacy-v1 " + legacy.length() + "b")
            try {
                val root = JSONObject(legacy.readText())
                return applyLegacyObject(context, root, "legacy-v1")
            } catch (e: Exception) {
                tried.add("legacy-v1 parse " + (e.message ?: "bad"))
            }
        }

        return JSONObject()
            .put("ok", false)
            .put("error", "unreadable (" + tried.joinToString("; ").ifBlank { "no backup yet — tap BACKUP first on this build" } + ")")
    }

    private fun applyMetaAndSiblings(context: Context, dir: File, label: String): JSONObject {
        val metaFile = File(dir, META)
        if (!metaFile.exists()) return JSONObject().put("ok", false).put("error", "$label no meta.json")
        val root = try {
            JSONObject(metaFile.readText())
        } catch (e: Exception) {
            return JSONObject().put("ok", false).put("error", "$label meta " + (e.message ?: "parse"))
        }
        if (root.optString("app") != "project-tricorder") {
            return JSONObject().put("ok", false).put("error", "$label not app")
        }
        val sch = root.optInt("schema", -1)
        if (sch != SCHEMA && sch != 1) {
            return JSONObject().put("ok", false).put("error", "$label schema $sch")
        }
        writePrefs(context, root.optJSONObject("prefs") ?: JSONObject())
        copyFile(File(dir, "field.jsonl"), File(context.filesDir, "logs/field.jsonl"))
        copyFile(File(dir, "audio.jsonl"), File(context.filesDir, "logs/audio.jsonl"))
        copyFile(File(dir, "flights.json"), File(context.filesDir, "logs/flights.json"))
        copyFile(File(dir, "civic.json"), File(context.filesDir, "logs/civic.json"))
        copyFile(File(dir, "memos.json"), File(context.filesDir, "dictation/memos.json"))
        return JSONObject()
            .put("ok", true)
            .put("schema", sch)
            .put("from", label)
            .put("face", root.optString("face"))
    }

    private fun applyLegacyObject(context: Context, root: JSONObject, label: String): JSONObject {
        if (root.optString("app") != "project-tricorder") {
            return JSONObject().put("ok", false).put("error", "$label not app")
        }
        writePrefs(context, root.optJSONObject("prefs") ?: JSONObject())
        writeText(File(context.filesDir, "logs/field.jsonl"), root.optString("field_jsonl"))
        writeText(File(context.filesDir, "logs/audio.jsonl"), root.optString("audio_jsonl"))
        writeText(File(context.filesDir, "dictation/memos.json"), root.optString("dictation_json"))
        return JSONObject()
            .put("ok", true)
            .put("schema", 1)
            .put("from", label)
            .put("face", root.optString("face"))
    }

    private fun writePrefs(context: Context, po: JSONObject) {
        val ed = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE).edit()
        po.keys().forEach { ed.putString(it, po.optString(it)) }
        ed.commit()
    }

    private fun writePublicZip(context: Context, zip: File): String {
        if (!zip.exists()) return ""
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val cr = context.contentResolver
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                cr.query(
                    uri,
                    arrayOf(MediaStore.Downloads._ID),
                    MediaStore.Downloads.DISPLAY_NAME + "=?",
                    arrayOf(ZIP_NAME),
                    null,
                )?.use { c ->
                    while (c.moveToNext()) {
                        val item = android.content.ContentUris.withAppendedId(uri, c.getLong(0))
                        try { cr.delete(item, null, null) } catch (_: Exception) {}
                    }
                }
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, ZIP_NAME)
                    put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ProjectTricorder")
                }
                val created = cr.insert(uri, values) ?: return ""
                cr.openOutputStream(created)?.use { out ->
                    FileInputStream(zip).use { it.copyTo(out) }
                }
                return "Download/ProjectTricorder/$ZIP_NAME"
            } catch (_: Exception) {}
        }
        return try {
            val pub = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ProjectTricorder",
            ).also { it.mkdirs() }
            val dest = File(pub, ZIP_NAME)
            copyFile(zip, dest)
            dest.absolutePath
        } catch (_: Exception) {
            ""
        }
    }

    private fun zipDir(dir: File, zipFile: File, skipName: String) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
            dir.listFiles()?.forEach { f ->
                if (!f.isFile || f.name == skipName) return@forEach
                zos.putNextEntry(ZipEntry(f.name))
                FileInputStream(f).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun unzip(zip: File, dest: File) {
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val name = File(e.name).name
                if (name.isNotBlank() && !e.isDirectory) {
                    FileOutputStream(File(dest, name)).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                e = zis.nextEntry
            }
        }
    }

    private fun copyFile(src: File, dest: File) {
        if (!src.exists() || src.length() == 0L) return
        dest.parentFile?.mkdirs()
        src.copyTo(dest, overwrite = true)
    }

    private fun writeText(f: File, body: String) {
        if (body.isEmpty()) return
        f.parentFile?.mkdirs()
        f.writeText(body)
    }
}
