package com.projecttricorder.app

import android.content.Context
import android.location.Geocoder
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

/**
 * Cheap place names for the field book.
 * Always: Open Location Code (plus code) — offline, no key.
 * Usually: Android Geocoder city / state (network, no key).
 * Optional: what3words if SharedPreferences key "w3w_key" is set
 *   (official API; W3W's encoder is proprietary).
 */
object PlaceHub {
    @Volatile private var store: PlaceStore? = null
    fun get(context: Context): PlaceStore {
        store?.let { return it }
        synchronized(this) {
            store?.let { return it }
            return PlaceStore(context.applicationContext).also { store = it }
        }
    }
}

class PlaceStore(private val context: Context) {

    private val io = Executors.newSingleThreadExecutor()
    @Volatile private var cache = JSONObject()
    @Volatile private var lastRefreshMs = 0L

    fun snapshot(lat: Double?, lon: Double?): JSONObject {
        if (lat == null || lon == null || !lat.isFinite() || !lon.isFinite()) {
            return cache.optJSONObject("place") ?: JSONObject()
                .put("ok", false)
                .put("reason", "no fix")
        }
        val plus = PlusCodes.encode(lat, lon)
        val hit = cache
        if (hit.optBoolean("ok") &&
            abs(hit.optDouble("lat") - lat) < 0.0004 &&
            abs(hit.optDouble("lon") - lon) < 0.0004
        ) {
            if (hit.optString("plus").isBlank()) hit.put("plus", plus)
            return hit
        }
        val stub = JSONObject()
            .put("ok", true)
            .put("lat", lat)
            .put("lon", lon)
            .put("plus", plus)
            .put("place", hit.optString("place"))
            .put("city", hit.optString("city"))
            .put("region", hit.optString("region"))
            .put("country", hit.optString("country"))
            .put("w3w", hit.optString("w3w"))
            .put("label", labelOf(hit.optString("place"), plus, hit.optString("w3w")))
        refreshAsync(lat, lon)
        return stub
    }

    fun resolveQuery(q: String): JSONObject {
        val s = q.trim()
        if (s.isBlank()) return JSONObject().put("ok", false).put("error", "empty")
        val w3 = Regex("^(?:/{0,3})([a-z]+\\.[a-z]+\\.[a-z]+)$", RegexOption.IGNORE_CASE).find(s)
        if (w3 != null) {
            val words = w3.groupValues[1].lowercase()
            val ll = what3wordsTo(words)
            if (ll != null) {
                return snapshot(ll.first, ll.second)
                    .put("ok", true)
                    .put("src", "w3w")
                    .put("query", words)
            }
            return JSONObject().put("ok", false).put("error", "what3words needs a key in settings, or words not found")
        }
        val plus = Regex("\\b([2-9CFGHJMPQRVWX]{8}\\+[2-9CFGHJMPQRVWX]{2,3})\\b", RegexOption.IGNORE_CASE).find(s)
        if (plus != null) {
            val pair = PlusCodes.decode(plus.groupValues[1])
            if (pair != null) return snapshot(pair.first, pair.second).put("ok", true).put("src", "plus")
        }
        parseLatLon(s)?.let { (lat, lon) ->
            return snapshot(lat, lon).put("ok", true).put("src", "gps")
        }
        return JSONObject().put("ok", false).put("error", "need lat,lon (N/S E/W ok) or plus code or ///word.word.word")
    }

    private fun parseLatLon(s0: String): Pair<Double, Double>? {
        var s = s0.trim().uppercase()
            .replace('°', ' ')
            .replace('′', ' ')
            .replace('\'', ' ')
        s = s.replace("NORTH", " N ").replace("SOUTH", " S ")
            .replace("EAST", " E ").replace("WEST", " W ")
            .replace(" AND ", " ").replace(" POINT ", ".")
        s = s.replace(Regex("(?<=\\d)([NSEW])"), " $1 ")
        s = s.replace(Regex("([NSEW])(?=\\d)"), "$1 ")
        val hemi = Regex(
            """([NS])?\s*(-?\d+(?:\.\d+)?)\s*([NS])?\s*[,;\s]+\s*([EW])?\s*(-?\d+(?:\.\d+)?)\s*([EW])?"""
        ).find(s)
        if (hemi != null) {
            var lat = hemi.groupValues[2].toDouble()
            var lon = hemi.groupValues[5].toDouble()
            val latH = hemi.groupValues[1].ifBlank { hemi.groupValues[3] }
            val lonH = hemi.groupValues[4].ifBlank { hemi.groupValues[6] }
            if (latH == "S") lat = -kotlin.math.abs(lat)
            if (latH == "N") lat = kotlin.math.abs(lat)
            if (lonH == "W") lon = -kotlin.math.abs(lon)
            if (lonH == "E") lon = kotlin.math.abs(lon)
            if (lat in -90.0..90.0 && lon in -180.0..180.0) return lat to lon
        }
        return null
    }

    private fun what3wordsTo(words: String): Pair<Double, Double>? {
        val key = try {
            context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
                .getString("w3w_key", "") ?: ""
        } catch (_: Exception) { "" }
        if (key.isBlank()) return null
        return try {
            val url = "https://api.what3words.com/v3/convert-to-coordinates?words=$words&key=$key"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.inputStream.bufferedReader().use { r ->
                val o = JSONObject(r.readText()).optJSONObject("coordinates") ?: return null
                o.optDouble("lat") to o.optDouble("lng")
            }
        } catch (_: Exception) { null }
    }

    fun label(lat: Double?, lon: Double?): String {
        val o = snapshot(lat, lon)
        return o.optString("label").ifBlank {
            if (lat != null && lon != null && lat.isFinite())
                String.format(Locale.US, "%.5f, %.5f", lat, lon)
            else "no fix"
        }
    }

    private fun refreshAsync(lat: Double, lon: Double) {
        val now = System.currentTimeMillis()
        if (now - lastRefreshMs < 12_000) return
        lastRefreshMs = now
        io.execute {
            try {
                val plus = PlusCodes.encode(lat, lon)
                var city = ""
                var region = ""
                var country = ""
                try {
                    if (Geocoder.isPresent()) {
                        val geo = Geocoder(context, Locale.getDefault())
                        val list = geo.getFromLocation(lat, lon, 1)
                        val a = list?.firstOrNull()
                        if (a != null) {
                            city = listOf(a.locality, a.subLocality, a.subAdminArea)
                                .firstOrNull { !it.isNullOrBlank() } ?: ""
                            region = a.adminArea ?: ""
                            country = a.countryName ?: ""
                        }
                    }
                } catch (_: Exception) { }
                if (city.isBlank()) {
                    nominatim(lat, lon)?.let {
                        if (city.isBlank()) city = it.optString("city")
                        if (region.isBlank()) region = it.optString("region")
                        if (country.isBlank()) country = it.optString("country")
                    }
                }
                val place = listOf(city, region, country).filter { it.isNotBlank() }.distinct().joinToString(", ")
                val w3w = what3words(lat, lon)
                val row = JSONObject()
                    .put("ok", true)
                    .put("lat", lat)
                    .put("lon", lon)
                    .put("plus", plus)
                    .put("place", place)
                    .put("city", city)
                    .put("region", region)
                    .put("country", country)
                    .put("w3w", w3w)
                    .put("label", labelOf(place, plus, w3w))
                    .put("t_ms", System.currentTimeMillis())
                cache = row
            } catch (_: Exception) { }
        }
    }

    private fun labelOf(place: String, plus: String, w3w: String): String {
        val bits = mutableListOf<String>()
        if (place.isNotBlank()) bits.add(place)
        if (w3w.isNotBlank()) bits.add("///$w3w")
        if (plus.isNotBlank()) bits.add(plus)
        return bits.joinToString(" · ")
    }

    private fun nominatim(lat: Double, lon: Double): JSONObject? {
        return try {
            val url = "https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=$lat&lon=$lon&zoom=12"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.setRequestProperty("User-Agent", "ProjectTricorder/0.6.30 (field instrument)")
            conn.inputStream.bufferedReader().use { r ->
                val o = JSONObject(r.readText())
                val a = o.optJSONObject("address") ?: JSONObject()
                JSONObject()
                    .put("city", first(a, "city", "town", "village", "hamlet", "suburb"))
                    .put("region", first(a, "state", "region"))
                    .put("country", a.optString("country"))
            }
        } catch (_: Exception) { null }
    }

    private fun first(a: JSONObject, vararg keys: String): String {
        for (k in keys) {
            val v = a.optString(k)
            if (v.isNotBlank()) return v
        }
        return ""
    }

    private fun what3words(lat: Double, lon: Double): String {
        val key = try {
            context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
                .getString("w3w_key", "") ?: ""
        } catch (_: Exception) { "" }
        if (key.isBlank()) return ""
        return try {
            val url = "https://api.what3words.com/v3/convert-to-3wa?coordinates=$lat,$lon&key=$key"
            val conn = URL(url).openConnection() as HttpURLConnection
            conn.connectTimeout = 4000
            conn.readTimeout = 4000
            conn.inputStream.bufferedReader().use { r ->
                JSONObject(r.readText()).optString("words")
            }
        } catch (_: Exception) { "" }
    }
}

/** Open Location Code, 10 characters (~14 m cell). Offline, no key. */
object PlusCodes {
    private const val A = "23456789CFGHJMPQRVWX"
    fun encode(lat: Double, lon: Double): String {
        var latVal = (lat + 90.0).coerceIn(0.0, 179.9999999)
        var lonVal = (lon + 180.0).coerceIn(0.0, 359.9999999)
        val out = StringBuilder()
        var latPlace = 20.0
        var lonPlace = 20.0
        for (pair in 0 until 5) {
            if (pair == 4) out.append('+')
            val latDigit = (latVal / latPlace).toInt().coerceIn(0, 19)
            val lonDigit = (lonVal / lonPlace).toInt().coerceIn(0, 19)
            out.append(A[latDigit])
            out.append(A[lonDigit])
            latVal -= latDigit * latPlace
            lonVal -= lonDigit * lonPlace
            latPlace /= 20.0
            lonPlace /= 20.0
        }
        return out.toString()
    }

    fun decode(code: String): Pair<Double, Double>? {
        val raw = code.uppercase().replace("[^0-9A-Z+]".toRegex(), "")
        val plus = raw.indexOf('+')
        if (plus < 0 || raw.length < 8) return null
        val body = raw.replace("+", "")
        if (body.length < 8) return null
        var latVal = 0.0
        var lonVal = 0.0
        var latPlace = 20.0
        var lonPlace = 20.0
        var i = 0
        while (i + 1 < body.length && i < 10) {
            val la = A.indexOf(body[i])
            val lo = A.indexOf(body[i + 1])
            if (la < 0 || lo < 0) return null
            latVal += la * latPlace
            lonVal += lo * lonPlace
            latPlace /= 20.0
            lonPlace /= 20.0
            i += 2
        }
        latVal += latPlace / 2.0
        lonVal += lonPlace / 2.0
        return (latVal - 90.0) to (lonVal - 180.0)
    }
}
