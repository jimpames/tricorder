package com.projecttricorder.app

import android.content.Context
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.AdvertisingOptions
import com.google.android.gms.nearby.connection.ConnectionInfo
import com.google.android.gms.nearby.connection.ConnectionLifecycleCallback
import com.google.android.gms.nearby.connection.ConnectionResolution
import com.google.android.gms.nearby.connection.ConnectionsStatusCodes
import com.google.android.gms.nearby.connection.DiscoveredEndpointInfo
import com.google.android.gms.nearby.connection.DiscoveryOptions
import com.google.android.gms.nearby.connection.EndpointDiscoveryCallback
import com.google.android.gms.nearby.connection.Payload
import com.google.android.gms.nearby.connection.PayloadCallback
import com.google.android.gms.nearby.connection.PayloadTransferUpdate
import com.google.android.gms.nearby.connection.Strategy
import org.json.JSONArray
import org.json.JSONObject

data class ComlinkPeer(
    val endpointId: String,
    var name: String,
    var guid: String,
    var state: String, // seen | reachable | linked
    var lastMs: Long = System.currentTimeMillis(),
    var lat: Double = Double.NaN,
    var lon: Double = Double.NaN,
    var fixMs: Long = 0L,
)

class NearbyLink(
    private val context: Context,
    private val localGuid: String,
    private val onIncoming: (JSONObject) -> Unit,
    private val onRoster: (JSONObject) -> Unit,
    private val onStatus: (String) -> Unit,
) {
    private val client = Nearby.getConnectionsClient(context)
    private val peers = LinkedHashMap<String, ComlinkPeer>()
    @Volatile var running = false
        private set

    fun start(advertiseName: String) {
        stop()
        running = true
        val opts = AdvertisingOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        val dopts = DiscoveryOptions.Builder().setStrategy(Strategy.P2P_CLUSTER).build()
        client.startAdvertising(advertiseName, SERVICE, lifecycle, opts)
            .addOnSuccessListener { onStatus("advertising") }
            .addOnFailureListener { onStatus("adv fail ${it.message}") }
        client.startDiscovery(SERVICE, discovery, dopts)
            .addOnSuccessListener { onStatus("discovering") }
            .addOnFailureListener { onStatus("disc fail ${it.message}") }
        emitRoster()
    }

    fun stop() {
        running = false
        try { client.stopAdvertising() } catch (_: Exception) {}
        try { client.stopDiscovery() } catch (_: Exception) {}
        try { client.stopAllEndpoints() } catch (_: Exception) {}
        peers.values.forEach { if (it.state == "linked") it.state = "seen" }
        onStatus("link off")
        emitRoster()
    }

    fun send(row: JSONObject, guid: String? = null) {
        val payload = Payload.fromBytes(row.toString().toByteArray(Charsets.UTF_8))
        peers.values.filter { it.state == "linked" && (guid == null || it.guid == guid) }.forEach { p ->
            try { client.sendPayload(p.endpointId, payload) } catch (_: Exception) {}
        }
    }

    fun noteFix(guid: String, name: String, lat: Double, lon: Double) {
        val p = peers.values.firstOrNull { it.guid == guid }
            ?: peers.values.firstOrNull { it.name.equals(name, true) }
        if (p != null) {
            p.lat = lat
            p.lon = lon
            p.fixMs = System.currentTimeMillis()
            p.lastMs = p.fixMs
            emitRoster()
        }
    }

    fun connect(endpointId: String) {
        val name = ComlinkId.advertiseName(context)
        client.requestConnection(name, endpointId, lifecycle)
    }

    fun rosterJson(): JSONObject {
        val arr = JSONArray()
        peers.values.forEach { p ->
            arr.put(
                JSONObject()
                    .put("endpoint", p.endpointId)
                    .put("name", p.name)
                    .put("guid", p.guid)
                    .put("state", p.state)
                    .put("last_ms", p.lastMs)
                    .put("muted", ComlinkId.muted(context).contains(p.guid))
                    .put("lat", if (p.lat.isFinite()) p.lat else org.json.JSONObject.NULL)
                    .put("lon", if (p.lon.isFinite()) p.lon else org.json.JSONObject.NULL)
                    .put("fix_ms", p.fixMs),
            )
        }
        return JSONObject()
            .put("ok", true)
            .put("running", running)
            .put("guid", localGuid)
            .put("name", ComlinkId.callsign(context))
            .put("peers", arr)
    }

    private fun emitRoster() { onRoster(rosterJson()) }

    private val lifecycle = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(endpointId: String, info: ConnectionInfo) {
            val (nm, gd) = ComlinkId.parseAdvertise(info.endpointName)
            val p = peers.getOrPut(endpointId) { ComlinkPeer(endpointId, nm, gd, "reachable") }
            p.name = nm; p.guid = gd; p.lastMs = System.currentTimeMillis()
            client.acceptConnection(endpointId, payloadCb)
            emitRoster()
        }
        override fun onConnectionResult(endpointId: String, result: ConnectionResolution) {
            val p = peers[endpointId]
            if (result.status.statusCode == ConnectionsStatusCodes.STATUS_OK) {
                if (p != null) p.state = "linked"
                onStatus("linked " + (p?.name ?: endpointId))
                send(
                    JSONObject()
                        .put("kind", "hello")
                        .put("from", ComlinkId.callsign(context))
                        .put("guid", localGuid),
                )
            } else {
                if (p != null && p.state == "linked") p.state = "reachable"
                onStatus("link fail " + result.status.statusCode)
            }
            emitRoster()
        }
        override fun onDisconnected(endpointId: String) {
            peers[endpointId]?.let { it.state = "seen"; it.lastMs = System.currentTimeMillis() }
            onStatus("dropped $endpointId")
            emitRoster()
        }
    }

    private val discovery = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(endpointId: String, info: DiscoveredEndpointInfo) {
            val (nm, gd) = ComlinkId.parseAdvertise(info.endpointName)
            val p = peers.getOrPut(endpointId) { ComlinkPeer(endpointId, nm, gd, "reachable") }
            p.name = nm; p.guid = gd; p.state = if (p.state == "linked") "linked" else "reachable"
            p.lastMs = System.currentTimeMillis()
            emitRoster()
            // One side requests: lower GUID wins, avoids double handshake.
            if (gd != localGuid && localGuid < gd && p.state != "linked") {
                client.requestConnection(ComlinkId.advertiseName(context), endpointId, lifecycle)
            }
        }
        override fun onEndpointLost(endpointId: String) {
            peers[endpointId]?.let { if (it.state != "linked") it.state = "seen" }
            emitRoster()
        }
    }

    private val payloadCb = object : PayloadCallback() {
        override fun onPayloadReceived(endpointId: String, payload: Payload) {
            val bytes = payload.asBytes() ?: return
            val raw = String(bytes, Charsets.UTF_8)
            try {
                val o = JSONObject(raw)
                peers[endpointId]?.lastMs = System.currentTimeMillis()
                onIncoming(o)
            } catch (_: Exception) {
                onIncoming(JSONObject().put("kind", "raw").put("text", raw))
            }
        }
        override fun onPayloadTransferUpdate(endpointId: String, update: PayloadTransferUpdate) {}
    }

    companion object {
        const val SERVICE = "com.projecttricorder.comlink"
    }
}
