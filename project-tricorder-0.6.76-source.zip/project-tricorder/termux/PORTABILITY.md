# Moving this stack to another Android

**Full install walkthrough:** `docs/TERMUX-BACKEND-INSTALL.md`

You need three things on the new phone. Only one of them is a compile.

## 1. Sideload the APK
`Tricorder-debug-0.2.15.apk` works on any arm64 Android 8+ with a camera.
Grant camera + mic. Battery unrestricted for Termux.

## 2. Termux (same ABI)
Install Termux from F-Droid (not the abandoned Play listing).

```bash
pkg update
pkg install wget curl git clang cmake python openssh termux-api espeak
termux-setup-storage
termux-wake-lock
termux-change-repo   # pick a fast mirror
```

RAM: 8 GB is tight, 12 GB is comfortable. Snapdragon 8xx / 7+ / Dimensity 8xxx class.

## 3. Weights — one script
From this folder:

```bash
bash fetch-models.sh
```

About 6 GB. Resume-safe. Gemma may 401 until you accept the Gemma license on huggingface.co while logged in; then retry, or use `llama-server -hf ggml-org/gemma-3-4b-it-GGUF` which prompts.

Kokoro ONNX is the PocketPal v1.0 fp32 graph + `voices-v1.0.bin`. FP16 NaNs on this ORT/Android combo — do not swap in fp16.

## Binaries — copy, do not rebuild first

Termux `aarch64` ELFs linked against `$PREFIX` **copy to another Termux aarch64**. They do **not** run on stock Android or iOS.

On the Fold (donor):

```bash
mkdir -p ~/export-bin
cp ~/llama.cpp/build/bin/llama-server ~/export-bin/
cp ~/stable-diffusion.cpp/build/bin/sd-server ~/export-bin/
cp ~/stable-diffusion.cpp/build/bin/sd-cli ~/export-bin/   # optional
tar -czf /sdcard/Download/tricorder-bins-aarch64.tgz -C ~ export-bin
```

On the new phone, after Termux exists:

```bash
tar -xzf /sdcard/Download/tricorder-bins-aarch64.tgz -C ~
mkdir -p ~/llama.cpp/build/bin ~/stable-diffusion.cpp/build/bin
cp ~/export-bin/llama-server ~/llama.cpp/build/bin/
cp ~/export-bin/sd-server    ~/stable-diffusion.cpp/build/bin/
chmod +x ~/llama.cpp/build/bin/llama-server ~/stable-diffusion.cpp/build/bin/sd-server
```

If `llama-server` dies with `CANNOT LINK EXECUTABLE`, the new Termux is too old/new. Rebuild there:

```bash
pkg install clang cmake git
git clone https://github.com/ggml-org/llama.cpp
cd llama.cpp && cmake -B build && cmake --build build -j --target llama-server

git clone https://github.com/leejet/stable-diffusion.cpp
cd stable-diffusion.cpp
cmake -B build -DSD_WEBP=OFF
cmake --build build -j --target sd-server
```

`-DSD_WEBP=OFF` avoids the missing `cpu-features` / libwebp hole we hit.

## Kokoro Python
`server.py` lives in `~/kokoro` on the donor. Copy that directory plus the two weight files. Termux Python 3.12–3.14 works with the dlinfo stub and espeak already installed.

## Start
```bash
cp termux/tricorder ~/bin/tricorder
chmod +x ~/bin/tricorder
# first start from the Termux app itself, not SSH
~/bin/tricorder start
~/bin/tricorder status
```

sshd is port **8022**. Do not kill sshd from `tricorder stop`.

## What does not travel
- Samsung-only battery quirks (Unrestricted is still required)
- GPU/OpenCL `sd-server` (CPU only unless you rebuild)
- x86 Termux / ChromeOS — need a rebuild
- The GGUF files inside the git zip — too big; always wget
