# Guide to Understanding Tricorder/OS — M-TOR

**Multi-Tronic Operating Realm for Android**  
Theory of operations for developers and scientists  
N2NHU Labs · Jim Ames, Claude and Grok · Newburgh, New York · 22 September 2026 · Rev 0.6.47

This describes software that runs on an ordinary phone. It is not a third Android, not DO-178C airborne software, and not affiliated with Star Trek rights holders. “Realm” means a coordination layer that sits on Android and treats models, sensors, and radios as swappable organs.

## 1. What M-TOR is

Tricorder/OS is not a third Android. The phone still boots Samsung’s kernel and ART. M-TOR is the multi-tronic operating realm: a thin, event-shaped control plane that makes several heterogeneous computers on one SoC behave like one instrument.

Those computers are real and separate. Gemma and SmolVLM live in Termux `llama-server` processes on loopback. Stable Diffusion is another process. Kokoro is another. YAMNet, BirdNET, and flora/fauna are in-process TFLite inside the APK. Speech-in is Android’s `SpeechRecognizer`. Comlink is Google Nearby. The face is a WebView. Kotlin is the janitor that owns hardware and permissions.

An app would pick one of those and wrap it. An integration treats them as organs. M-TOR is the circulatory system.

**Multi-tronic:** more than one inference engine, more than one sensor class, more than one transport, none allowed to become the system. **Operating realm:** a jurisdiction with laws (tuples, event names, JSON row shape), not a new kernel.

## 2. Design laws

Written in design spec v0.1; still binding on the 0.6.x face.

1. Nothing important is a special case in application code. Modes, keyword hints, ports, and providers are data.
2. API-first. The face never owns a model. It posts JSON to `127.0.0.1` or calls a `JavascriptInterface` that already looks like a tool.
3. Event-driven. A button, a frame, a bird label, a PTT packet, and a NOAA row all become events or event-shaped JSON. Subscribers decide whether they care.
4. Algebraic intent. User meaning is projected onto a tuple `I = (Mode, InputChannel, TargetModality, Action)` and matched against ordered rules. The model is a worker hired after the route exists.
5. Extensible by construction. If a sense cannot be expressed as a row `{kind, text, from, guid, hhmm, extra}`, it does not belong on the bus yet.

## 3. Two spines, one realm

### 3.1 tricorder-core (algebraic spine)

`EventBus` — the only object UI, providers, and engines talk to.  
`TupleEngine` — deterministic router, zero domain literals.  
`payloadBuilder` / `mcpClient` — resolved route to backend call.  
`sensorLoopDriver` / `contextProviderPoller` — time owns Sensor, Sentry, and weather.

That package is the constitution. The Fold 3 face re-hosted the laws where latency and permissions live.

### 3.2 Android hosting (visceral spine)

WebView renders phosphor. `voice-menu.js` and `submitInquiry()` are the tuple door. Kotlin owns camera, mic, GNSS, baro, Nearby, TFLite, MediaPlayer. Termux keeps four warm servers. FieldLog / AudioLog are the durable riverbed.

A scientist adding a classifier does not open a new Activity stack. They emit the row the CRT already paints and the mesh already forwards.

## 4. Intent as water

Intent is not a prompt. It is a drop that falls downhill through weirs.

```
utterance / button / frame / PCM / ADS-B
        |  normalize (STT aliases)
        v
   tuple door   I = (mode, channel, modality, action)
        |  first matching rule wins — no LLM
        +--> local organ     (clock, comlink, dictation, NAV)
        +--> in-process net  (YAMNet, flora, BirdNET)
        +--> loopback organ  (Gemma, SmolVLM, SD, Kokoro)
        +--> radio organ     (Nearby JSON)
        v
   event-shaped row
        |  CRT, LED, log, TTS, mesh subscribers
        v
   field log  +  optional spoken line  +  optional remote copy
```

Water does not ask the ocean what a creek is. “tricoder commlink” is aliased to the comlink action before any model token is spent. That is the difference between an orchestrator and a chatbot with plugins.

When the drop does reach Gemma, the expensive work stays on `:8080`. The face stays interactive. IPL / ALL dumps the cistern: in-flight HTTP and TTS die without tearing down the realm.

## 5. Why stacking does not stall the realm

“No system lag” is not a claim that Stable Diffusion is instant. It is a claim that a new organ does not add a synchronous frame to the UI thread or a new token to the door.

- **Warm processes, cold features.** The four Termux servers stay up. Flora fetch writes a file; the next Sensor frame already knows the extra classifier.
- **Cheap door, expensive room.** Tuple matching is string work. YAMNet is milliseconds on the 888. Gemma and Kokoro are seconds. SD is tens of seconds. Hold, continuous-vision-without-Kokoro, MUTE, and IPL are weirs.
- **Same row, new subscriber.** Gunfire on Spock is `emitContextAlert` plus `{kind:context, from, guid, …}`. Kirk is a subscriber. The callsign was a field, not a new bus.
- **Abort is an organ.** A 30-second job without IPL couples the face to that job. M-TOR refuses that coupling.

We do not run a new Activity per sense. We do not ask Gemma “the user said something, what now?” We do not block `onCreate` on model load.

## 6. Data as water

A field-log row is the molecule: `kind`, `text`, timestamp, optional photo, optional `extra` (tail, plus code, from, guid). AudioLog is the same idea for YAMNet dwells. Dictation pours into the field log with `LOG nnnn`.

Readings charts are a filter over that river. Comlink is the same molecule on a radio: `Payload.fromBytes(row.toString())`. PTT is `kind=ptt`. A watch is `kind=context`. A future Earth-link store-and-forward should ingest that molecule, not invent a homeserver schema.

Place names flow once: lat/lon + offline plus code + optional Geocoder city. NAV, horizon, and log drink from one cache.

## 7. Theory of operation by organ

| Organ | Door | Worker | Weir |
|---|---|---|---|
| Inquiry | STT / type | Gemma `:8080` | chunked Kokoro, IPL |
| Sensor / Sentry | camera | SmolVLM + flora TFLite | Hold, continuous-no-TTS |
| Audio | PCM duty cycle | YAMNet ± BirdNET | interval/dwell, self-speech suppress |
| Imagine | prompt | SD `:8188` | steps, size |
| Translate | SOURCE/TARGET | on-device packs | AUTO swap |
| Knowledge | MEMORY ALPHA / MEDICAL | cached wiki extracts | TERMINATE |
| Clock | CLOCK | GnssClock else wall | timers |
| NAV | H second press | haversine + DR | 30 m off-track |
| Comlink | COMLINK | Nearby cluster | peer mute, robot-only |

## 8. How a scientist adds an organ

1. Produce the molecule.  
2. PCM-in → classify in-process → append log.  
3. Feed-in → look like `contextProviderPoller`.  
4. Verb-in → tuple alias plus the STT misspellings.  
5. If other units should hear it → `from` + `guid` + `send()` when Comlink is live.  
6. Paint with an existing CRT subscriber or a short sheet.

**Test of belonging:** can a deaf, muted, offline unit still write the row? If the feature dies when Gemma is down, it was an app plugin, not an organ.

## 9. Why this is unusual

Phone “AI” products in 2026 are one model plus a skin, or a cloud round-trip with an on-device teaser. None of them treat watch, flora, ADS-B, dictation, walking NAV, and a mesh of callsigns as the same river.

Cloud vendors could ship this appliance. They optimize for tokens billed. An offline orchestrator with four local servers and a tuple door does not sell seats. The Fold 3 already had the SoC. M-TOR is permission to use all of it at once without asking a frontier model what a button means.

## 10. Limits

The WebView face is one JavaScript heap — `const strip` twice in 0.6.42 took the CRT down. Nearby is Play-services radio range, not valley-proof log sync. Termux dies when the phone sleeps hard; `~/bin/tricorder` is the babysitter, not the kernel. “No lag” does not apply to SD or first-token Gemma. Do not fly with the horizon.

## 11. Glossary

- **Tuple** — `I = (Mode, InputChannel, TargetModality, Action)`. Door, not model.
- **Organ** — a process or in-process classifier with one job and a row-shaped output.
- **Molecule** — JSON row the log, CRT, TTS, and mesh can all drink.
- **Weir** — Hold, MUTE, IPL, peer mute, TTS length. Flow control without shutting the river.
- **Realm** — the jurisdiction those objects share on top of Android.

## 12. Document control

Companion to Field Manual Rev 0.6.47 and design spec v0.1. Software: Project Tricorder Mk I 0.6.47. Source: `tricorder-core` (EventBus, TupleEngine) and `android-app` (viewport + organs).
