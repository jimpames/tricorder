#!/usr/bin/env python3
"""3x5 portrait laminated field cards — NASA-mission + tricorder phosphor."""
from reportlab.pdfgen import canvas
from reportlab.lib.units import inch
from reportlab.lib.colors import Color, HexColor, white, black
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from pathlib import Path

W, H = 3 * inch, 5 * inch
NAVY = HexColor("#0b1220")
NAVY2 = HexColor("#121a2b")
RED = HexColor("#fc3d21")
BLUE = HexColor("#0b3d91")
GOLD = HexColor("#d4af37")
PHOS = HexColor("#7dffb0")
PHOS_DIM = HexColor("#3f8a63")
CREAM = HexColor("#f4f1ea")
MUTED = HexColor("#a8b4c8")
WARN = HexColor("#ffb454")

OUT = Path("/home/workdir/artifacts/Project-Tricorder-MkI-Field-Cards-3x5.pdf")
OUT2 = Path("/home/workdir/artifacts/project-tricorder/project-tricorder/docs/Project-Tricorder-MkI-Field-Cards-3x5.pdf")


def wrap(c, text, font, size, x, y, max_w, leading, color=CREAM, center=False):
    words = text.split()
    lines, cur = [], ""
    for w in words:
        trial = (cur + " " + w).strip()
        if c.stringWidth(trial, font, size) <= max_w:
            cur = trial
        else:
            if cur:
                lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    for i, line in enumerate(lines):
        c.setFillColor(color)
        c.setFont(font, size)
        if center:
            c.drawCentredString(x, y - i * leading, line)
        else:
            c.drawString(x, y - i * leading, line)
    return len(lines) * leading


def brand_mast(c):
    """Top strap on every card — name, crew, license, support."""
    c.setFillColor(RED)
    c.rect(0, H - 0.26 * inch, W, 0.26 * inch, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 7.4)
    c.drawCentredString(W / 2, H - 0.17 * inch, "PROJECT TRICORDER  MK. I")
    c.setFillColor(HexColor("#0e1828"))
    c.rect(0, H - 0.72 * inch, W, 0.46 * inch, fill=1, stroke=0)
    c.setFillColor(GOLD)
    c.setFont("Helvetica-Bold", 5.8)
    c.drawCentredString(W / 2, H - 0.38 * inch, "BY  AMES  ·  GROK  ·  CLAUDE")
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 5.3)
    c.drawCentredString(W / 2, H - 0.50 * inch, "DESIGNED AND CODED USA   ·   GPL-3.0 OPEN SOURCE")
    c.setFillColor(PHOS)
    c.setFont("Helvetica", 5.4)
    c.drawCentredString(W / 2, H - 0.62 * inch, "github.com/jimpames/tricorder")
    c.setFillColor(CREAM)
    c.setFont("Helvetica", 5.3)
    c.drawCentredString(W / 2, H - 0.72 * inch + 2, "support  jimpames@gmail.com")
    c.setFillColor(BLUE)
    c.rect(0, H - 0.78 * inch, W, 0.06 * inch, fill=1, stroke=0)


def header(c, kicker, title):
    c.setFillColor(NAVY)
    c.rect(0, 0, W, H, fill=1, stroke=0)
    brand_mast(c)
    c.setFillColor(white)
    c.setFont("Helvetica-Bold", 6)
    c.drawString(0.16 * inch, H - 0.92 * inch, kicker.upper())
    c.setFillColor(GOLD)
    c.setFont("Helvetica-Bold", 6)
    c.drawRightString(W - 0.14 * inch, H - 0.92 * inch, "FIELD CARD")
    c.setFillColor(PHOS)
    wrap(c, title.upper(), "Helvetica-Bold", 11, 0.16 * inch, H - 1.10 * inch, W - 0.70 * inch, 13)
    c.setStrokeColor(PHOS_DIM)
    c.setLineWidth(0.6)
    c.line(0.16 * inch, H - 1.28 * inch, W - 0.16 * inch, H - 1.28 * inch)


def footer(c, n, total):
    c.setFillColor(RED)
    c.rect(0, 0, W, 0.22 * inch, fill=1, stroke=0)
    c.setFillColor(white)
    c.setFont("Helvetica", 5.5)
    c.drawString(0.14 * inch, 0.08 * inch, "N2NHU LABS  ·  NEWBURGH NY")
    c.drawRightString(W - 0.14 * inch, 0.08 * inch, f"{n:02d} / {total:02d}")


def badge(c, x, y, kind):
    """Simple mission pictograms in a 28pt square."""
    s = 0.34 * inch
    c.setFillColor(NAVY2)
    c.setStrokeColor(PHOS)
    c.setLineWidth(1.1)
    c.roundRect(x, y, s, s, 4, fill=1, stroke=1)
    cx, cy = x + s / 2, y + s / 2
    c.setStrokeColor(PHOS)
    c.setFillColor(PHOS)
    c.setLineWidth(1.3)
    if kind == "mic":
        c.roundRect(cx - 4, cy - 2, 8, 12, 3, fill=0, stroke=1)
        c.line(cx, cy - 2, cx, cy - 7)
        c.line(cx - 6, cy - 7, cx + 6, cy - 7)
    elif kind == "eye":
        c.ellipse(cx - 10, cy - 5, cx + 10, cy + 5, fill=0, stroke=1)
        c.circle(cx, cy, 3.2, fill=1, stroke=0)
    elif kind == "shield":
        p = c.beginPath()
        p.moveTo(cx, cy + 10)
        p.lineTo(cx + 9, cy + 5)
        p.lineTo(cx + 9, cy - 4)
        p.lineTo(cx, cy - 11)
        p.lineTo(cx - 9, cy - 4)
        p.lineTo(cx - 9, cy + 5)
        p.close()
        c.drawPath(p, stroke=1, fill=0)
    elif kind == "wave":
        p = c.beginPath()
        p.moveTo(cx - 11, cy)
        for i, yy in enumerate([4, -6, 8, -5, 3]):
            p.lineTo(cx - 11 + (i + 1) * 4.4, cy + yy)
        c.drawPath(p, stroke=1, fill=0)
    elif kind == "plane":
        p = c.beginPath()
        p.moveTo(cx - 11, cy)
        p.lineTo(cx + 11, cy)
        p.moveTo(cx - 2, cy)
        p.lineTo(cx - 8, cy + 8)
        p.moveTo(cx - 2, cy)
        p.lineTo(cx - 8, cy - 8)
        p.moveTo(cx + 8, cy)
        p.lineTo(cx + 5, cy + 3)
        p.moveTo(cx + 8, cy)
        p.lineTo(cx + 5, cy - 3)
        c.drawPath(p, stroke=1, fill=0)
    elif kind == "talk":
        c.roundRect(cx - 10, cy - 4, 16, 12, 2, fill=0, stroke=1)
        p = c.beginPath()
        p.moveTo(cx - 4, cy - 4)
        p.lineTo(cx - 7, cy - 10)
        p.lineTo(cx + 1, cy - 4)
        c.drawPath(p, stroke=1, fill=0)
    elif kind == "compass":
        c.circle(cx, cy, 10, fill=0, stroke=1)
        c.setFillColor(RED)
        p = c.beginPath()
        p.moveTo(cx, cy + 9)
        p.lineTo(cx + 3, cy)
        p.lineTo(cx, cy - 3)
        p.lineTo(cx - 3, cy)
        p.close()
        c.drawPath(p, fill=1, stroke=0)
        c.setFillColor(PHOS)
    elif kind == "star":
        c.circle(cx, cy, 2, fill=1, stroke=0)
        c.setStrokeColor(GOLD)
        c.line(cx - 10, cy, cx + 10, cy)
        c.line(cx, cy - 10, cx, cy + 10)
        c.line(cx - 7, cy - 7, cx + 7, cy + 7)
    elif kind == "book":
        c.rect(cx - 9, cy - 9, 18, 16, fill=0, stroke=1)
        c.line(cx, cy - 9, cx, cy + 7)
        c.line(cx - 7, cy + 4, cx - 2, cy + 4)
        c.line(cx + 2, cy + 4, cx + 7, cy + 4)
    elif kind == "link":
        c.circle(cx - 5, cy, 5.5, fill=0, stroke=1)
        c.circle(cx + 5, cy, 5.5, fill=0, stroke=1)
    elif kind == "clock":
        c.circle(cx, cy, 10, fill=0, stroke=1)
        c.line(cx, cy, cx, cy + 6)
        c.line(cx, cy, cx + 5, cy - 2)
    elif kind == "save":
        c.rect(cx - 8, cy - 8, 16, 16, fill=0, stroke=1)
        c.rect(cx - 4, cy + 2, 8, 6, fill=0, stroke=1)
        c.rect(cx - 5, cy - 7, 10, 7, fill=0, stroke=1)
    elif kind == "warn":
        p = c.beginPath()
        p.moveTo(cx, cy + 10)
        p.lineTo(cx + 11, cy - 9)
        p.lineTo(cx - 11, cy - 9)
        p.close()
        c.setStrokeColor(WARN)
        c.drawPath(p, stroke=1, fill=0)
        c.setFillColor(WARN)
        c.circle(cx, cy - 6, 1.4, fill=1, stroke=0)
        c.rect(cx - 1, cy - 3, 2, 8, fill=1, stroke=0)
        c.setFillColor(PHOS)
    elif kind == "hand":
        c.circle(cx, cy + 4, 3.5, fill=0, stroke=1)
        c.roundRect(cx - 3, cy - 10, 6, 14, 2, fill=0, stroke=1)
    elif kind == "grid":
        for i in range(3):
            for j in range(3):
                c.rect(cx - 9 + i * 7, cy - 9 + j * 7, 5, 5, fill=0, stroke=1)
    else:
        c.circle(cx, cy, 6, fill=0, stroke=1)


def bullets(c, items, y0):
    y = y0
    for item in items:
        c.setFillColor(PHOS)
        c.circle(0.22 * inch, y + 2, 1.6, fill=1, stroke=0)
        used = wrap(c, item, "Helvetica", 7.4, 0.32 * inch, y, W - 0.48 * inch, 9.4, CREAM)
        y -= max(used, 10) + 3
    return y


def card_cover(c):
    c.setFillColor(NAVY)
    c.rect(0, 0, W, H, fill=1, stroke=0)
    c.setFillColor(RED)
    c.rect(0, H - 0.22 * inch, W, 0.22 * inch, fill=1, stroke=0)
    c.setFillColor(BLUE)
    c.rect(0, 0, W, 0.22 * inch, fill=1, stroke=0)
    # meatball-ish
    c.setFillColor(RED)
    c.circle(W / 2, H / 2 + 0.55 * inch, 0.42 * inch, fill=1, stroke=0)
    c.setFillColor(NAVY)
    c.circle(W / 2 + 0.08 * inch, H / 2 + 0.58 * inch, 0.28 * inch, fill=1, stroke=0)
    c.setStrokeColor(GOLD)
    c.setLineWidth(1.4)
    c.line(0.4 * inch, H / 2 + 0.55 * inch, W - 0.4 * inch, H / 2 + 0.55 * inch)
    c.setFillColor(PHOS)
    c.setFont("Helvetica-Bold", 8)
    c.drawCentredString(W / 2, H - 0.55 * inch, "PROJECT")
    c.setFont("Helvetica-Bold", 16)
    c.drawCentredString(W / 2, H - 0.82 * inch, "TRICORDER")
    c.setFillColor(GOLD)
    c.setFont("Helvetica-Bold", 8)
    c.drawCentredString(W / 2, H - 1.02 * inch, "MARK I  ·  FIELD CARDS")
    c.setFillColor(CREAM)
    c.setFont("Helvetica", 7)
    wrap(
        c,
        "Laminate. Pocket. One job per card. Voice first, then the face.",
        "Helvetica",
        7.5,
        W / 2,
        H / 2 - 0.15 * inch,
        W - 0.5 * inch,
        10,
        CREAM,
        center=True,
    )
    c.setFillColor(GOLD)
    c.setFont("Helvetica-Bold", 6)
    c.drawCentredString(W / 2, 0.88 * inch, "BY  AMES  ·  GROK  ·  CLAUDE")
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 6)
    c.drawCentredString(W / 2, 0.74 * inch, "DESIGNED AND CODED USA  ·  GPL-3.0")
    c.setFillColor(PHOS)
    c.setFont("Helvetica", 6)
    c.drawCentredString(W / 2, 0.60 * inch, "github.com/jimpames/tricorder")
    c.setFillColor(CREAM)
    c.setFont("Helvetica", 6)
    c.drawCentredString(W / 2, 0.46 * inch, "support  jimpames@gmail.com")
    c.setFillColor(MUTED)
    c.setFont("Helvetica", 5.5)
    c.drawCentredString(W / 2, 0.32 * inch, "N2NHU LABS  ·  NEWBURGH, NEW YORK")
    c.setFillColor(white)
    c.setFont("Helvetica", 6)
    c.drawCentredString(W / 2, 0.08 * inch, "NOT FOR FLIGHT  ·  NOT A 911 DEVICE")


def card_body(c, kicker, title, icon, items, n, total, note=None):
    header(c, kicker, title)
    badge(c, W - 0.52 * inch, H - 1.24 * inch, icon)
    y = bullets(c, items, H - 1.46 * inch)
    if note:
        c.setFillColor(WARN)
        wrap(c, note, "Helvetica-Oblique", 6.6, 0.16 * inch, 0.40 * inch, W - 0.32 * inch, 8.4, WARN)
    footer(c, n, total)


CARDS = [
    (
        "Operations",
        "The Face",
        "grid",
        [
            "I Inquiry — Gemma chat. Mic or type.",
            "II Sensor — one look + flora/fauna.",
            "III Sentry — continuous watch. Weapons/motion.",
            "IV Audio — YAMNet + civic + flights.",
            "T / XLATE — offline speech translator.",
            "H Horizon, second press NAV.",
            "S Satellites / Stars. O Sol / weather / moon.",
            "L review  E officer note  V video  P play.",
            "IPL / ALL aborts work. STT kills speech only.",
        ],
        None,
    ),
    (
        "Voice",
        "ROBO cycle",
        "mic",
        [
            "Dark — Kokoro lady voice.",
            "Green ROBO — fast Android robot.",
            "Yellow [H/F R] — robot + hands-free menu.",
            "Red [MUTE] — silent observer. CRT + log only. No voice, no tones.",
            "One more tap returns dark / Kokoro.",
            "Civic, flights, sentry alerts always use robot. Inquiry still uses Kokoro unless ROBO or MUTE.",
        ],
        "MUTE is the camp unit that must not announce itself.",
    ),
    (
        "Hands-free",
        "Speech menu",
        "hand",
        [
            "Arm yellow [H/F R]. Say the ship name first.",
            "TRICORDER SENSOR / SENTRY / AUDIO",
            "TRICORDER TRANSLATOR or TRANSLATE",
            "TRICORDER HORIZON · NAV · CAMP · MARK · BACKTRACK",
            "TRICORDER SATELLITES · SOL · CLOCK · DICTATION",
            "TRICORDER SETTINGS · BACK END · DIAGNOSTICS",
            "TRICORDER SUMMARIZE READINGS",
            "TRICORDER COMLINK · HELP",
            "Leave a mode with the face button. Aliases: tricoder, trick order.",
        ],
        "While yellow, speech that is not a TRICORDER line is ignored.",
    ),
    (
        "Inquiry",
        "Ask the computer",
        "talk",
        [
            "I Inquiry. Tap mic or type. SEND.",
            "Intercepts before the model: HELP, SETTINGS, BACK END, DIAGNOSTICS, COMPUTER, CLOCK, DICTATION, MEMORY ALPHA, MEDICAL.",
            "COMPUTER — Daystrom spiel + battery, baro, Earth link.",
            "DIAGNOSTICS — version, packs, sensors. Robot voice.",
            "Wait for CHAT lamp green before the next line.",
        ],
        None,
    ),
    (
        "Look",
        "Sensor",
        "eye",
        [
            "II Sensor. Point. Hold is a toggle: press to freeze the frame, press again to release.",
            "Vision describes the scene. Flora/fauna runs on the same snap when packs are on device.",
            "TOP 3 bars: weakest on top, HIGHLY LIKELY green on the bottom of the CRT.",
            "Scroll up for raw percents. LED shows #1 and a percent meter.",
        ],
        None,
    ),
    (
        "Watch",
        "Sentry",
        "shield",
        [
            "III Sentry is continuous by default. Optional Continuous MV (no Kokoro) writes the CRT only.",
            "Hold after a hit so the loop does not flood.",
            "Sure weapon (knife, gun): klaxon + WEAPON DETECTED ×3. Robot.",
            "Possible / dual-use: chime + possible weapon. Robot.",
            "Motion, animal, rain: short robot line. Logged.",
            "Motion does not gate the caption loop.",
        ],
        "Captions are keywords. Not a certified weapons detector.",
    ),
    (
        "Listen",
        "Audio sense",
        "wave",
        [
            "IV Audio. Sliders: dwell and interval.",
            "YAMNet on-device. BirdNET if fetched.",
            "Priority robot alerts: gunfire ×3 + klaxon · scream · siren ×3 · air/rail/ship · vehicles · named animal · humans ×3 · entertainment.",
            "Unit does not call its own speech HUMANS DETECTED.",
            "DISMISS a flight/civic card or graphs stay frozen.",
        ],
        "Fireworks can look like gunfire.",
    ),
    (
        "Watch",
        "Civic + flights",
        "plane",
        [
            "Needs Audio armed + Earth link + GPS fix.",
            "Flights: OpenSky box. Card: photo, owner, FROM/TO, AUTOPLAY.",
            "Civic: CityAlert (no key) + IPAWS + USGS. Not Citizen Inc. SpotCrime needs a static IP — skip it.",
            "Civic card: icon, HEAR AGAIN, PREV/NEXT, DISMISS.",
            "Settings geobox: flight km, civic km, quake km.",
        ],
        "All civic/flight speech is robot voice.",
    ),
    (
        "Overhead",
        "AUTOPLAY",
        "plane",
        [
            "On a pinned airframe card, touch AUTOPLAY.",
            "1 Photo + spoken line (tail, owner, feet or meters, mph or km/h, mach, from, to).",
            "2 Airframe facts card.",
            "3 Origin city + up to 3 airport views.",
            "4 Dest city + views.",
            "5 Next craft, newest first. Touch AUTOPLAY again to stop.",
            "English units are the default. Settings checkbox writes native prefs.",
        ],
        "Needs Earth link for photos and dossiers.",
    ),
    (
        "Language",
        "Translator",
        "talk",
        [
            "T / XLATE. Green = listening. Yellow = speaking. Red = thinking.",
            "SOURCE and TARGET open language wheels. AUTO green swaps after each line.",
            "Silence after speech triggers the translation. Robot or Kokoro per ROBO.",
            "Packs download at first Earth link, or from Settings.",
            "Press T again to leave.",
        ],
        None,
    ),
    (
        "Walk",
        "Horizon + NAV",
        "compass",
        [
            "H cycles: off → horizon → NAV → off.",
            "Horizon: heading, G, GPS speed, baro altitude proxy, place line. Toy only.",
            "NAV is line-of-sight walking. No roads. Not for driving or flight.",
            "Dest: 41.50N 74.01W · plus code · ///what.3.words (key in Settings).",
            "GO bearing + distance. MARK waypoint. CAMP here. BACKTRACK to camp.",
            "Off-track chime > 30 m. Stale GPS: dead-reckon at a walk.",
        ],
        "NOT certified. NEVER fly or land on this display.",
    ),
    (
        "Sky",
        "Sat · Stars · Sol",
        "star",
        [
            "S toggles satellites and the star map. Live with device attitude.",
            "O Sol cycles: space weather + planet orbits + HF/VHF/UHF → earth forecast (scroll) → moon phase → off.",
            "CLOCK — GNSS novelty clock, analog/digital, 12/24, named timers.",
            "Say MOON or CLOCK from Inquiry.",
        ],
        "Satellite clock is a field novelty, not a time standard.",
    ),
    (
        "Notes",
        "Dictation",
        "book",
        [
            "Wake: DICTATION or TRICORDER DICTATION.",
            "NEW · EDIT nnnn · LOG nnnn (CONFIRMED) · SUMMARIZE nnnn",
            "MINDMAP keyword · SPEAK nnnn · KILL nnnn (CONFIRMED) · TERMINATE",
            "ZULU then SAVE or ABORT.",
            "CURSOR MINUS / PLUS word · BACKSPACE · NEWLINE · CUT · PASTE · HOME · END",
            "PUNCTUATION PERIOD (or PERIOD / DOT).",
        ],
        None,
    ),
    (
        "Mesh",
        "Comlink",
        "link",
        [
            "TRICORDER COMLINK or the nameplate.",
            "GUID is TC- plus a hash of ANDROID_ID. Assign a callsign. SAVE NAME.",
            "Yellow = heard. Green = linked. Touch a name to mute that unit.",
            "PTT: speak. Far tube: Beep beep beep. From NAME. … Robot.",
            "Remote alerts: Remote tricorder Spock detected …",
            "Both units need 0.6.46+.",
        ],
        None,
    ),
    (
        "Record",
        "Log + readings",
        "book",
        [
            "L review with time slider. E officer note. V video. P play.",
            "Sensor, sentry, flora, bird, flight, civic hits write the book with GPS + place when known.",
            "SUMMARIZE READINGS [category] [day|week|month|all].",
            "Letter bars A B C. Touch a bar for that category’s timeline. Flights: by tail / by airframe.",
        ],
        None,
    ),
    (
        "Keep",
        "Backup + settings",
        "save",
        [
            "Comlink pane: BACKUP TRICORDER (green) writes schema-2 folder + zip.",
            "RESTORE TRICORDER (yellow) reads internal meta first, then the zip.",
            "Tap BACKUP on 0.6.59+ before you depend on it. Old one-file JSON will not restore.",
            "Settings: units, geobox km, civic toggles, scanner / PulsePoint handoff, W3W key.",
            "Termux four-pack: chat :8080 vision :8081 image :8188 tts :5000. ~/bin/tricorder start",
        ],
        None,
    ),
    (
        "Limits",
        "Warnings",
        "warn",
        [
            "Not FAA / NASA / EASA / ICAO certified. Not DO-178C.",
            "Horizon, G, speed, baro, SAT, SOL, moon, GNSS clock — never fly, land, or navigate a craft.",
            "Weapon and gunfire lines are captions and YAMNet labels. Not a weapons detector. Not 911.",
            "MEDICAL is an encyclopedia briefing. MEMORY ALPHA is Simple English Wikipedia — not Star Trek.",
            "Not affiliated with The Wand Company, Paramount, Desilu, CBS, Roddenberry, or Wah Chang.",
        ],
        "When in doubt, use your eyes and a real radio.",
    ),
]


def main():
    total = 1 + len(CARDS)
    c = canvas.Canvas(str(OUT), pagesize=(W, H))
    c.setTitle("Project Tricorder Mk I — Field Cards 3×5")
    c.setAuthor("N2NHU Labs")
    card_cover(c)
    c.showPage()
    for i, (kicker, title, icon, items, note) in enumerate(CARDS, start=2):
        card_body(c, kicker, title, icon, items, i, total, note)
        c.showPage()
    c.save()
    OUT2.write_bytes(OUT.read_bytes())
    print("wrote", OUT, "pages", total, "bytes", OUT.stat().st_size)


if __name__ == "__main__":
    main()
