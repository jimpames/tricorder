package com.projecttricorder.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONObject
import java.io.File

/**
 * Internal copy is the restore source of truth on the same install.
 * Downloads copy is a sidecar that can survive uninstall.
 * Schema 1: prefs + field.jsonl + audio.jsonl + dictation + face blob.
 */
object BackupStore {
    const val SCHEMA = 1
    const val FILE_NAME = "tricorder-backup-v$SCHEMA.json"

    fun export(context: Context, faceJson: String?): JSONObject {
        val prefs = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
        val prefObj = JSONObject()
        prefs.all.forEach { (k, v) -> if (v != null) prefObj.put(k, v.toString()) }
        val root = JSONObject()
            .put("schema", SCHEMA)
            .put("app", "project-tricorder")
            .put("t_ms", System.currentTimeMillis())
            .put("prefs", prefObj)
            .put("field_jsonl", read(File(context.filesDir, "logs/field.jsonl")))
            .put("audio_jsonl", read(File(context.filesDir, "logs/audio.jsonl")))
            .put("dictation_json", read(File(context.filesDir, "dictation/memos.json")))
            .put("face", faceJson ?: "")
        val text = root.toString()
        val internalDir = File(context.filesDir, "backup").also { it.mkdirs() }
        val internal = File(internalDir, FILE_NAME)
        internal.writeText(text)

        var publicPath = writePublic(context, text)
        return JSONObject()
            .put("ok", true)
            .put("schema", SCHEMA)
            .put("bytes", text.length)
            .put("public", publicPath)
            .put("internal", internal.absolutePath)
    }

    fun import(context: Context): JSONObject {
        val tried = mutableListOf<String>()
        for (blob in loadCandidates(context)) {
            tried.add(blob.label + " " + blob.body.length + "b")
            val root = try { JSONObject(blob.body) } catch (e: Exception) {
                tried.add(blob.label + " parse:" + (e.message ?: "bad json"))
                continue
            }
            val sch = root.optInt("schema", -1)
            if (sch != SCHEMA) {
                tried.add(blob.label + " schema $sch")
                continue
            }
            if (root.optString("app") != "project-tricorder") {
                tried.add(blob.label + " not app")
                continue
            }
            val prefs = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE).edit()
            val po = root.optJSONObject("prefs") ?: JSONObject()
            po.keys().forEach { prefs.putString(it, po.optString(it)) }
            prefs.commit()
            write(File(context.filesDir, "logs/field.jsonl"), root.optString("field_jsonl"))
            write(File(context.filesDir, "logs/audio.jsonl"), root.optString("audio_jsonl"))
            write(File(context.filesDir, "dictation/memos.json"), root.optString("dictation_json"))
            return JSONObject()
                .put("ok", true)
                .put("schema", SCHEMA)
                .put("from", blob.label)
                .put("face", root.optString("face"))
        }
        return JSONObject()
            .put("ok", false)
            .put("error", "unreadable backup (" + tried.joinToString("; ").ifBlank { "no files" } + ")")
    }

    private data class Blob(val label: String, val body: String)

    private fun loadCandidates(context: Context): List<Blob> {
        val out = mutableListOf<Blob>()
        val internal = File(context.filesDir, "backup/$FILE_NAME")
        if (internal.exists() && internal.length() > 8) {
            try { out.add(Blob("internal", internal.readText())) } catch (_: Exception) {}
        }
        try {
            val pub = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ProjectTricorder/$FILE_NAME",
            )
            if (pub.exists() && pub.length() > 8) {
                try { out.add(Blob("downloads-file", pub.readText())) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val cr = context.contentResolver
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                cr.query(
                    uri,
                    arrayOf(MediaStore.Downloads._ID, MediaStore.Downloads.DISPLAY_NAME),
                    MediaStore.Downloads.DISPLAY_NAME + "=?",
                    arrayOf(FILE_NAME),
                    MediaStore.Downloads.DATE_MODIFIED + " DESC",
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0)
                        val item = android.content.ContentUris.withAppendedId(uri, id)
                        val body = cr.openInputStream(item)?.bufferedReader()?.readText() ?: continue
                        if (body.length > 8) out.add(Blob("mediastore", body))
                    }
                }
            } catch (_: Exception) {}
        }
        return out
    }

    private fun writePublic(context: Context, text: String): String {
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                val cr = context.contentResolver
                val uri = MediaStore.Downloads.EXTERNAL_CONTENT_URI
                cr.query(
                    uri,
                    arrayOf(MediaStore.Downloads._ID),
                    MediaStore.Downloads.DISPLAY_NAME + "=?",
                    arrayOf(FILE_NAME),
                    null,
                )?.use { c ->
                    while (c.moveToNext()) {
                        val item = android.content.ContentUris.withAppendedId(uri, c.getLong(0))
                        try { cr.delete(item, null, null) } catch (_: Exception) {}
                    }
                }
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, FILE_NAME)
                    put(MediaStore.Downloads.MIME_TYPE, "application/json")
                    put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ProjectTricorder")
                }
                val created = cr.insert(uri, values)
                if (created != null) {
                    cr.openOutputStream(created)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    return "Download/ProjectTricorder/$FILE_NAME"
                }
            } catch (_: Exception) {}
        }
        return try {
            val pub = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ProjectTricorder",
            ).also { it.mkdirs() }
            val f = File(pub, FILE_NAME)
            f.writeText(text)
            f.absolutePath
        } catch (_: Exception) {
            ""
        }
    }

    private fun read(f: File): String = try { if (f.exists()) f.readText() else "" } catch (_: Exception) { "" }
    private fun write(f: File, body: String) {
        if (body.isEmpty()) return
        f.parentFile?.mkdirs()
        f.writeText(body)
    }
}
