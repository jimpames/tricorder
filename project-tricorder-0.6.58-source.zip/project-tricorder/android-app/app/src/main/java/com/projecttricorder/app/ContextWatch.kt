package com.projecttricorder.app

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.ScheduledFuture
import java.util.concurrent.TimeUnit

class ContextWatch(private val context: Context) {
    private val exec = Executors.newSingleThreadScheduledExecutor()
    private var weatherJob: ScheduledFuture<*>? = null
    private var flightJob: ScheduledFuture<*>? = null
    private var citizenJob: ScheduledFuture<*>? = null
    private val seen = HashSet<String>()
    @Volatile private var citizenArmedNote = false
    @Volatile private var flags: Set<String> = emptySet()
    @Volatile private var running = false

    fun start(enabled: Set<String>, onAlert: (JSONObject) -> Unit) {
        stop()
        flags = enabled
        running = true
        if ("weather_alerts_noaa" in flags) {
            weatherJob = exec.scheduleWithFixedDelay({ safe { pollWeather(onAlert) } }, 2, 180, TimeUnit.SECONDS)
        }
        if ("flight_overhead" in flags) {
            flightJob = exec.scheduleWithFixedDelay({ safe { pollFlights(onAlert) } }, 4, 45, TimeUnit.SECONDS)
        }
        if ("crime_safety_citizen" in flags) {
            citizenJob = exec.scheduleWithFixedDelay({ safe { pollCitizen(onAlert) } }, 6, 120, TimeUnit.SECONDS)
        }
        if ("traffic_waze" in flags) {
            onAlert(
                JSONObject()
                    .put("kind", "context")
                    .put("source", "notice")
                    .put("text", "Waze has no public keyless feed — not polled."),
            )
        }
    }

    fun stop() {
        running = false
        weatherJob?.cancel(false); weatherJob = null
        flightJob?.cancel(false); flightJob = null
        citizenJob?.cancel(false); citizenJob = null
        citizenArmedNote = false
    }

    private fun safe(block: () -> Unit) {
        try { if (running) block() } catch (_: Exception) {}
    }

    @SuppressLint("MissingPermission")
    private fun lastFix(): Location? {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val gps = try { lm.getLastKnownLocation(LocationManager.GPS_PROVIDER) } catch (_: Exception) { null }
        val net = try { lm.getLastKnownLocation(LocationManager.NETWORK_PROVIDER) } catch (_: Exception) { null }
        return when {
            gps != null && net != null -> if (gps.time >= net.time) gps else net
            else -> gps ?: net
        }
    }

    private fun prefNum(key: String, def: Double): Double {
        val s = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE).getString(key, "") ?: ""
        return s.toDoubleOrNull() ?: def
    }
    private fun degFromKm(km: Double): Double = (km.coerceIn(3.0, 250.0) / 111.0)

    private fun pollWeather(onAlert: (JSONObject) -> Unit) {
        val loc = lastFix() ?: return
        val url = "https://api.weather.gov/alerts/active?point=${loc.latitude},${loc.longitude}"
        val body = httpGet(url, "ProjectTricorder/0.5.4 (field instrument; nws.alerts)") ?: return
        val features = JSONObject(body).optJSONArray("features") ?: return
        for (i in 0 until features.length()) {
            val f = features.optJSONObject(i) ?: continue
            val id = f.optString("id", "w$i")
            val p = f.optJSONObject("properties") ?: continue
            val sev = p.optString("severity")
            if (sev !in setOf("Severe", "Extreme", "Moderate")) continue
            if (!seen.add("wx:$id")) continue
            val event = p.optString("event", "Weather")
            val headline = p.optString("headline", event)
            val area = p.optString("areaDesc", "")
            val details = listOf(headline, area).filter { it.isNotBlank() }.joinToString(" — ")
            onAlert(
                JSONObject()
                    .put("kind", "context")
                    .put("source", "weather")
                    .put("event", event)
                    .put("severity", sev)
                    .put("text", details)
                    .put("hhmm", nowHhmm()),
            )
        }
    }

    private val routeCache = HashMap<String, JSONObject>()
    private val aircraftCache = HashMap<String, JSONObject>()

    private fun pollFlights(onAlert: (JSONObject) -> Unit) {
        val loc = lastFix() ?: return
        val d = degFromKm(prefNum("geo_flight_km", 28.0))
        val url =
            "https://opensky-network.org/api/states/all?lamin=${loc.latitude - d}&lomin=${loc.longitude - d}" +
                "&lamax=${loc.latitude + d}&lomax=${loc.longitude + d}"
        val body = httpGet(url, UA) ?: return
        val states = JSONObject(body).optJSONArray("states") ?: return
        var n = 0
        for (i in 0 until states.length()) {
            val row = states.optJSONArray(i) ?: continue
            val grounded = row.optBoolean(8, false)
            if (grounded) continue
            val icao = row.optString(0, "").trim()
            val call = row.optString(1, "").trim().ifBlank { "aircraft" }
            val alt = row.optDouble(7, Double.NaN)
            val vel = row.optDouble(9, Double.NaN)
            val key = "ac:${icao.ifBlank { call }}"
            if (!seen.add(key)) continue
            n += 1
            onAlert(enrichFlight(icao, call, alt, vel))
            if (n >= 6) break
        }
    }

    private fun enrichFlight(icao: String, call: String, alt: Double, vel: Double): JSONObject {
        val ac = lookupAircraft(icao, call)
        val route = lookupRoute(icao, call)
        val reg = ac.optString("registration").ifBlank { call }
        val photoUrl = ac.optString("url_photo_thumbnail").ifBlank { ac.optString("url_photo") }
            .ifBlank { planespotters(icao, reg) }
            .ifBlank { airportDataPhoto(icao) }
            .ifBlank { jetPhotos(reg) }
        val photoB64 = if (photoUrl.isNotBlank()) downloadThumb(photoUrl) else ""
        val origin = route.optJSONObject("origin") ?: JSONObject()
        val dest = route.optJSONObject("dest") ?: JSONObject()
        val originCity = origin.optString("city")
        val destCity = dest.optString("city")
        val originLabel = airportLabel(origin)
        val destLabel = airportLabel(dest)
        val altS = if (alt.isFinite()) "${alt.toInt()} m" else "?"
        val velS = if (vel.isFinite()) "${vel.toInt()} m/s" else ""
        val routePhrase = buildString {
            if (originLabel.isNotBlank()) append(" from ").append(originLabel)
            if (destLabel.isNotBlank()) append(" to ").append(destLabel)
        }
        val spoken = "$call $altS $velS$routePhrase".trim()
        return JSONObject()
            .put("kind", "context")
            .put("source", "flight")
            .put("event", "overhead")
            .put("text", spoken)
            .put("hhmm", nowHhmm())
            .put("icao24", icao)
            .put("callsign", call)
            .put("registration", reg)
            .put("type", ac.optString("type"))
            .put("icao_type", ac.optString("icao_type"))
            .put("manufacturer", ac.optString("manufacturer"))
            .put("owner", ac.optString("registered_owner"))
            .put("owner_country", ac.optString("registered_owner_country_name"))
            .put("mode_s", ac.optString("mode_s").ifBlank { icao })
            .put("photo_url", photoUrl)
            .put("photo", photoB64)
            .put("origin_city", originCity)
            .put("dest_city", destCity)
            .put("origin_label", originLabel)
            .put("dest_label", destLabel)
            .put("origin_iata", origin.optString("iata"))
            .put("dest_iata", dest.optString("iata"))
            .put("alt_m", if (alt.isFinite()) alt else JSONObject.NULL)
            .put("vel_ms", if (vel.isFinite()) vel else JSONObject.NULL)
    }

    private fun lookupAircraft(icao: String, call: String): JSONObject {
        val key = icao.lowercase().ifBlank { call.uppercase() }
        aircraftCache[key]?.let { return it }
        val id = icao.ifBlank { call }.replace(" ", "")
        if (id.isBlank() || id.equals("aircraft", true)) return JSONObject()
        val body = httpGet("https://api.adsbdb.com/v0/aircraft/$id", UA) ?: return JSONObject()
        val ac = try {
            JSONObject(body).optJSONObject("response")?.optJSONObject("aircraft") ?: JSONObject()
        } catch (_: Exception) {
            JSONObject()
        }
        aircraftCache[key] = ac
        return ac
    }

    private fun lookupRoute(icao: String, call: String): JSONObject {
        val key = icao.lowercase().ifBlank { call.uppercase() }
        routeCache[key]?.let { return it }
        val found = lookupAdsbdbRoute(call) ?: lookupOpenSkyRouteObj(icao) ?: JSONObject()
        routeCache[key] = found
        return found
    }

    private fun airportFields(obj: JSONObject?): JSONObject {
        val o = JSONObject()
        if (obj == null) return o
        val city = obj.optString("municipality").ifBlank { obj.optString("name") }
        val iata = obj.optString("iata_code").ifBlank { obj.optString("iata") }
        val icaoC = obj.optString("icao_code").ifBlank { obj.optString("icao") }
        o.put("city", city)
        o.put("iata", iata)
        o.put("icao", icaoC)
        o.put("name", obj.optString("name"))
        return o
    }

    private fun airportLabel(obj: JSONObject?): String {
        if (obj == null) return ""
        val city = obj.optString("city").ifBlank { obj.optString("municipality").ifBlank { obj.optString("name") } }
        val iata = obj.optString("iata").ifBlank { obj.optString("iata_code") }
        val icaoC = obj.optString("icao").ifBlank { obj.optString("icao_code") }
        return when {
            city.isNotBlank() && iata.isNotBlank() -> "$city $iata"
            city.isNotBlank() -> city
            iata.isNotBlank() -> iata
            icaoC.isNotBlank() -> icaoC
            else -> ""
        }
    }

    private fun lookupAdsbdbRoute(call: String): JSONObject? {
        val cs = call.replace(" ", "").uppercase()
        if (cs.isBlank() || cs == "AIRCRAFT") return null
        val body = httpGet("https://api.adsbdb.com/v0/callsign/$cs", UA) ?: return null
        val fr = JSONObject(body).optJSONObject("response")?.optJSONObject("flightroute") ?: return null
        return JSONObject()
            .put("origin", airportFields(fr.optJSONObject("origin") ?: fr.optJSONObject("departure")))
            .put("dest", airportFields(fr.optJSONObject("destination") ?: fr.optJSONObject("arrival")))
    }

    private fun lookupOpenSkyRouteObj(icao: String): JSONObject? {
        if (icao.isBlank()) return null
        val end = System.currentTimeMillis() / 1000
        val begin = end - 16 * 3600
        val body = httpGet(
            "https://opensky-network.org/api/flights/aircraft?icao24=${icao.lowercase()}&begin=$begin&end=$end",
            UA,
        ) ?: return null
        val arr = try { JSONArray(body) } catch (_: Exception) { return null }
        if (arr.length() == 0) return null
        val last = arr.optJSONObject(arr.length() - 1) ?: return null
        val dep = last.optString("estDepartureAirport", "")
        val dest = last.optString("estArrivalAirport", "")
        if (dep.isBlank() && dest.isBlank()) return null
        return JSONObject()
            .put("origin", JSONObject().put("icao", dep).put("city", dep))
            .put("dest", JSONObject().put("icao", dest).put("city", dest))
    }

    private fun airportDataPhoto(icao: String): String {
        val hex = icao.lowercase().replace(" ", "")
        if (hex.isBlank()) return ""
        val body = httpGet("https://www.airport-data.com/api/ac_thumb.json?m=$hex&n=1", UA) ?: return ""
        return try {
            val data = JSONObject(body).optJSONArray("data") ?: return ""
            data.optJSONObject(0)?.optString("image").orEmpty()
        } catch (_: Exception) {
            ""
        }
    }

    private fun jetPhotos(reg: String): String {
        val r = reg.replace(" ", "").uppercase()
        if (r.isBlank() || r == "AIRCRAFT") return ""
        val body = httpGet(
            "https://jp.rewis.workers.dev/?page=1&sort-order=0&keywords=$r&keywords-type=registration&keywords-contain=0",
            UA,
        ) ?: return ""
        return try {
            val photos = JSONObject(body).optJSONArray("photos") ?: return ""
            val first = photos.optJSONObject(0) ?: return ""
            first.optString("imageUrl").ifBlank { first.optString("thumbnailUrl") }
        } catch (_: Exception) {
            ""
        }
    }

    private fun planespotters(icao: String, reg: String): String {
        val hex = icao.lowercase()
        val urls = ArrayList<String>()
        if (hex.isNotBlank()) urls.add("https://api.planespotters.net/pub/photos/hex/$hex")
        if (reg.isNotBlank()) urls.add("https://api.planespotters.net/pub/photos/reg/$reg")
        for (u in urls) {
            val body = httpGet(u, UA) ?: continue
            try {
                val photos = JSONObject(body).optJSONArray("photos") ?: continue
                val first = photos.optJSONObject(0) ?: continue
                val src = first.optJSONObject("thumbnail_large")?.optString("src")
                    ?: first.optJSONObject("thumbnail")?.optString("src")
                    ?: ""
                if (src.isNotBlank()) return src
            } catch (_: Exception) { }
        }
        return ""
    }

    private fun downloadThumb(url: String): String {
        val bytes = httpGetBytes(url) ?: return ""
        if (bytes.size < 200) return ""
        return try {
            val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return ""
            val w = bmp.width.coerceAtMost(480)
            val h = if (bmp.width > 0) (bmp.height * w / bmp.width).coerceAtLeast(1) else bmp.height
            val scaled = if (w < bmp.width) Bitmap.createScaledBitmap(bmp, w, h, true) else bmp
            val out = ByteArrayOutputStream()
            scaled.compress(Bitmap.CompressFormat.JPEG, 72, out)
            val raw = out.toByteArray()
            if (raw.size > 280_000) return ""
            "data:image/jpeg;base64," + Base64.encodeToString(raw, Base64.NO_WRAP)
        } catch (_: Exception) {
            ""
        }
    }

    private val civicEvents = setOf(
        "civil emergency message", "civil danger warning", "law enforcement warning",
        "child abduction emergency", "amber alert", "911 telephone outage emergency",
        "shelter in place warning", "evacuation immediate", "fire warning",
        "hazardous materials warning", "nuclear power plant warning",
        "radiological hazard warning", "emergency action notification",
        "local area emergency", "administrative message",
    )

    private fun isCivicCap(p: JSONObject): Boolean {
        val event = p.optString("event", "").lowercase()
        val cat = p.optString("category", "")
        val resp = p.optString("response", "")
        val urg = p.optString("urgency", "")
        if (civicEvents.any { event.contains(it) }) return true
        if (cat.equals("Safety", true) || cat.equals("Security", true) ||
            cat.equals("Rescue", true) || cat.equals("Fire", true) || cat.equals("CBRNE", true)
        ) return true
        if (event.contains("amber") || event.contains("civil") || event.contains("abduction") ||
            event.contains("911") || event.contains("evacuation") || event.contains("shelter")
        ) return true
        if (resp.equals("Shelter", true) || resp.equals("Evacuate", true) || resp.equals("Avoid", true)) return true
        if (urg.equals("Immediate", true) && (event.contains("warning") || event.contains("emergency")) &&
            !event.contains("thunderstorm") && !event.contains("tornado") &&
            !event.contains("flood") && !event.contains("winter") && !event.contains("heat") &&
            !event.contains("wind") && !event.contains("fog")
        ) return true
        return false
    }

    private fun pollCitizen(onAlert: (JSONObject) -> Unit) {
        val loc = lastFix()
        if (loc == null) {
            if (!citizenArmedNote && seen.add("cz:nofix")) {
                citizenArmedNote = true
                onAlert(
                    JSONObject()
                        .put("kind", "context")
                        .put("source", "citizen")
                        .put("text", "Civic watch. Need GPS fix.")
                        .put("hhmm", nowHhmm()),
                )
            }
            return
        }
        // Public-safety CAP via NWS (IPAWS) — Citizen Inc. has no consumer API and no key to enter.
        val nws = httpGet(
            "https://api.weather.gov/alerts/active?point=${loc.latitude},${loc.longitude}",
            "ProjectTricorder/0.6.47 (field instrument; civic.alerts)",
        )
        var civicHits = 0
        if (nws != null) {
            val features = JSONObject(nws).optJSONArray("features") ?: JSONArray()
            for (i in 0 until features.length()) {
                val f = features.optJSONObject(i) ?: continue
                val id = f.optString("id", "c$i")
                val p = f.optJSONObject("properties") ?: continue
                if (!isCivicCap(p)) continue
                civicHits++
                if (!seen.add("cz:$id")) continue
                val event = p.optString("event", "civic")
                val headline = p.optString("headline", event)
                val area = p.optString("areaDesc", "")
                onAlert(
                    JSONObject()
                        .put("kind", "context")
                        .put("source", "citizen")
                        .put("event", event)
                        .put("text", listOf(headline, area).filter { it.isNotBlank() }.joinToString(" — "))
                        .put("hhmm", nowHhmm()),
                )
            }
        }
        if (!citizenArmedNote && seen.add("cz:armed")) {
            citizenArmedNote = true
            onAlert(
                JSONObject()
                    .put("kind", "context")
                    .put("source", "citizen")
                    .put("text", "Civic watch on. IPAWS, quakes, CityAlert. CAP hits $civicHits.")
                    .put("hhmm", nowHhmm()),
            )
        }
        val quake = httpGet(
            "https://earthquake.usgs.gov/fdsnws/event/1/query?format=geojson" +
                "&latitude=${loc.latitude}&longitude=${loc.longitude}&maxradiuskm=${prefNum("geo_quake_km", 400.0).toInt().coerceIn(50, 800)}&minmagnitude=3.0&limit=8&orderby=time",
            "ProjectTricorder/0.6.47",
        )
        if (quake != null) {
            val feats = JSONObject(quake).optJSONArray("features") ?: JSONArray()
            for (i in 0 until feats.length()) {
                val f = feats.optJSONObject(i) ?: continue
                val id = f.optString("id", "q$i")
                if (!seen.add("eq:$id")) continue
                val p = f.optJSONObject("properties") ?: continue
                val mag = p.optDouble("mag", Double.NaN)
                val place = p.optString("place", "quake")
                if (!mag.isFinite() || mag < 3.0) continue
                onAlert(
                    JSONObject()
                        .put("kind", "context")
                        .put("source", "citizen")
                        .put("event", "earthquake")
                        .put("text", "Magnitude ${"%.1f".format(mag)} earthquake — $place")
                        .put("hhmm", nowHhmm()),
                )
            }
        }
        pollCityAlert(loc, onAlert)
        pollSpotCrime(loc, onAlert)
    }

    private fun pollCityAlert(loc: android.location.Location, onAlert: (JSONObject) -> Unit) {
        val d = degFromKm(prefNum("geo_civic_km", 31.0))
        val bbox = "${loc.longitude - d},${loc.latitude - d},${loc.longitude + d},${loc.latitude + d}"
        val url = "https://cityalert.live/api/incidents?bbox=$bbox"
        val body = httpGet(url, "ProjectTricorder/0.6.52 (field instrument; civic)") ?: return
        val root = try { JSONObject(body) } catch (_: Exception) { return }
        val feats = root.optJSONArray("features") ?: JSONArray()
        var n = 0
        for (i in 0 until feats.length()) {
            if (n >= 6) break
            val f = feats.optJSONObject(i) ?: continue
            val p = f.optJSONObject("properties") ?: continue
            val id = p.optString("id", "ca$i")
            if (!seen.add("ca:$id")) continue
            val typ = p.optString("type", p.optString("category", "incident"))
            val title = p.optString("title", p.optString("description", typ))
            n++
            onAlert(
                JSONObject()
                    .put("kind", "context")
                    .put("source", "citizen")
                    .put("event", typ)
                    .put("category", p.optString("category", typ))
                    .put("id", id)
                    .put("text", title.take(240))
                    .put("hhmm", nowHhmm()),
            )
        }
    }

    private fun pollSpotCrime(loc: android.location.Location, onAlert: (JSONObject) -> Unit) {
        val key = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
            .getString("spotcrime_key", "")?.trim().orEmpty()
        if (key.isBlank()) return
        val url = "https://api.spotcrime.com/crimes.json?lat=${loc.latitude}&lon=${loc.longitude}&radius=2&key=${java.net.URLEncoder.encode(key, "UTF-8")}"
        val body = httpGet(url, "ProjectTricorder/0.6.50") ?: return
        val root = try { JSONObject(body) } catch (_: Exception) { return }
        val arr = root.optJSONArray("crimes") ?: root.optJSONArray("incidents") ?: JSONArray()
        var n = 0
        for (i in 0 until arr.length()) {
            if (n >= 6) break
            val c = arr.optJSONObject(i) ?: continue
            val id = c.optString("cdid", c.optString("id", "sc$i"))
            if (!seen.add("sc:$id")) continue
            val typ = c.optString("type", c.optString("offense", "incident"))
            val addr = c.optString("address", c.optString("addr", ""))
            val whenStr = c.optString("date", c.optString("when", ""))
            n++
            onAlert(
                JSONObject()
                    .put("kind", "context")
                    .put("source", "citizen")
                    .put("event", typ)
                    .put("text", listOf("SpotCrime $typ", addr, whenStr).filter { it.isNotBlank() }.joinToString(" — "))
                    .put("hhmm", nowHhmm()),
            )
        }
    }

    private fun nowHhmm(): String {
        val c = java.util.Calendar.getInstance()
        return "%02d:%02d".format(c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE))
    }

    private fun httpGetBytes(url: String): ByteArray? {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        return try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Accept", "image/*,application/octet-stream")
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.use { it.readBytes() }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    private fun httpGet(url: String, userAgent: String): String? {
        val conn = (URL(url).openConnection() as HttpURLConnection)
        return try {
            conn.connectTimeout = 8000
            conn.readTimeout = 8000
            conn.setRequestProperty("User-Agent", userAgent)
            conn.setRequestProperty("Accept", "application/json")
            if (conn.responseCode !in 200..299) return null
            conn.inputStream.bufferedReader().use { it.readText() }
        } catch (_: Exception) {
            null
        } finally {
            conn.disconnect()
        }
    }

    companion object {
        private const val UA = "ProjectTricorder/0.6.26 (+https://github.com/project-tricorder)"
    }
}
