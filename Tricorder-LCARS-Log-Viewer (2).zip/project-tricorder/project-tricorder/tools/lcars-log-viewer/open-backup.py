#!/usr/bin/env python3
"""Open a tricorder-backup-v2.zip in the LCARS viewer (Windows / any OS)."""
from __future__ import annotations

import base64
import sys
import webbrowser
from pathlib import Path

HERE = Path(__file__).resolve().parent
HTML = HERE / "Tricorder-LCARS.html"


def main() -> int:
    if not HTML.exists():
        print("missing", HTML)
        return 1
    html = HTML.read_text(encoding="utf-8")
    if len(sys.argv) < 2:
        webbrowser.open(HTML.as_uri())
        return 0
    src = Path(sys.argv[1]).expanduser()
    if not src.exists():
        print("not found", src)
        return 1
    b64 = base64.b64encode(src.read_bytes()).decode("ascii")
    inject = f"<script>window.__TC_BACKUP_B64={b64!r};</script>\n</body>"
    out = html.replace("</body>", inject, 1)
    dest = HERE / "_last-opened.html"
    dest.write_text(out, encoding="utf-8")
    webbrowser.open(dest.as_uri())
    print("opened", src.name, "schema zip", src.stat().st_size, "bytes")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
