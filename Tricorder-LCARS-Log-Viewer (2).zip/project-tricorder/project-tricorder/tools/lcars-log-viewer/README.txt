PROJECT TRICORDER MK. I — LCARS log viewer
N2NHU Labs · Windows 11 companion for tricorder-backup-v2.zip

Drop the zip on open-backup.bat
  or double-click Tricorder-LCARS.html and drop the zip on the orange well
  or:  python open-backup.py "C:\Users\you\Downloads\tricorder-backup-v2.zip"

Needs a current Edge / Chrome / Firefox. Python is optional (only for the
.bat drop-target that preloads the archive).

Decodes schema 2:
  meta.json     callsign, prefs, face
  field.jsonl   sensor / sentry / spoken book
  audio.jsonl   YAMNet + BirdNET
  flights.json  overhead cards
  civic.json    CityAlert / IPAWS / watch
  memos.json    dictation (if present)

Photos load from photo_url when the PC is on the net. Embedded JPEGs in
the zip are not rendered in this pass (the tube already stores the URL).
