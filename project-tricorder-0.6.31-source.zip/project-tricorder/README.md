# Project Tricorder — Status & Handoff
*Last updated: 13 Sep 2026 · software 0.6.29*

## Sprint 13 Sep 2026 — knowledge banks + overhead cards

Mk I now treats an overhead contact as an object you can inspect, and treats Memory Alpha / MEDICAL as spoken reference banks rather than another menu.

### Memory Alpha
- Inquiry only. No face button. Say **`MEMORY ALPHA`** or, in one breath, **`memory alpha Airbus A320`**.
- Simple English Wikipedia titles and extracts, English Wikipedia fallback, local article cache.
- Bare wake opens the bank, speaks “online, speak a search,” and arms the mic. `TERMINATE` or CLOSE leaves.
- Typed SEARCH field on the sheet if you do not want to talk.

### MEDICAL
- Same voice pattern: **`MEDICAL`** or **`medical pink eye`** / **`medical puncture wound`**.
- WikiMed (`mdwiki.org`) is the title catalog only. Its REST article API is Cloudflare-blocked from the phone, which is why early builds showed titles and nothing else.
- Body text and photographs load from English Wikipedia. Related titles stay tappable.
- This is a field briefing, not a clinician.

### Overhead flight card
Audio Sense + aircraft watch + Earth link + a GPS fix.
- OpenSky box around the last fix, adsbdb type / owner / tail, route when published.
- Photograph, in order: adsbdb thumb → Planespotters hex/reg → airport-data Mode-S → JetPhotos worker. JPEG is written into the field log.
- **FROM / TO** cities are buttons.
- **Photo** or **AIRFRAME FACTS** opens the type / owner / Mode-S / Wikipedia card. The same photo rides on that card.
- Robot voice, metric or English from Settings, departure and destination spoken when known.

### City dossiers
Touch FROM or TO.
- Wikipedia extract and thumbnail.
- REST Countries (capital, population, region) when a country can be guessed.
- CIA World Factbook snippet when the country is in the onboard GEC table.
- Spoken.
- **BACK TO AIRFRAME** restores the same craft photo so the other city can be opened.

### Pin, do not flash
YAMNet was rewriting the CRT every dwell and wiping the picture. The card is pinned until **DISMISS AIRFRAME**. Audio still classifies and can still speak gunfire / siren / vehicle lines. CLOSE on the city or airframe sheet also restores a pinned card.

### Help / manual
Help sheet, spoken `HELP`, and on-device `manual.html` match Field Operations Manual Rev 0.6.28. Sideload **0.6.29** for that briefing on the phone.

---


## TL;DR: what exists and what doesn't yet

**Exists and works today:** a tested, config-driven routing/event core (`tricorder-core`, 93 passing tests) and a self-contained browser UI shell (`ui-shell/tricorder-ui-shell.html`) that runs the same architecture live in a phone browser, with real camera, real device-motion sensors, real Bluetooth device detection, a real settings page, and an optional real connection to a llama-server backend.

**Exists now: a sideloadable debug APK.** `android-app/` is a Kotlin WebView wrapper that bundles `ui-shell/tricorder-ui-shell.html` as an asset. The compiled debug build is `Tricorder-debug.apk` (package `com.projecttricorder.app`, minSdk 26). UWB, NFC, and ambient BLE scanning are still *not* wired — those remain native-bridge follow-ups — but the app installs, launches the TOS shell, can use the camera/mic/location permission prompts, talks cleartext to a Termux `llama-server` on `127.0.0.1`, and exposes fold posture through `window.TricorderNative`.

---

## 1. What's in this zip

```
project-tricorder/
├── README.md                          (this file)
├── docs/
│   ├── tricorder-design-doc.md        Original architecture spec (config-driven,
│   │                                   algebraic tuple routing, API-first, MCP-based)
│   └── tricorder-llama-server-setup.md  Termux + llama-server setup guide for the Fold 3
├── tricorder-core/                    Platform-agnostic core logic (Node package)
│   ├── src/
│   │   ├── eventBus.mjs               Pub/sub spine
│   │   ├── configLoader.mjs           Loads/validates/hot-reloads the config document
│   │   ├── tupleEngine.mjs            Deterministic (Mode,InputChannel,TargetModality,Action) router
│   │   ├── mcpClient.mjs              Resolves a route to a backend, calls it, handles fallback
│   │   ├── payloadBuilder.mjs         Shapes requests per backend protocol (openai_chat_vision, etc.)
│   │   ├── sensorLoopDriver.mjs       Scan-loop (Sensor) / guard-loop (Sentry) behavior
│   │   ├── contextProviderPoller.mjs  Generic repeating fetch-and-normalize loop for context providers
│   │   └── providers/noaaWeatherAlerts.mjs   First real (non-stubbed) context provider
│   ├── config/tricorder.config.json   Reference config: 3 buttons, 4 tuple rules, 5 providers
│   ├── test/                          93 tests, zero network calls, zero dependencies
│   └── README.md                      Module-by-module docs + "suggested next steps"
├── ui-shell/
│   └── tricorder-ui-shell.html        Interactive browser demo — see §2
└── android-app/                       Kotlin WebView wrapper → sideloadable APK
    ├── BUILD.md                       How to rebuild in Android Studio / Gradle
    └── Tricorder-debug.apk            Debug APK produced this session (when present)
```

Run the tests: `cd tricorder-core && npm test`

---

## 2. The UI shell — what's real, what's demo, what's structurally impossible in a browser

Open `ui-shell/tricorder-ui-shell.html` directly in your phone's browser (not an in-app/chat preview — those sandbox camera and localhost access).

| Feature | Status |
|---|---|
| TOS-prop visual design (screen, 3 lights, 3 switches, speaker grille) | Real, done |
| Event bus / tuple engine / sensor-loop logic | Real — a browser-side port of the exact same logic as `tricorder-core`, kept in sync deliberately |
| Settings page (models, buttons, tuple rules, providers, raw JSON) | Real, fully editable, live-applying, validated the same way `ConfigLoader` validates in the Node package |
| Chat/vision responses | **Demo (canned) by default.** Flip "Response source" to "Real llama-server" in Backend & Camera to get actual `fetch()` calls — requires your own `llama-server` running (see `docs/tricorder-llama-server-setup.md`) |
| Camera (Sensor/Sentry vision frames) | Real `getUserMedia`, real frame capture, real pixel-diff motion detection — only activates in Real mode |
| Accelerometer / gyro / compass telemetry | Real `DeviceMotionEvent`/`DeviceOrientationEvent` — fused into Sentry mode's escalation logic alongside the camera signal |
| Nearby Bluetooth device detection | Real `Web Bluetooth` — opens the browser's native device picker, reports the chosen device's name/battery. **Not** ambient "someone walked up" radar — see the in-app hint for why (MAC/name randomization is intentional on modern phones) |
| Wi-Fi scanning | **No browser API exists for this at all.** Not a limitation of this build — there's nothing to build. |
| UWB ranging, NFC, raw fingerprint, fold posture/hinge angle | **No browser API exists for any of these.** This is the hard wall that requires native code — see §3. |

---

## 3. What remains before you can sideload an APK

This is the honest gap. Three sub-parts, roughly in order:

### 3a. A real Android project exists (WebView wrapper)
`android-app/` is a Gradle/Android Studio project. Sideload `Tricorder-debug.apk`. Rebuild with `gradle assembleDebug` (see `android-app/BUILD.md`).

The realistic longer-term paths, cheapest to most expensive:

1. **WebView wrapper (recommended starting point).** A minimal Kotlin app with one `Activity` hosting a `WebView` that loads `tricorder-ui-shell.html` (bundled as an asset) almost unchanged, plus a `@JavascriptInterface`-annotated bridge class exposing the native-only things (WindowManager posture, UWB, NFC, real background BLE scanning) as callable JS functions. This reuses ~90% of the UI work already done and is the fastest path to something sideloadable.
2. **React Native rewrite.** Re-implements the UI shell's screen in RN, gets real native modules for camera/BLE "for free" via community libraries, but WindowManager/UWB still need a custom native module either way, and the distinctive HTML/CSS visual work would need re-doing in RN/Tailwind-equivalent styling.
3. **Full native Kotlin (Jetpack Compose) rewrite.** Most "correct" long-term, most expensive — the CRT screen, toggle switches, etc. all get rebuilt as Compose UI.

None of this exists yet as a single line of Kotlin or a `build.gradle` file. That's the actual next milestone.

### 3b. Native bridge code for the sensors that matter
Whichever path above is chosen, someone has to write:
- A `FoldingFeature`/`WindowInfoTracker` listener (Jetpack WindowManager) for fold posture — coarse `FLAT`/`HALF_OPENED` + orientation, **not** a numeric hinge angle (that's not exposed by this API at all, contrary to what the pasted spec sheet implied).
- A UWB ranging session (`androidx.core.uwb`) if you want that feature — genuinely more involved, requires a second UWB-capable device to range against, not just "detect UWB exists."
- Real background BLE scanning (`BluetoothLeScanner`), which is what actually gets you continuous "device came into range" behavior instead of Web Bluetooth's one-shot picker.
- A foreground service if you want Sentry mode to keep running while the app is backgrounded/screen off — Android will kill background work otherwise.

### 3c. Build tooling
- Android SDK + Gradle need to be installed **somewhere with a build environment** — Android Studio on a PC/Mac is the practical option; building a full Android app inside Termux directly is possible but painful (SDK components, NDK, licensing prompts).
- Once a project exists, `./gradlew assembleDebug` produces an unsigned debug `.apk` — that's the one you sideload. No Play Store signing needed for personal sideloading.
- **I cannot produce a compiled `.apk` from this chat environment** — no Android SDK, no Gradle, and the sandboxed network here can't reach the SDK manager's download servers even if I tried. What I *can* do next session is write the actual Kotlin/Gradle project source as text files, ready to drop into Android Studio — the same way `tricorder-core`'s source was written and tested here, just without the "run it and see it pass" step, since that step needs a real Android toolchain.

---

## 4. Suggested order for next session

1. Decide WebView-wrapper vs. RN vs. full-native (recommendation: WebView wrapper — cheapest path to "something on the phone").
2. I write the Android project skeleton (Gradle files, manifest, minimal `MainActivity` + `WebView` + JS bridge stub functions) as text, here.
3. You build it in Android Studio, confirm the existing HTML shell loads and runs inside the WebView unmodified.
4. Wire the JS bridge functions one at a time: WindowManager posture first (easiest, most self-contained), then real BLE scanning, then UWB/NFC if still wanted.
5. Real `llama-server` connection test on-device (this part is already fully built and waiting — see `docs/tricorder-llama-server-setup.md`).

Everything in `tricorder-core` and the UI shell stays exactly as useful either way — the Android wrapper calls into the same JS, the same event names, the same config shape. Nothing done today gets thrown away.
