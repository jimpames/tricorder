/* SOL SYSTEM — press 1 space, 2 earth, 3 moon, 4 off */
(function () {
  const PLANETS = [
    { name: 'Mercury', a: 0.387, p: 87.969, L0: 252.25, col: '#b8b0a0' },
    { name: 'Venus', a: 0.723, p: 224.701, L0: 181.98, col: '#e8c98a' },
    { name: 'Earth', a: 1.000, p: 365.256, L0: 100.46, col: '#6ec8ff' },
    { name: 'Mars', a: 1.524, p: 686.980, L0: 355.45, col: '#ff6b4a' },
    { name: 'Jupiter', a: 5.203, p: 4332.59, L0: 34.40, col: '#d4a574' },
    { name: 'Saturn', a: 9.537, p: 10759.2, L0: 50.00, col: '#e6d9a8' },
  ];
  const GROUPS = [
    ['80m-40m', '80 / 40'],
    ['30m-20m', '30 / 20'],
    ['17m-15m', '17 / 15'],
    ['12m-10m', '12 / 10'],
  ];
  let mode = 'off';
  let snap = null;
  let raf = 0;

  function $(id) { return document.getElementById(id); }
  function loadSnap() {
    try {
      const raw = window.TricorderNative && TricorderNative.solSnapshot && TricorderNative.solSnapshot();
      snap = raw ? JSON.parse(raw) : null;
    } catch { snap = null; }
    return snap;
  }
  function daysJ2000(d) { return (d.getTime() / 86400000) - 10957.5; }
  function lonDeg(pl, date) {
    return ((pl.L0 + (360 / pl.p) * daysJ2000(date)) % 360 + 360) % 360;
  }
  function band(ham, name, time) {
    const b = (ham && ham.bands) || {};
    return b[name + '_' + time] || b[name.split('-')[0] + '_' + time] || '—';
  }
  function kpNum(ham, kp) {
    const v = parseFloat((ham && ham.kindex) || (kp && (kp.kp_index || kp.estimated_kp)) || 'NaN');
    return isFinite(v) ? v : 0;
  }
  function uhfLine(ham, kp) {
    const k = kpNum(ham, kp);
    if (k >= 7) return 'UHF aurora  scintillation likely';
    if (k >= 5) return 'UHF aurora  possible scintillation';
    return 'UHF aurora  quiet / line of sight';
  }

  const PHASES = [
    'New Moon', 'Waxing Crescent', 'First Quarter', 'Waxing Gibbous',
    'Full Moon', 'Waning Gibbous', 'Last Quarter', 'Waning Crescent',
  ];
  function moonState(date) {
    const syn = 29.530588853;
    const known = Date.UTC(2000, 0, 6, 18, 14, 0);
    let age = ((date.getTime() - known) / 86400000) % syn;
    if (age < 0) age += syn;
    const slice = syn / 8;
    const idx = Math.min(7, Math.floor(age / slice + 0.5) % 8);
    // nearest-center index: use floor of age/slice for "current phase window"
    const win = Math.min(7, Math.floor(age / slice));
    const into = age - win * slice;
    const left = slice - into;
    const prev = PHASES[(win + 7) % 8];
    const next = PHASES[(win + 1) % 8];
    const illum = (1 - Math.cos(2 * Math.PI * age / syn)) / 2;
    return { age, syn, slice, win, name: PHASES[win], prev, next, into, left, illum };
  }
  function moonLine() {
    const m = moonState(new Date());
    return m.name + '  ' + Math.round(m.illum * 100) + '% lit  next ' + m.next + ' in ' + m.left.toFixed(1) + ' d';
  }
  function moonBrief() {
    const m = moonState(new Date());
    return ('Moon phase ' + m.name +
      ' Illumination ' + Math.round(m.illum * 100) + ' percent' +
      ' Age ' + m.age.toFixed(1) + ' days of ' + m.syn.toFixed(2) +
      ' This phase lasts about ' + m.slice.toFixed(2) + ' days' +
      ' ' + m.into.toFixed(1) + ' days into it' +
      ' ' + m.left.toFixed(1) + ' days remain' +
      ' Phase just ended ' + m.prev +
      ' Next phase ' + m.next).replace(/\./g, ' ');
  }
  function paintMoon(ctx, w, h) {
    const m = moonState(new Date());
    ctx.fillStyle = '#05080f';
    ctx.fillRect(0, 0, w, h);
    const cx = w * 0.28, cy = h * 0.46, r = Math.min(w, h) * 0.22;
    ctx.fillStyle = '#d8c9a0';
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#05080f';
    const phase = (m.age / m.syn);
    ctx.save();
    ctx.beginPath(); ctx.arc(cx, cy, r + 1, 0, Math.PI * 2); ctx.clip();
    if (phase <= 0.5) {
      const k = 1 - phase * 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, Math.abs(k) * r, r, 0, -Math.PI / 2, Math.PI / 2, k < 0);
      ctx.rect(cx - r, cy - r, r, 2 * r);
      ctx.fill();
    } else {
      const k = (phase - 0.5) * 2;
      ctx.beginPath();
      ctx.ellipse(cx, cy, k * r, r, 0, Math.PI / 2, 3 * Math.PI / 2, false);
      ctx.rect(cx, cy - r, r, 2 * r);
      ctx.fill();
    }
    ctx.restore();
    ctx.strokeStyle = '#7dffb0';
    ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
    ctx.font = '11px "IBM Plex Mono", monospace';
    const x = w * 0.52;
    let y = 22;
    const line = (t, col) => { ctx.fillStyle = col || '#d8ffe8'; ctx.fillText(String(t).slice(0, 42), x, y); y += 14; };
    line('MOON PHASE', '#7dffb0');
    line(m.name, '#ffb454');
    line(Math.round(m.illum * 100) + '% illuminated');
    line('age ' + m.age.toFixed(1) + ' d  /  ' + m.syn.toFixed(2) + ' d');
    line('this phase ~' + m.slice.toFixed(2) + ' d');
    line(m.into.toFixed(1) + ' d in   ' + m.left.toFixed(1) + ' d left');
    line('ended  ' + m.prev);
    line('next   ' + m.next);
  }

  function briefing() {
    const s = snap || {};
    const ham = s.ham || {};
    const earth = s.earth || {};
    if (mode === 'moon') return moonBrief();
    if (mode === 'earth') {
      const city = earth.city || 'this site';
      const hours = (earth.hourly || []).slice(0, 6).map((p) => {
        const hh = String(p.t || '').slice(11, 16);
        return hh + ' ' + p.temp + (p.unit || '') + ' ' + p.wx;
      }).join(' ');
      const days = (earth.outlook || []).slice(0, 6).map((p) => (p.name || '') + ' ' + (p.wx || '')).join(' ');
      return ('Earth weather at ' + city + ' Next hours ' + hours + ' Outlook ' + days).replace(/\./g, ' ');
    }
    const hf = GROUPS.map((g) => g[1] + ' day ' + band(ham, g[0], 'day') + ' night ' + band(ham, g[0], 'night')).join(' ');
    return ('Sol system Solar flux ' + (ham.solarflux || '—') + ' sunspots ' + (ham.sunspots || '—')
      + ' K index ' + (ham.kindex || '—') + ' X ray ' + (ham.xray || '—')
      + ' HF ' + hf + ' VHF aurora ' + (ham.vhfaurora || '—') + ' ' + uhfLine(ham, s.kp_latest)).replace(/\./g, ' ');
  }

  function drawOrbits(ctx, w, h) {
    const cx = w * 0.28, cy = h * 0.52, maxR = Math.min(w * 0.26, h * 0.44);
    const now = new Date();
    ctx.fillStyle = '#ffcc66';
    ctx.beginPath(); ctx.arc(cx, cy, 7, 0, Math.PI * 2); ctx.fill();
    ctx.fillStyle = '#ffb454';
    ctx.font = '9px "IBM Plex Mono", monospace';
    ctx.fillText('SOL', cx - 8, cy + 18);
    PLANETS.forEach((pl) => {
      const r = 12 + (pl.a / 9.6) * (maxR - 12);
      ctx.strokeStyle = '#1c4a33';
      ctx.beginPath(); ctx.arc(cx, cy, r, 0, Math.PI * 2); ctx.stroke();
      const th = lonDeg(pl, now) * Math.PI / 180;
      const x = cx + Math.cos(th) * r;
      const y = cy + Math.sin(th) * r;
      ctx.fillStyle = pl.col;
      ctx.beginPath(); ctx.arc(x, y, (pl.name === 'Jupiter' || pl.name === 'Saturn') ? 4 : 2.6, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#9ad4b0';
      ctx.fillText(pl.name[0], x + 5, y - 3);
    });
  }

  function paintSpace(ctx, w, h) {
    drawOrbits(ctx, w, h);
    const s = snap || {};
    const ham = s.ham || {};
    const kp = s.kp_latest || {};
    ctx.font = '10px "IBM Plex Mono", monospace';
    const x = w * 0.52;
    let y = 14;
    const line = (t, col) => { ctx.fillStyle = col || '#d8ffe8'; ctx.fillText(String(t).slice(0, 44), x, y); y += 13; };
    line('SOL CYCLE / SPACE WX  NOAA SWPC', '#7dffb0');
    line('SFI ' + (ham.solarflux || '—') + '  SSN ' + (ham.sunspots || '—') + '  A ' + (ham.aindex || '—'));
    line('Kp ' + (ham.kindex || kp.kp_index || '—') + '  Bz ' + (ham.magneticfield || '—') + '  wind ' + (ham.solarwind || '—'));
    line('X-ray ' + (ham.xray || '—') + '  aurora ' + (ham.aurora || '—'));
    y += 4;
    line('HF PROPAGATION  HamQSL', '#ffb454');
    GROUPS.forEach((g) => {
      line(g[1] + '  day ' + band(ham, g[0], 'day') + '   night ' + band(ham, g[0], 'night'));
    });
    y += 4;
    line('VHF aurora  ' + (ham.vhfaurora || '—'), '#6ec8ff');
    line(uhfLine(ham, kp), '#6ec8ff');
    line('geomag ' + (ham.geomagfield || '—') + '  S/N ' + (ham.signalnoise || '—'));
    if (!s.at) line('No snapshot — Fetch SOL wx', '#ffb454');
  }

  function fillEarth() {
    const box = $('solEarth');
    if (!box) return;
    const s = snap || {};
    const earth = s.earth || {};
    const lines = [];
    lines.push('EARTH WEATHER  NWS');
    lines.push((earth.city || '') + '  office ' + (earth.office || ''));
    lines.push('');
    lines.push('Next six hours');
    (earth.hourly || []).slice(0, 6).forEach((p) => {
      const hh = String(p.t || '').slice(11, 16);
      lines.push(hh + '   ' + p.temp + (p.unit || '') + '   ' + (p.wind || '') + '   ' + (p.wx || ''));
    });
    lines.push('');
    lines.push('Today + next 2 days');
    (earth.outlook || []).slice(0, 6).forEach((p) => {
      lines.push((p.name || '') + '  ' + p.temp + '  ' + (p.wx || ''));
      if (p.detail) lines.push('  ' + p.detail);
    });
    if (!earth.hourly) lines.push('No NWS snapshot — Fetch SOL wx');
    box.textContent = lines.join('\n');
  }

  function tick() {
    if (mode === 'off') { raf = 0; return; }
    const c = $('solCanvas');
    if (!c) return;
    const ctx = c.getContext('2d');
    ctx.fillStyle = '#05080f';
    ctx.fillRect(0, 0, c.width, c.height);
    if (mode === 'space') paintSpace(ctx, c.width, c.height);
    if (mode === 'moon') paintMoon(ctx, c.width, c.height);
    raf = requestAnimationFrame(tick);
  }

  function paintButton() {
    const b = $('solBtn');
    const lab = $('solModeLbl');
    if (b) {
      b.classList.toggle('horizon-on', mode !== 'off');
      b.classList.toggle('horizon-off', mode === 'off');
    }
    if (lab) lab.textContent = mode === 'off' ? 'off' : (mode === 'space' ? 'sol' : (mode === 'earth' ? 'wx' : 'moon'));
  }

  function cycle() {
    if (mode === 'off') mode = 'space';
    else if (mode === 'space') mode = 'earth';
    else if (mode === 'earth') mode = 'moon';
    else mode = 'off';
    loadSnap();
    const c = $('solCanvas');
    const bar = $('solBar');
    const earth = $('solEarth');
    if (c) c.style.display = (mode === 'space' || mode === 'moon') ? 'block' : 'none';
    if (earth) earth.style.display = mode === 'earth' ? 'block' : 'none';
    if (bar) bar.style.display = mode === 'off' ? 'none' : 'flex';
    if (mode === 'earth') fillEarth();
    paintButton();
    if (typeof setScreen === 'function') {
      if (mode === 'space') setScreen('SOL SYSTEM\norbits + space weather + HF/VHF/UHF');
      else if (mode === 'earth') setScreen('EARTH WEATHER\nsix hours + today and next two days');
      else if (mode === 'moon') setScreen('MOON PHASE\n' + moonLine());
    }
    if (mode !== 'off') {
      try { if (typeof speak === 'function') speak(briefing(), { force: true }); } catch {}
      if (!raf) tick();
    }
  }

  function wire() {
    const b = $('solBtn');
    if (b) b.addEventListener('click', cycle);
    const f = $('fetchSol');
    if (f) f.addEventListener('click', () => { try { TricorderNative.fetchSol(); } catch {} });
    paintButton();
  }
  window.__tricorderSol = (raw) => { try { snap = JSON.parse(raw); } catch { loadSnap(); } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', wire);
  else wire();
})();
