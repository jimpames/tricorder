package com.projecttricorder.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Bundle as OsBundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.ToneGenerator
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.os.SystemClock
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.CountDownLatch
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var bridge: TricorderBridge
    private var speechRecognizer: SpeechRecognizer? = null
    private var ttsPlayer: MediaPlayer? = null
    private val ttsExecutor = Executors.newSingleThreadExecutor()
    private val kokoroGen = AtomicInteger(0)
    @Volatile private var kokoroConn: HttpURLConnection? = null
    private var audioSense: AudioSense? = null
    private val audioLog = AudioLog(this)
    private val birdNet = BirdNetStore(this)
    private val floraStore = FloraStore(this)
    private val dictationStore = DictationStore(this)
    private val fieldLog = FieldLog(this)
    private val contextWatch = ContextWatch(this)
    private val knowledgeStore = KnowledgeStore(this)
    @Volatile private var lastFlightJson: String = "{}"
    private val translateStore = TranslateStore()
    private var translateTts: TextToSpeech? = null
    private var alertTts: TextToSpeech? = null
    @Volatile private var alertTtsReady = false
    private var translateRec: SpeechRecognizer? = null
    @Volatile private var translateOn = false
    @Volatile private var xlatSrc = "en"
    @Volatile private var xlatTgt = "es"
    @Volatile private var translateAuto = true
    private val videoLog = VideoLog(fieldLog)
    private var nearbyLink: NearbyLink? = null
    private var meshLink: MeshLink? = null
    @Volatile private var pressureHpa: Double? = null
    @Volatile private var ambientC: Double? = null
    @Volatile private var humidityPct: Double? = null
    @Volatile private var imuGx: Float = 0f
    @Volatile private var imuGy: Float = 0f
    @Volatile private var imuGz: Float = 9.8f
    @Volatile private var imuHeading: Double? = null
    @Volatile private var gpsAltM: Double? = null
    @Volatile private var lastImuPushMs: Long = 0L
    private val rotMat = FloatArray(9)
    private val oriAng = FloatArray(3)
    @Volatile private var earthLink: Boolean? = null
    @Volatile var groundSpeedMps: Double = Double.NaN
    @Volatile var lastLat: Double = Double.NaN
    @Volatile var lastLon: Double = Double.NaN
    private var speedStarted = false
    private var gnssStarted = false
    @Volatile private var gnssUtcNanos: Long = 0L
    @Volatile private var gnssElapsedNanos: Long = 0L
    @Volatile private var gnssUncNs: Double = Double.NaN
    @Volatile private var gnssLeap: Int = 18
    @Volatile private var gnssLocked: Boolean = false
    @Volatile private var gnssDiscont: Int = -1
    @Volatile private var gnssSatCount: Int = 0
    private val tleStore = TleStore(this)
    private val solStore = SolStore(this)
    private var sensorManager: SensorManager? = null
    private val envListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent?) {
            val e = event ?: return
            when (e.sensor.type) {
                Sensor.TYPE_PRESSURE -> pressureHpa = e.values[0].toDouble()
                Sensor.TYPE_AMBIENT_TEMPERATURE -> ambientC = e.values[0].toDouble()
                Sensor.TYPE_RELATIVE_HUMIDITY -> humidityPct = e.values[0].toDouble()
                Sensor.TYPE_GRAVITY -> {
                    imuGx = e.values[0]; imuGy = e.values[1]; imuGz = e.values[2]
                    pushImu()
                }
                Sensor.TYPE_ACCELEROMETER -> {
                    if (imuGz == 9.8f && kotlin.math.abs(e.values[2]) > 0.1f) {
                        imuGx = e.values[0]; imuGy = e.values[1]; imuGz = e.values[2]
                        pushImu()
                    }
                }
                Sensor.TYPE_ROTATION_VECTOR -> {
                    try {
                        SensorManager.getRotationMatrixFromVector(rotMat, e.values)
                        SensorManager.getOrientation(rotMat, oriAng)
                        var deg = Math.toDegrees(oriAng[0].toDouble())
                        if (deg < 0) deg += 360.0
                        imuHeading = deg
                        pushImu()
                    } catch (_: Exception) {}
                }
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { startGroundSpeed(); startGnssClock() }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bridge = TricorderBridge(this)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.setGeolocationEnabled(true)
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.userAgentString = settings.userAgentString + " TricorderNative/0.1"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = false
            }
            addJavascriptInterface(bridge, "TricorderNative")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest,
                ): Boolean = false

                override fun onPageFinished(view: WebView, url: String?) {
                    injectNativeBanner()
                    if (url != null && url.contains("tricorder-ui-shell")) {
                        Thread { bootstrapInit() }.start()
                        try { startComlink() } catch (_: Exception) {}
                    }
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    request.grant(request.resources)
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?,
                ) {
                    callback?.invoke(origin, true, false)
                }
            }
        }

        setContentView(webView)
        requestRuntimePermissions()
        observeFoldPosture()
        startEnvSensors()
        startGroundSpeed()
        startGnssClock()
        ttsExecutor.execute { earthLink = probeEarthLink() }
        webView.loadUrl("file:///android_asset/www/tricorder-ui-shell.html")
    }

    private fun injectNativeBanner() {
        val js = """
            (function () {
              try {
                window.__TRICORDER_NATIVE__ = true;
                /* nameplate stays clean — no wrapper badge */
              } catch (e) {}
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun termuxInstalled(): Boolean {
        return try {
            packageManager.getPackageInfo("com.termux", 0)
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun probePort(port: Int): Boolean {
        return try {
            val s = java.net.Socket()
            s.connect(java.net.InetSocketAddress("127.0.0.1", port), 400)
            s.close()
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun copyBootstrapScript() {
        try {
            val out = File(getExternalFilesDir(null) ?: filesDir, "tricorder-start.sh")
            assets.open("termux/tricorder.sh").use { inp ->
                out.outputStream().use { inp.copyTo(it) }
            }
            out.setReadable(true, false)
        } catch (_: Exception) {}
    }

    fun packStatusJson(): String {
        return org.json.JSONObject()
            .put("birdnet", birdNet.status())
            .put("flora", floraStore.status())
            .put("translate", translateStore.status())
            .put("termux", termuxInstalled())
            .put("earth_link", earthLink == true)
            .put("chat", probePort(8080))
            .put("vision", probePort(8081))
            .put("image", probePort(8188))
            .put("tts", probePort(5000))
            .put("tle", tleStore.status())
            .put("sol", solStore.ready())
            .put("dictation", dictationStore.status())
            .put("knowledge", knowledgeStore.status())
            .toString()
    }

    private fun bootstrapInit() {
        pushJs("window.__tricorderNote && window.__tricorderNote('Initializing tricorder…')")
        earthLink = probeEarthLink()
        if (!termuxInstalled()) {
            pushJs("window.__tricorderNote && window.__tricorderNote('ALERT: Termux by F-Droid is not installed. Chat, vision, Imagine, and Kokoro need Termux.')")
        }
        copyBootstrapScript()
        if (earthLink == true) {
            try {
                if (!birdNet.ready()) {
                    pushJs("window.__tricorderNote && window.__tricorderNote('Earth link up — fetching BirdNET')")
                    birdNet.download { p -> pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")") }
                }
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("BirdNET fetch: " + t.message) + ")")
            }
            try {
                if (!floraStore.ready()) {
                    pushJs("window.__tricorderNote && window.__tricorderNote('Earth link up — fetching flora/fauna')")
                    floraStore.download { p -> pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")") }
                }
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("Flora fetch: " + t.message) + ")")
            }
            try {
                if (translateStore.downloadedCodes().isEmpty()) {
                    pushJs("window.__tricorderNote && window.__tricorderNote('Earth link up — fetching translator pair en+es')")
                    translateStore.downloadPair("en", "es") { p ->
                        pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")")
                    }
                }
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("XLAT fetch: " + t.message) + ")")
            }
            try {
                if (!tleStore.status().optBoolean("ready")) {
                    pushJs("window.__tricorderNote && window.__tricorderNote('Earth link up — fetching Keplerian TLE packs')")
                    val msg = tleStore.download { p ->
                        pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")")
                    }
                    pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(msg) + ")")
                }
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("TLE fetch: " + t.message) + ")")
            }

            try {
                if (!dictationStore.readyEmbed()) {
                    pushJs("window.__tricorderNote && window.__tricorderNote('Earth link up — fetching dictation embedder')")
                    dictationStore.downloadEmbed { p -> pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")") }
                }
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("Dictation embedder: " + t.message) + ")")
            }
            try {
                knowledgeStore.warm { p ->
                    pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")")
                }
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("Knowledge banks: " + t.message) + ")")
            }
            try {
                pushJs("window.__tricorderNote && window.__tricorderNote('Earth link up — fetching SOL / space / earth weather')")
                val msg = solStore.download(lastLat, lastLon) { p ->
                    pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")")
                }
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(msg) + ")")
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("SOL fetch: " + t.message) + ")")
            }
        } else {
            pushJs("window.__tricorderNote && window.__tricorderNote('No earth link — skipping pack fetch. Offline classifiers stay as they are.')")
        }
        val st = packStatusJson()
        pushJs("window.__tricorderPacks && window.__tricorderPacks(" + org.json.JSONObject.quote(st) + ")")
        pushJs("window.__tricorderNote && window.__tricorderNote('Tricorder init complete.')")
    }


    fun dictationList(): String = dictationStore.list().toString()
    fun dictationGet(id: String): String = dictationStore.get(id).toString()
    fun dictationCreate(title: String): String = dictationStore.create(title).toString()
    fun dictationSave(id: String, body: String): String = dictationStore.save(id, body).toString()
    fun dictationKill(id: String): Boolean = dictationStore.kill(id)
    fun dictationSummarizeLocal(id: String): String = dictationStore.summarizeLocal(id).toString()
    fun dictationMindmap(keyword: String): String = dictationStore.mindmap(keyword).toString()
    fun dictationStatus(): String = dictationStore.status().toString()
    fun fetchDictationEmbed() {
        Thread {
            try {
                val msg = dictationStore.downloadEmbed { p -> pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")") }
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(msg) + ")")
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("Dictation embedder: " + t.message) + ")")
            }
        }.start()
    }

    fun playFieldLog(index: Int): String {
        val row = try { org.json.JSONObject(fieldLog.get(index).toString()) } catch (_: Exception) {
            return "no entry"
        }
        val vidPath = row.optString("video_path")
        if (vidPath.isNotBlank()) {
            val f = File(vidPath)
            if (f.exists()) {
                runOnUiThread {
                    try {
                        val uri = androidx.core.content.FileProvider.getUriForFile(
                            this,
                            packageName + ".files",
                            f,
                        )
                        val intent = android.content.Intent(android.content.Intent.ACTION_VIEW)
                        intent.setDataAndType(uri, "video/mp4")
                        intent.addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                        startActivity(intent)
                    } catch (t: Throwable) {
                        pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("video play: " + t.message) + ")")
                    }
                }
                return "playing video"
            }
        }
        val text = row.optString("text")
        if (text.isNotBlank()) {
            speakKokoro(text)
            return "speaking entry"
        }
        return "nothing to play"
    }

    fun openManual() {
        runOnUiThread { webView.loadUrl("file:///android_asset/www/manual.html") }
    }

    fun openFDroidTermux() {
        runOnUiThread {
            try {
                startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://f-droid.org/packages/com.termux/")))
            } catch (_: Exception) {}
        }
    }

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            wanted += Manifest.permission.BLUETOOTH_SCAN
            wanted += Manifest.permission.BLUETOOTH_CONNECT
        }
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun observeFoldPosture() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                WindowInfoTracker.getOrCreate(this@MainActivity)
                    .windowLayoutInfo(this@MainActivity)
                    .collect { info ->
                        val folding = info.displayFeatures.filterIsInstance<FoldingFeature>().firstOrNull()
                        if (folding == null) {
                            bridge.updatePosture("FLAT_OR_PHONE", "UNKNOWN", "windowmanager")
                        } else {
                            val state = when (folding.state) {
                                FoldingFeature.State.FLAT -> "FLAT"
                                FoldingFeature.State.HALF_OPENED -> "HALF_OPENED"
                                else -> "UNKNOWN"
                            }
                            val orientation = when (folding.orientation) {
                                FoldingFeature.Orientation.HORIZONTAL -> "HORIZONTAL"
                                FoldingFeature.Orientation.VERTICAL -> "VERTICAL"
                                else -> "UNKNOWN"
                            }
                            bridge.updatePosture(state, orientation, "windowmanager")
                        }
                    }
            }
        }
    }

    fun startNativeListen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            evalJs("window.__tricorderSpeechError && window.__tricorderSpeechError('mic permission denied')")
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            evalJs("window.__tricorderSpeechError && window.__tricorderSpeechError('no on-device recognizer')")
            return
        }
        stopNativeListen()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: OsBundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "no match"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "timeout"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "mic permission denied"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "network"
                    SpeechRecognizer.ERROR_CLIENT -> "canceled"
                    else -> "error $error"
                }
                evalJs("window.__tricorderSpeechError && window.__tricorderSpeechError(${jsonStr(msg)})")
            }
            override fun onResults(results: OsBundle?) {
                val said = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                evalJs("window.__tricorderSpeechResult && window.__tricorderSpeechResult(${jsonStr(said)})")
            }
            override fun onPartialResults(partialResults: OsBundle?) {
                val said = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (said.isNotBlank()) {
                    evalJs("window.__tricorderSpeechPartial && window.__tricorderSpeechPartial(${jsonStr(said)})")
                }
            }
            override fun onEvent(eventType: Int, params: OsBundle?) {}
        })
        speechRecognizer = rec
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        rec.startListening(intent)
    }

    fun stopNativeListen() {
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
    }

    private fun evalJs(code: String) {
        if (!this::webView.isInitialized) return
        webView.post { webView.evaluateJavascript(code, null) }
    }

    private fun jsonStr(s: String): String =
        org.json.JSONObject.quote(s)

    private fun chunkKokoro(text: String, max: Int = 80): List<String> {
        val raw = text.trim().replace(Regex("\\s+"), " ")
        if (raw.isEmpty()) return emptyList()
        val sentences = Regex("[^.!?]+[.!?]+\\s*|[^.!?]+$").findAll(raw).map { it.value.trim() }.toList()
        val out = mutableListOf<String>()
        val buf = StringBuilder()
        fun flush() {
            val s = buf.toString().trim()
            if (s.isNotEmpty()) out.add(s)
            buf.setLength(0)
        }
        for (sent in sentences.ifEmpty { listOf(raw) }) {
            var s = sent
            while (s.length > max) {
                var cut = s.lastIndexOf(' ', max)
                if (cut < max / 3) cut = max
                val piece = s.substring(0, cut).trim()
                if (buf.isNotEmpty() && buf.length + 1 + piece.length > max) flush()
                if (piece.length >= max) { flush(); out.add(piece) } else {
                    if (buf.isNotEmpty()) buf.append(' ')
                    buf.append(piece)
                    flush()
                }
                s = s.substring(cut).trim()
            }
            if (s.isEmpty()) continue
            if (buf.isNotEmpty() && buf.length + 1 + s.length > max) flush()
            if (buf.isNotEmpty()) buf.append(' ')
            buf.append(s)
        }
        flush()
        return out
    }

    fun speakKokoro(text: String) {
        val chunks = chunkKokoro(text.trim().take(2000), 80)
        if (chunks.isEmpty()) return
        val gen = kokoroGen.incrementAndGet()
        gateAudioForVoice(true)
        ttsExecutor.execute {
            try {
                for ((idx, clipped) in chunks.withIndex()) {
                    if (gen != kokoroGen.get()) return@execute
                    var conn: HttpURLConnection? = null
                    val bytes = try {
                        conn = (URL("http://127.0.0.1:5000/v1/audio/speech").openConnection() as HttpURLConnection).apply {
                            requestMethod = "POST"
                            setRequestProperty("Content-Type", "application/json")
                            doOutput = true
                            connectTimeout = 8000
                            readTimeout = 90_000
                        }
                        kokoroConn = conn
                        val body = org.json.JSONObject()
                            .put("model", "kokoro-82m")
                            .put("input", clipped)
                            .put("voice", "af_bella")
                            .toString()
                            .toByteArray()
                        conn.outputStream.use { it.write(body) }
                        if (conn.responseCode !in 200..299) {
                            if (idx == 0) notifyTtsFallback(text.trim().take(400))
                            return@execute
                        }
                        conn.inputStream.use { it.readBytes() }
                    } catch (_: Exception) {
                        if (gen == kokoroGen.get() && idx == 0) notifyTtsFallback(text.trim().take(400))
                        return@execute
                    } finally {
                        try { conn?.disconnect() } catch (_: Exception) {}
                        if (kokoroConn === conn) kokoroConn = null
                    }
                    if (gen != kokoroGen.get()) return@execute
                    if (bytes.isEmpty()) continue
                    val tmp = File(cacheDir, "kokoro-play-$idx.wav")
                    tmp.writeBytes(bytes)
                    val latch = CountDownLatch(1)
                    runOnUiThread {
                        if (gen != kokoroGen.get()) { latch.countDown(); return@runOnUiThread }
                        try {
                            try { ttsPlayer?.stop(); ttsPlayer?.release() } catch (_: Exception) {}
                            val mp = MediaPlayer()
                            ttsPlayer = mp
                            mp.setAudioAttributes(
                                AudioAttributes.Builder()
                                    .setUsage(AudioAttributes.USAGE_MEDIA)
                                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                    .build(),
                            )
                            mp.setDataSource(tmp.absolutePath)
                            mp.setOnCompletionListener {
                                it.release()
                                if (ttsPlayer === it) ttsPlayer = null
                                latch.countDown()
                            }
                            mp.setOnErrorListener { _, _, _ -> latch.countDown(); true }
                            mp.prepare()
                            mp.start()
                        } catch (_: Exception) {
                            latch.countDown()
                        }
                    }
                    latch.await(90, TimeUnit.SECONDS)
                }
            } finally {
                if (gen == kokoroGen.get()) {
                    runOnUiThread {
                        webView.evaluateJavascript("window.__tricorderTtsDone && window.__tricorderTtsDone()", null)
                    }
                    webView.postDelayed({ gateAudioForVoice(false) }, 600)
                }
            }
        }
    }

    private fun startEnvSensors() {
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManager = sm
        listOf(
            Sensor.TYPE_PRESSURE,
            Sensor.TYPE_AMBIENT_TEMPERATURE,
            Sensor.TYPE_RELATIVE_HUMIDITY,
            Sensor.TYPE_GRAVITY,
            Sensor.TYPE_ACCELEROMETER,
            Sensor.TYPE_ROTATION_VECTOR,
            Sensor.TYPE_GYROSCOPE,
        ).forEach { type ->
            sm.getDefaultSensor(type)?.let { sm.registerListener(envListener, it, SensorManager.SENSOR_DELAY_UI) }
        }
    }

    private fun pushImu() {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastImuPushMs < 120) return
        lastImuPushMs = now
        val hdg = imuHeading
        val p = pressureHpa
        val alt = gpsAltM
        val js = org.json.JSONObject()
            .put("gx", imuGx.toDouble())
            .put("gy", imuGy.toDouble())
            .put("gz", imuGz.toDouble())
            .put("heading", if (hdg != null) hdg else org.json.JSONObject.NULL)
            .put("pressure_hpa", if (p != null) p else org.json.JSONObject.NULL)
            .put("gps_alt_m", if (alt != null) alt else org.json.JSONObject.NULL)
        runOnUiThread {
            webView.evaluateJavascript(
                "window.__tricorderImu && window.__tricorderImu(" + js.toString() + ")",
                null,
            )
        }
    }

    @SuppressLint("MissingPermission")
    private fun startGroundSpeed() {
        if (speedStarted) return
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!fine && !coarse) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        val listener = android.location.LocationListener { loc ->
            lastLat = loc.latitude
            lastLon = loc.longitude
            if (loc.hasAltitude()) gpsAltM = loc.altitude
            val mps = if (loc.hasSpeed()) loc.speed.toDouble() else Double.NaN
            groundSpeedMps = mps
            val js = if (mps.isFinite()) mps else -1.0
            val fix = org.json.JSONObject()
                .put("lat", loc.latitude)
                .put("lon", loc.longitude)
                .put("alt_m", if (loc.hasAltitude()) loc.altitude else org.json.JSONObject.NULL)
                .put("acc_m", if (loc.hasAccuracy()) loc.accuracy.toDouble() else org.json.JSONObject.NULL)
                .put("speed_mps", js)
                .put("t_ms", loc.time)
            runOnUiThread {
                webView.evaluateJavascript(
                    "window.__tricorderSpeed && window.__tricorderSpeed($js)",
                    null,
                )
                webView.evaluateJavascript(
                    "window.__tricorderFix && window.__tricorderFix(" + fix.toString() + ")",
                    null,
                )
            }
        }
        try {
            val last = listOf(
                android.location.LocationManager.GPS_PROVIDER,
                android.location.LocationManager.NETWORK_PROVIDER,
            ).mapNotNull { p -> try { lm.getLastKnownLocation(p) } catch (_: Exception) { null } }
                .maxByOrNull { it.time }
            if (last != null) {
                lastLat = last.latitude
                lastLon = last.longitude
                if (last.hasSpeed()) groundSpeedMps = last.speed.toDouble()
            }
            if (lm.isProviderEnabled(android.location.LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(
                    android.location.LocationManager.GPS_PROVIDER,
                    400L,
                    0.5f,
                    listener,
                    android.os.Looper.getMainLooper(),
                )
            }
            if (lm.isProviderEnabled(android.location.LocationManager.NETWORK_PROVIDER)) {
                lm.requestLocationUpdates(
                    android.location.LocationManager.NETWORK_PROVIDER,
                    1000L,
                    2f,
                    listener,
                    android.os.Looper.getMainLooper(),
                )
            }
            speedStarted = true
        } catch (_: Exception) { }
    }

    @SuppressLint("MissingPermission")
    private fun startGnssClock() {
        if (gnssStarted) return
        val fine = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
            PackageManager.PERMISSION_GRANTED
        if (!fine) return
        val lm = getSystemService(Context.LOCATION_SERVICE) as android.location.LocationManager
        val cb = object : android.location.GnssMeasurementsEvent.Callback() {
            override fun onGnssMeasurementsReceived(event: android.location.GnssMeasurementsEvent) {
                val c = event.clock
                gnssSatCount = try { event.measurements.size } catch (_: Exception) { 0 }
                try {
                    val d = c.hardwareClockDiscontinuityCount
                    if (gnssDiscont >= 0 && d != gnssDiscont) gnssLocked = false
                    gnssDiscont = d
                } catch (_: Exception) { }
                if (!c.hasFullBiasNanos()) {
                    gnssLocked = false
                    return
                }
                val extraBias = try { if (c.hasBiasNanos()) c.biasNanos else 0.0 } catch (_: Exception) { 0.0 }
                val bias = c.fullBiasNanos + extraBias
                val gpsNs = c.timeNanos - bias
                val leap = try { if (c.hasLeapSecond()) c.leapSecond else 18 } catch (_: Exception) { 18 }
                gnssLeap = leap
                gnssUtcNanos = (gpsNs - leap * 1_000_000_000.0).toLong()
                gnssElapsedNanos = try {
                    if (android.os.Build.VERSION.SDK_INT >= 29 && c.hasElapsedRealtimeNanos()) c.elapsedRealtimeNanos
                    else android.os.SystemClock.elapsedRealtimeNanos()
                } catch (_: Exception) { android.os.SystemClock.elapsedRealtimeNanos() }
                gnssUncNs = try {
                    when {
                        c.hasBiasUncertaintyNanos() -> c.biasUncertaintyNanos
                        c.hasTimeUncertaintyNanos() -> c.timeUncertaintyNanos
                        else -> Double.NaN
                    }
                } catch (_: Exception) { Double.NaN }
                gnssLocked = true
            }
        }
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                lm.registerGnssMeasurementsCallback(mainExecutor, cb)
            } else {
                @Suppress("DEPRECATION")
                lm.registerGnssMeasurementsCallback(cb)
            }
            gnssStarted = true
        } catch (_: Exception) { }
    }

    fun gnssClockJson(): String {
        val nowE = android.os.SystemClock.elapsedRealtimeNanos()
        val locked = gnssLocked && gnssUtcNanos != 0L
        val utcMs = if (locked) {
            val age = nowE - gnssElapsedNanos
            (gnssUtcNanos + age) / 1_000_000L
        } else System.currentTimeMillis()
        val unc = gnssUncNs
        return org.json.JSONObject()
            .put("ok", true)
            .put("locked", locked)
            .put("source", if (locked) "gnss" else "device")
            .put("utc_ms", utcMs)
            .put("unc_ns", if (unc.isFinite()) unc else org.json.JSONObject.NULL)
            .put("leap_s", gnssLeap)
            .put("sats", gnssSatCount)
            .put("update_hz", if (locked) 1 else 0)
            .put("display_hz", 4)
            .put("resolution", if (locked) "1 ns GNSS clock, interpolated at 4 Hz" else "1 ms device clock")
            .toString()
    }

    fun resolveNav(q: String): String = PlaceHub.get(this).resolveQuery(q).toString()

    fun placeJson(): String {
        val lat = lastLat
        val lon = lastLon
        return PlaceHub.get(this).snapshot(
            if (lat.isFinite()) lat else null,
            if (lon.isFinite()) lon else null,
        ).toString()
    }

    fun tleStatus(): String = tleStore.status().toString()
    fun tleText(id: String): String = tleStore.text(id)
    fun fetchTles() {
        Thread {
            try {
                val msg = tleStore.download { p ->
                    pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")")
                }
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(msg) + ")")
                pushJs("window.__tricorderPacks && window.__tricorderPacks(" + org.json.JSONObject.quote(packStatusJson()) + ")")
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("TLE: " + t.message) + ")")
            }
        }.start()
    }
    fun solSnapshot(): String = solStore.snapshot()
    fun fetchSol() {
        Thread {
            try {
                val msg = solStore.download(lastLat, lastLon) { p ->
                    pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")")
                }
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(msg) + ")")
                pushJs("window.__tricorderSol && window.__tricorderSol(" + org.json.JSONObject.quote(solStore.snapshot()) + ")")
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("SOL: " + t.message) + ")")
            }
        }.start()
    }

    fun observerFixJson(): String {
        return org.json.JSONObject()
            .put("ok", lastLat.isFinite() && lastLon.isFinite())
            .put("lat", if (lastLat.isFinite()) lastLat else org.json.JSONObject.NULL)
            .put("lon", if (lastLon.isFinite()) lastLon else org.json.JSONObject.NULL)
            .put("mps", if (groundSpeedMps.isFinite()) groundSpeedMps else org.json.JSONObject.NULL)
            .toString()
    }

    fun groundSpeedJson(): String {
        val v = groundSpeedMps
        return org.json.JSONObject()
            .put("ok", v.isFinite())
            .put("mps", if (v.isFinite()) v else org.json.JSONObject.NULL)
            .put("kmh", if (v.isFinite()) v * 3.6 else org.json.JSONObject.NULL)
            .put("mph", if (v.isFinite()) v * 2.236936 else org.json.JSONObject.NULL)
            .toString()
    }

    private fun probeEarthLink(): Boolean {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("/system/bin/ping", "-c", "1", "-W", "2", "8.8.8.8"))
            val code = proc.waitFor()
            if (code == 0) return true
            val conn = URL("https://clients3.google.com/generate_204").openConnection() as HttpURLConnection
            conn.connectTimeout = 2000
            conn.readTimeout = 2000
            conn.requestMethod = "HEAD"
            conn.responseCode in 200..399
        } catch (_: Exception) {
            false
        }
    }

    fun startAudioSense(dwellMs: Int, intervalMs: Int) {
        runOnUiThread {
            if (audioSense == null) audioSense = AudioSense(this)
            audioSense?.dwellMs = dwellMs.toLong().coerceIn(1000, 20000)
            audioSense?.intervalMs = intervalMs.toLong().coerceIn(1000, 120000)
            audioSense?.start { json ->
                val enriched = enrichAudioJson(json)
                val safe = enriched.replace("\\", "\\\\").replace("'", "\\'").replace("\n", " ")
                runOnUiThread {
                    webView.evaluateJavascript(
                        "window.__tricorderAudio && window.__tricorderAudio('$safe')",
                        null,
                    )
                }
            }
        }
    }

    private fun enrichAudioJson(raw: String): String {
        return try {
            val obj = org.json.JSONObject(raw)
            val labels = obj.optJSONArray("labels") ?: org.json.JSONArray()
            var avian = false
            for (i in 0 until labels.length()) {
                val name = labels.optJSONObject(i)?.optString("label") ?: ""
                if (name.contains("Bird", ignoreCase = true) || name.contains("Animal", ignoreCase = true)) {
                    avian = true
                }
            }
            var bird = org.json.JSONArray()
            if (avian && birdNet.ready()) {
                val pcm = audioSense?.lastPcm
                if (pcm != null) bird = birdNet.classifyPcm16k(pcm)
            }
            obj.put("birdnet", bird)
            obj.put("birdnet_ready", birdNet.ready())
            val extra = org.json.JSONObject().put("avian", avian)
            val row = audioLog.append(labels, bird, extra)
            try {
                val top = if (labels.length() > 0) labels.optJSONObject(0)?.optString("label") else ""
                val bird0 = if (bird.length() > 0) bird.optJSONObject(0)?.optString("en") else ""
                val kind = if (bird.length() > 0) "bird" else "audio"
                val txt = listOf(bird0, top).filter { !it.isNullOrBlank() }.joinToString(" / ")
                val noise = Regex("silence|speech|white noise|noise|inside|outside|quiet", RegexOption.IGNORE_CASE)
                if (txt.isNotBlank() && bird.length() > 0) {
                    fieldLog.append("bird", txt)
                } else if (txt.isNotBlank() && !noise.containsMatchIn(txt)) {
                    fieldLog.append(kind, txt)
                }
            } catch (_: Exception) {}
            obj.put("log_id", row.optString("id"))
            obj.put("log_path", audioLog.path())
            if (nearbyLink?.running == true) nearbyLink?.send(row)
            obj.toString()
        } catch (t: Throwable) {
            raw
        }
    }

    fun getAudioLog(n: Int): String = audioLog.tail(n)

    fun birdNetStatus(): String = birdNet.status().toString()

    fun fetchBirdNet() {
        Thread {
            try {
                val msg = birdNet.download { p -> pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")") }
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(msg) + ")")
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("BirdNET fetch failed: " + t.message) + ")")
            }
        }.start()
    }

    fun startAudioLink() = startComlink()

    fun stopAudioLink() = stopComlink()

    fun startComlink() {
        val guid = ComlinkId.guid(this)
        val nearbyOn = getSetting("nearby_on").ifBlank { "1" } != "0"
        val loraOn = getSetting("lora_on") == "1" || getSetting("lora_on").equals("true", true)
        if (nearbyOn) {
            if (nearbyLink == null) {
                nearbyLink = NearbyLink(
                    this,
                    guid,
                    onIncoming = { obj -> handleComlink(obj) },
                    onRoster = { roster ->
                        pushJs("window.__tricorderComlink && window.__tricorderComlink(" + mergeRoster(roster).toString() + ")")
                    },
                    onStatus = { s ->
                        pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("COMLINK " + s) + ")")
                    },
                )
            }
            nearbyLink?.start(ComlinkId.advertiseName(this))
        } else {
            nearbyLink?.stop()
        }
        if (loraOn) {
            if (meshLink == null) {
                meshLink = MeshLink(
                    this,
                    onIncoming = { obj -> handleComlink(obj) },
                    onStatus = { s ->
                        pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(s) + ")")
                        nearbyLink?.rosterJson()?.let {
                            pushJs("window.__tricorderComlink && window.__tricorderComlink(" + mergeRoster(it).toString() + ")")
                        }
                    },
                )
            }
            meshLink?.start()
        } else {
            meshLink?.stop()
        }
    }

    fun stopComlink() {
        nearbyLink?.stop()
        meshLink?.stop()
    }

    private fun mergeRoster(base: org.json.JSONObject): org.json.JSONObject {
        val lora = meshLink?.statusJson() ?: org.json.JSONObject().put("on", "0")
        base.put("lora", lora)
        base.put("nearby_on", getSetting("nearby_on").ifBlank { "1" })
        if (meshLink?.linked == true) {
            val peers = base.optJSONArray("peers") ?: org.json.JSONArray()
            peers.put(
                org.json.JSONObject()
                    .put("endpoint", "lora")
                    .put("name", meshLink?.radioName?.ifBlank { "T1000-E" })
                    .put("guid", "lora")
                    .put("state", "linked")
                    .put("via", "lora"),
            )
            base.put("peers", peers)
        }
        return base
    }

    fun comlinkRoster(): String {
        val base = nearbyLink?.rosterJson() ?: org.json.JSONObject()
            .put("ok", true)
            .put("running", false)
            .put("guid", ComlinkId.guid(this))
            .put("name", ComlinkId.callsign(this))
            .put("peers", org.json.JSONArray())
        return mergeRoster(base).toString()
    }

    fun meshStatus(): String = (meshLink?.statusJson() ?: org.json.JSONObject().put("linked", false)).toString()

    fun startMesh() {
        setSetting("lora_on", "1")
        startComlink()
    }

    fun stopMesh() {
        setSetting("lora_on", "0")
        meshLink?.stop()
    }

    fun setCallsign(name: String) {
        ComlinkId.setCallsign(this, name)
        nearbyLink?.rosterJson()?.let {
            pushJs("window.__tricorderComlink && window.__tricorderComlink(" + it.toString() + ")")
        }
        if (nearbyLink?.running == true) {
            try { startComlink() } catch (_: Exception) {}
        }
    }

    fun backupTricorder(faceJson: String): String = try {
        BackupStore.export(this, faceJson).toString()
    } catch (t: Throwable) {
        org.json.JSONObject().put("ok", false).put("error", t.message ?: "backup fail").toString()
    }

    fun restoreTricorder(): String = try {
        BackupStore.import(this).toString()
    } catch (t: Throwable) {
        org.json.JSONObject().put("ok", false).put("error", t.message ?: "restore fail").toString()
    }

    fun getSetting(key: String): String =
        getSharedPreferences("tricorder", MODE_PRIVATE).getString(key, "") ?: ""

    fun setSetting(key: String, value: String) {
        getSharedPreferences("tricorder", MODE_PRIVATE).edit().putString(key, value).commit()
    }

    fun openExternal(url: String) {
        try {
            val u = android.net.Uri.parse(url)
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, u).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }

    fun scannerUrl(): String {
        val loc = try {
            val lm = getSystemService(LOCATION_SERVICE) as android.location.LocationManager
            lm.getLastKnownLocation(android.location.LocationManager.GPS_PROVIDER)
                ?: lm.getLastKnownLocation(android.location.LocationManager.NETWORK_PROVIDER)
        } catch (_: Exception) { null }
        val st = stateFips(loc?.latitude ?: 41.5, loc?.longitude ?: -74.0)
        return "https://www.broadcastify.com/listen/stid/$st"
    }

    private fun stateFips(lat: Double, lon: Double): Int {
        // coarse CONUS boxes — NY default for the reference lab
        return when {
            lat in 40.4..45.1 && lon in -79.8..-71.7 -> 36
            lat in 38.9..41.4 && lon in -80.6..-74.6 -> 42
            lat in 38.7..41.5 && lon in -75.6..-73.8 -> 34
            lat in 40.9..42.9 && lon in -73.8..-69.8 -> 25
            lat in 24.4..31.1 && lon in -87.7..-79.9 -> 12
            lat in 32.5..42.1 && lon in -124.5..-114.0 -> 6
            lat in 25.8..36.6 && lon in -106.7..-93.4 -> 48
            else -> 36
        }
    }

    fun mutePeer(guid: String, mute: Boolean) {
        ComlinkId.setMuted(this, guid, mute)
        nearbyLink?.rosterJson()?.let { pushJs("window.__tricorderComlink && window.__tricorderComlink(" + it.toString() + ")") }
    }

    fun comlinkPtt(text: String, guid: String?) {
        val row = org.json.JSONObject()
            .put("kind", "ptt")
            .put("from", ComlinkId.callsign(this))
            .put("guid", ComlinkId.guid(this))
            .put("text", text.trim())
        if (guid.isNullOrBlank() || guid == "lora") {
            nearbyLink?.send(row)
            meshLink?.send(row)
        } else {
            nearbyLink?.send(row, guid)
        }
    }

    private fun handleComlink(obj: org.json.JSONObject) {
        val kind = obj.optString("kind")
        val from = obj.optString("from", "REMOTE")
        val guid = obj.optString("guid")
        if (guid.isNotBlank() && ComlinkId.muted(this).contains(guid)) return
        when (kind) {
            "hello" -> pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("COMLINK hello $from") + ")")
            "ptt" -> {
                val text = obj.optString("text")
                val spoken = "Beep beep beep. From $from. $text"
                pushJs("window.__tricorderComlinkPtt && window.__tricorderComlinkPtt(" + org.json.JSONObject.quote(spoken) + ")")
                try { speakRobo(spoken) } catch (_: Exception) {}
                try { fieldLog.append("comlink", spoken) } catch (_: Exception) {}
            }
            "context", "alert" -> {
                val label = obj.optString("text", obj.optString("source"))
                obj.put("remote", true)
                obj.put("text", label)
                emitContextAlert(obj, local = false, fromName = from)
            }
            else -> {
                pushJs("window.__tricorderRemoteHit && window.__tricorderRemoteHit(" + org.json.JSONObject.quote(obj.toString()) + ")")
            }
        }
    }

    private fun pushJs(expr: String) {
        runOnUiThread { webView.evaluateJavascript(expr, null) }
    }

    fun stopAudioSense() {
        audioSense?.stop()
        contextWatch.stop()
    }

    fun startContextWatch(flagsJson: String) {
        val flags = HashSet<String>()
        try {
            val arr = org.json.JSONArray(flagsJson)
            for (i in 0 until arr.length()) flags.add(arr.optString(i))
        } catch (_: Exception) {}
        contextWatch.start(flags) { row ->
            emitContextAlert(row, local = true)
        }
    }

    fun stopContextWatch() {
        contextWatch.stop()
    }

    fun autoBackup(faceJson: String) {
        ttsExecutor.execute {
            try { BackupStore.export(this, faceJson) } catch (_: Exception) {}
        }
    }

    fun probeAlertApis() {
        ttsExecutor.execute {
            val row = try {
                contextWatch.probeServices()
            } catch (e: Exception) {
                org.json.JSONObject().put("ok", false).put("error", e.message ?: "probe")
            }
            pushJs("window.__tricorderApiCheck && window.__tricorderApiCheck(" + org.json.JSONObject.quote(row.toString()) + ")")
        }
    }

    private fun emitContextAlert(row: org.json.JSONObject, local: Boolean, fromName: String? = null) {
        val source = row.optString("source", "context")
        val details = row.optString("text", "")
        val hhmm = row.optString("hhmm", "")
        val who = fromName?.takeIf { it.isNotBlank() } ?: row.optString("from").ifBlank { "REMOTE" }
        val spoken = if (local) {
            "Local tricorder detected $source event" + (if (hhmm.isNotBlank()) " at $hhmm" else "") +
                ". Details follow. " + details
        } else {
            "Remote tricorder $who detected $source event" + (if (hhmm.isNotBlank()) " at $hhmm" else "") +
                ". Details follow. " + details
        }
        try {
            val photo = row.optString("photo")
            val extra = org.json.JSONObject()
            listOf(
                "registration","type","manufacturer","owner","origin_city","dest_city",
                "origin_label","dest_label","callsign","icao24","photo_url","icao_type",
            ).forEach { k ->
                if (row.optString(k).isNotBlank()) extra.put(k, row.optString(k))
            }
            fieldLog.append(if (source == "flight") "flight" else "context", spoken, photo.ifBlank { null }, extra)
        } catch (_: Exception) {}
        if (source == "flight") {
            lastFlightJson = row.toString()
            val jsRow = org.json.JSONObject(row.toString())
            val embedded = jsRow.optString("photo")
            if (embedded.length > 60_000) jsRow.put("photo", "")
            val safe = jsRow.toString().replace("\\", "\\\\").replace("</", "<\\/").replace("\u2028", " ").replace("\u2029", " ")
            pushJs("window.__tricorderFlight && window.__tricorderFlight($safe)")
        }
        if (local && source != "notice") {
            try {
                val wire = org.json.JSONObject()
                    .put("kind", "context")
                    .put("source", source)
                    .put("text", details)
                    .put("hhmm", hhmm)
                    .put("from", ComlinkId.callsign(this))
                    .put("guid", ComlinkId.guid(this))
                    .put("remote", true)
                nearbyLink?.send(wire)
                meshLink?.send(wire)
            } catch (_: Exception) {}
        }
        if (source != "flight") {
            val civic = org.json.JSONObject()
                .put("source", source)
                .put("event", row.optString("event", source))
                .put("category", row.optString("category", source))
                .put("text", details)
                .put("spoken", spoken)
                .put("hhmm", hhmm)
                .put("id", row.optString("id", source + hhmm + details.hashCode()))
            val safe = civic.toString().replace("\\", "\\\\").replace("</", "<\\/").replace("\u2028", " ").replace("\u2029", " ")
            pushJs("window.__tricorderCivic && window.__tricorderCivic($safe)")
            try { speakRobo(spoken) } catch (_: Exception) {}
        }
    }

    fun setAudioDuty(dwellMs: Int, intervalMs: Int) {
        audioSense?.dwellMs = dwellMs.toLong().coerceIn(1000, 20000)
        audioSense?.intervalMs = intervalMs.toLong().coerceIn(1000, 120000)
    }


    fun floraStatus(): String = floraStore.status().toString()

    fun fetchFlora() {
        Thread {
            try {
                val msg = floraStore.download { p -> pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")") }
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(msg) + ")")
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("Flora fetch failed: " + t.message) + ")")
            }
        }.start()
    }

    fun classifyFlora(dataUrl: String): String {
        return try {
            val hits = floraStore.classifyDataUrl(dataUrl)
            val extra = org.json.JSONObject().put("kind", "vision")
            audioLog.append(org.json.JSONArray(), org.json.JSONArray(), extra.put("vision", hits))
            val label = StringBuilder()
            for (i in 0 until hits.length()) {
                val pack = hits.optJSONObject(i) ?: continue
                val hs = pack.optJSONArray("hits") ?: continue
                for (j in 0 until hs.length()) {
                    val h = hs.optJSONObject(j) ?: continue
                    if (label.isNotEmpty()) label.append("; ")
                    label.append(pack.optString("pack")).append(": ").append(h.optString("en"))
                }
            }
            fieldLog.append("flora", if (label.isNotEmpty()) label.toString() else "flora scan", dataUrl, extra)
            org.json.JSONObject().put("ok", true).put("ready", floraStore.ready()).put("vision", hits).toString()
        } catch (t: Throwable) {
            org.json.JSONObject().put("ok", false).put("error", t.message ?: "classify failed").toString()
        }
    }

    fun logField(kind: String, text: String, imageDataUrl: String?): String {
        return try {
            fieldLog.append(kind, text, imageDataUrl).toString()
        } catch (t: Throwable) {
            org.json.JSONObject().put("ok", false).put("error", t.message ?: "log failed").toString()
        }
    }

    fun fieldLogSummary(): String = fieldLog.summary().toString()

    fun fieldLogGet(index: Int): String = fieldLog.get(index).toString()
    fun fieldLogGetById(id: String): String = fieldLog.getById(id).toString()

    fun fieldLogCount(): Int = fieldLog.count()

    fun lastFlight(): String = lastFlightJson

    fun knowledgeSearch(bank: String, query: String) {
        Thread {
            try {
                val row = knowledgeStore.search(bank, query)
                pushJs("window.__tricorderKnowledge && window.__tricorderKnowledge(" + row.toString() + ")")
            } catch (t: Throwable) {
                pushJs(
                    "window.__tricorderKnowledge && window.__tricorderKnowledge(" +
                        org.json.JSONObject().put("ok", false).put("error", t.message ?: "search failed").toString() + ")",
                )
            }
        }.start()
    }

    fun cityFacts(name: String) {
        Thread {
            try {
                val row = knowledgeStore.cityCard(name)
                pushJs("window.__tricorderCityCard && window.__tricorderCityCard(" + row.toString() + ")")
            } catch (t: Throwable) {
                pushJs(
                    "window.__tricorderCityCard && window.__tricorderCityCard(" +
                        org.json.JSONObject().put("ok", false).put("error", t.message ?: "city failed").toString() + ")",
                )
            }
        }.start()
    }

    fun aircraftFacts(payloadJson: String) {
        Thread {
            try {
                val extra = try { org.json.JSONObject(payloadJson) } catch (_: Exception) { org.json.JSONObject() }
                val row = knowledgeStore.aircraftCard(
                    extra.optString("type"),
                    extra.optString("registration"),
                    extra,
                )
                pushJs("window.__tricorderCraftCard && window.__tricorderCraftCard(" + row.toString() + ")")
            } catch (t: Throwable) {
                pushJs(
                    "window.__tricorderCraftCard && window.__tricorderCraftCard(" +
                        org.json.JSONObject().put("ok", false).put("error", t.message ?: "craft failed").toString() + ")",
                )
            }
        }.start()
    }

    fun knowledgeStatus(): String = knowledgeStore.status().toString()

    fun startVideoLog(): String {
        return try { videoLog.start() } catch (t: Throwable) { "video failed: ${t.message}" }
    }

    fun stopVideoLog(): String {
        return try { videoLog.stop() } catch (t: Throwable) { "video stop failed: ${t.message}" }
    }

    fun translateStatus(): String = translateStore.status().toString()

    fun translateLangs(): String {
        val arr = org.json.JSONArray()
        translateStore.languages().forEach {
            arr.put(org.json.JSONObject().put("code", it.code).put("name", it.name))
        }
        return arr.toString()
    }

    fun fetchTranslatePacks() {
        Thread {
            try {
                val msg = translateStore.downloadAll { p ->
                    pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")")
                }
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(msg) + ")")
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("XLAT fetch failed: " + t.message) + ")")
            }
        }.start()
    }

    fun fetchTranslatePair(src: String, tgt: String) {
        Thread {
            try {
                translateStore.downloadPair(src, tgt) { p ->
                    pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote(p) + ")")
                }
            } catch (t: Throwable) {
                pushJs("window.__tricorderNote && window.__tricorderNote(" + org.json.JSONObject.quote("XLAT pair fail: " + t.message) + ")")
            }
        }.start()
    }

    fun setTranslateLangs(src: String, tgt: String) {
        xlatSrc = src.ifBlank { "en" }
        xlatTgt = tgt.ifBlank { "es" }
    }

    fun setTranslateAuto(on: Boolean) {
        translateAuto = on
    }

    private fun maybeSwapAfterTurn() {
        if (!translateAuto) return
        val a = xlatSrc
        val b = xlatTgt
        xlatSrc = b
        xlatTgt = a
        pushJs("window.__tricorderXlat && window.__tricorderXlat(" + org.json.JSONObject.quote("swap:$xlatSrc:$xlatTgt") + ")")
    }

    fun startTranslator(src: String, tgt: String) {
        setTranslateLangs(src, tgt)
        runOnUiThread {
            translateOn = true
            stopNativeListen()
            killTranslateRec()
            try { translateTts?.stop() } catch (_: Exception) {}
            try { translateTts?.shutdown() } catch (_: Exception) {}
            translateTts = null
            translateTts = TextToSpeech(this) { st ->
                if (!translateOn) return@TextToSpeech
                if (st == TextToSpeech.SUCCESS) {
                    webView.postDelayed({ if (translateOn) armTranslateListen() }, 700)
                } else {
                    pushJs("window.__tricorderNote && window.__tricorderNote('XLAT TTS unavailable')")
                }
            }
        }
    }

    fun stopTranslator() {
        translateOn = false
        runOnUiThread {
            killTranslateRec()
            try { translateTts?.stop() } catch (_: Exception) {}
            try { translateTts?.shutdown() } catch (_: Exception) {}
            translateTts = null
            try { translateStore.release() } catch (_: Exception) {}
            pushJs("window.__tricorderXlat && window.__tricorderXlat('off')")
        }
    }

    private fun killTranslateRec() {
        try { translateRec?.cancel() } catch (_: Exception) {}
        try { translateRec?.destroy() } catch (_: Exception) {}
        translateRec = null
    }

    private fun armTranslateListen() {
        if (!translateOn) return
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        killTranslateRec()
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            pushJs("window.__tricorderNote && window.__tricorderNote('XLAT no recognizer')")
            return
        }
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: OsBundle?) {
                pushJs("window.__tricorderXlat && window.__tricorderXlat('listen')")
            }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {
                pushJs("window.__tricorderXlat && window.__tricorderXlat('think')")
            }
            override fun onError(error: Int) {
                if (!translateOn) return
                killTranslateRec()
                val wait = when (error) {
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_CLIENT -> 1600L
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 700L
                    else -> 1100L
                }
                webView.postDelayed({ if (translateOn) armTranslateListen() }, wait)
            }
            override fun onResults(results: OsBundle?) {
                val said = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (said.isBlank()) {
                    if (translateOn) webView.postDelayed({ armTranslateListen() }, 300)
                    return
                }
                pushJs("window.__tricorderXlat && window.__tricorderXlat(" + org.json.JSONObject.quote("src:" + said) + ")")
                Thread {
                    val out = try { translateStore.translate(said, xlatSrc, xlatTgt) } catch (t: Throwable) { t.message ?: "xlat fail" }
                    fieldLog.append("xlat", said + " → " + out)
                    runOnUiThread { speakTranslation(out) }
                }.start()
            }
            override fun onPartialResults(partialResults: OsBundle?) {
                val said = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (said.isNotBlank()) {
                    pushJs("window.__tricorderXlat && window.__tricorderXlat(" + org.json.JSONObject.quote("partial:" + said) + ")")
                }
            }
            override fun onEvent(eventType: Int, params: OsBundle?) {}
        })
        translateRec = rec
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
        intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        val loc = translateStore.localeFor(xlatSrc)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, loc.toLanguageTag())
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, loc.toLanguageTag())
        try { rec.startListening(intent) } catch (_: Exception) {
            webView.postDelayed({ if (translateOn) armTranslateListen() }, 600)
        }
        pushJs("window.__tricorderXlat && window.__tricorderXlat('listen')")
    }

    private fun speakTranslation(text: String) {
        pushJs("window.__tricorderXlat && window.__tricorderXlat(" + org.json.JSONObject.quote("dst:" + text) + ")")
        val tts = translateTts
        if (tts == null || text.isBlank()) {
            if (translateOn) webView.postDelayed({ armTranslateListen() }, 400)
            return
        }
        try { tts.language = translateStore.localeFor(xlatTgt) } catch (_: Exception) {}
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
                pushJs("window.__tricorderXlat && window.__tricorderXlat('speak')")
            }
            override fun onDone(utteranceId: String?) {
                maybeSwapAfterTurn()
                if (translateOn) webView.postDelayed({ armTranslateListen() }, 350)
            }
            @Deprecated("deprecated")
            override fun onError(utteranceId: String?) {
                maybeSwapAfterTurn()
                if (translateOn) webView.postDelayed({ armTranslateListen() }, 350)
            }
        })
        val params = android.os.Bundle()
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, "xlat-1")
    }



    fun logVisionCaption(text: String) {
        try {
            val extra = org.json.JSONObject().put("kind", "vision_caption").put("caption", text)
            audioLog.append(org.json.JSONArray(), org.json.JSONArray(), extra)
        } catch (_: Exception) {}
    }

    fun shipStatusJson(): String {
        ttsExecutor.execute { earthLink = probeEarthLink() }
        val bm = getSystemService(BatteryManager::class.java)
        val battery = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val cm = getSystemService(ConnectivityManager::class.java)
        val net = cm?.activeNetwork != null
        val uptimeMs = SystemClock.elapsedRealtime()
        return org.json.JSONObject()
            .put("battery_pct", battery)
            .put("uptime_ms", uptimeMs)
            .put("network", net)
            .put("earth_link", earthLink == true)
            .put("pressure_hpa", pressureHpa ?: org.json.JSONObject.NULL)
            .put("temp_c", ambientC ?: org.json.JSONObject.NULL)
            .put("humidity_pct", humidityPct ?: org.json.JSONObject.NULL)
            .put("gps_alt_m", gpsAltM ?: org.json.JSONObject.NULL)
            .put("heading", imuHeading ?: org.json.JSONObject.NULL)
            .put("has_pressure", pressureHpa != null)
            .put("has_accel", true)
            .put("model", Build.MODEL)
            .toString()
    }

    private fun gateAudioForVoice(on: Boolean) {
        audioSense?.holdForVoice = on
    }

    @Volatile private var pendingRobo: String? = null

    fun voiceMuted(): Boolean =
        getSetting("voice_mode").equals("mute", ignoreCase = true)

    fun speakRobo(text: String) {
        if (voiceMuted()) return
        val clipped = text.trim().take(8000)
        if (clipped.isEmpty()) return
        gateAudioForVoice(true)
        pendingRobo = clipped
        val holdMs = (clipped.length * 70L).coerceIn(4000L, 180000L)
        runOnUiThread {
            ensureAlertTts { tts ->
                val say = pendingRobo ?: clipped
                pendingRobo = null
                try {
                    tts.setSpeechRate(1.15f)
                    tts.setPitch(0.72f)
                    val params = android.os.Bundle()
                    params.putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, "alert-robo")
                    val mode = if (say.startsWith("WEAPON")) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD
                    tts.speak(say, mode, params, "alert-robo")
                } catch (_: Exception) {}
                webView.postDelayed({ gateAudioForVoice(false) }, holdMs)
            }
        }
    }

    private fun ensureAlertTts(ready: (TextToSpeech) -> Unit) {
        val existing = alertTts
        if (existing != null && alertTtsReady) {
            ready(existing)
            return
        }
        alertTts = TextToSpeech(this) { st ->
            alertTtsReady = st == TextToSpeech.SUCCESS
            val tts = alertTts ?: return@TextToSpeech
            if (alertTtsReady) {
                try { tts.language = java.util.Locale.US } catch (_: Exception) {}
                ready(tts)
            }
        }
    }

    fun playAlertTone(kind: String) {
        if (voiceMuted()) return
        Thread {
            var tg: ToneGenerator? = null
            try {
                tg = ToneGenerator(AudioManager.STREAM_MUSIC, 90)
                when (kind) {
                    "klaxon" -> {
                        repeat(6) {
                            tg.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 260)
                            Thread.sleep(300)
                        }
                    }
                    "beep3" -> {
                        repeat(3) {
                            tg.startTone(ToneGenerator.TONE_PROP_BEEP, 140)
                            Thread.sleep(220)
                        }
                    }
                    else -> {
                        tg.startTone(ToneGenerator.TONE_PROP_BEEP2, 180)
                        Thread.sleep(200)
                        tg.startTone(ToneGenerator.TONE_PROP_ACK, 220)
                        Thread.sleep(240)
                    }
                }
            } catch (_: Exception) {
            } finally {
                try { tg?.release() } catch (_: Exception) {}
            }
        }.start()
    }

    fun stopRobo() {
        try { alertTts?.stop() } catch (_: Exception) {}
        pendingRobo = null
        gateAudioForVoice(false)
    }

    fun stopKokoro() {
        kokoroGen.incrementAndGet()
        try { kokoroConn?.disconnect() } catch (_: Exception) {}
        kokoroConn = null
        try { ttsPlayer?.stop() } catch (_: Exception) {}
        try { ttsPlayer?.release() } catch (_: Exception) {}
        ttsPlayer = null
        gateAudioForVoice(false)
        runOnUiThread {
            webView.evaluateJavascript("window.__tricorderTtsDone && window.__tricorderTtsDone()", null)
        }
    }

    private fun notifyTtsFallback(text: String) {
        webView.postDelayed({ gateAudioForVoice(false) }, 400)
        runOnUiThread {
            webView.evaluateJavascript(
                "window.__tricorderTtsFallback && window.__tricorderTtsFallback(${jsonStr(text)})",
                null,
            )
        }
    }


    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        try { webView.clearCache(false) } catch (_: Exception) {}
        if (level >= android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL) {
            try { webView.freeMemory() } catch (_: Exception) {}
        }
    }

    override fun onDestroy() {
        try { webView.clearCache(false) } catch (_: Exception) {}
        try { sensorManager?.unregisterListener(envListener) } catch (_: Exception) {}
        stopAudioSense()
        stopKokoro()
        try { alertTts?.stop(); alertTts?.shutdown() } catch (_: Exception) {}
        ttsExecutor.shutdownNow()
        stopNativeListen()
        webView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
