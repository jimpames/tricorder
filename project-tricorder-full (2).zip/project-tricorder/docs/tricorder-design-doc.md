# Project Tricorder — Design Specification v0.1
### A fully offline, config-driven, MCP-routed sensor/companion device
*(Galaxy Z Fold 3 reference hardware, extensible to any Android/iOS device)*

---

## 0. Design Mandate

Everything below follows five non-negotiable rules you set:

1. **Nothing important is hardcoded.** Models, endpoints, button meanings, intent rules, and context providers all live in one config document, hot-reloadable.
2. **API-first.** The UI is a thin renderer of events. Every capability (chat, vision, speech, sensors, context feeds) is exposed as a callable tool behind a local MCP server — the UI never talks to a model or sensor directly.
3. **Event-driven.** State changes propagate as events on a bus; nothing polls unless a provider config says to.
4. **Algebraic, not hardcoded, intent routing.** User input is normalized into a tuple and routed by declarative transformation rules — also stored in config, not in app logic.
5. **Extensible by construction.** Every "wouldn't it be cool if" (flight overhead, NOAA alerts, crime alerts, flora/fauna ID, Waze) is a **context provider** — a plug-in shape the system already understands, even before any of them are built. Phase 1 ships with zero of them wired up; the *shape* is what matters now.

---

## 1. Research Findings — what's actually available today (Aug 2026)

This matters because the earlier planning conversation assumed a few things that turned out to be aspirational rather than shipped. Corrected picture:

| Component | Status | Detail |
|---|---|---|
| **PocketPal AI local server / OpenAI-compatible endpoint** | ❌ Not shipped | This has been requested by the community repeatedly (GitHub issues [#574](https://github.com/a-ghorbani/pocketpal-ai/issues/574), [#407](https://github.com/a-ghorbani/pocketpal-ai/issues/407), [#259](https://github.com/a-ghorbani/pocketpal-ai/issues/259)) but PocketPal does not currently *host* a server. Recent releases add the *reverse*: PocketPal can act as a **client** that connects to an external llama.cpp server and detects its capabilities (vision support, context size). |
| **llama.cpp's own server (`llama-server`)** | ✅ Real, mature | `llama.cpp` ships a first-class OpenAI-compatible HTTP server (`/v1/chat/completions`, vision input, tool-calling, MCP CORS proxy flag). This is the actual thing to run for an API-first design — via Termux on Android, it's the same binary PocketPal itself embeds. |
| **PocketPal neural TTS** | ✅ Real, evolving | Current builds ship streaming neural TTS using compact open models (**Supertonic** confirmed, 31 languages). Whether "Kokoro" specifically is bundled varies by build/version — treat the *category* (small, on-device neural TTS) as reliable, the *specific model name* as config, not gospel. |
| **Kokoro-82M (the model itself)** | ✅ Real, open-weights | 82M-parameter TTS model, runnable standalone via `kokoro-onnx` or similar ONNX runtimes on-device — independent of any particular app bundling it. |
| **Gemma 4 (E2B/E4B)** | ✅ Real, released | Google's edge-optimized MatFormer/PLE architecture models, confirmed via Google's official blog. Good fit for chat+vision. |
| **NOAA/National Weather Service alerts API** | ✅ Real, free, no key | `https://api.weather.gov/alerts/active` — GeoJSON, requires only a descriptive `User-Agent` header, ~5,000 req/hr, no auth. |
| **OpenSky Network (flight tracking)** | ✅ Real, free tier | `https://opensky-network.org/api/states/all` with a bounding box (`lamin/lomin/lamax/lomax`) gives live ADS-B state vectors (callsign, altitude, speed, heading). **Note:** as of March 2026 basic-auth was retired in favor of OAuth2 client-credentials — needs a registered client id/secret, token refreshed every ~30 min. Free for non-commercial use. |
| **Citizen app (crime/safety alerts)** | ⚠️ Enterprise-only | No public consumer API. Citizen sells an **Enterprise API** (`business.citizen.com/api`) aimed at corporate security teams — paid, contractual. Design the provider slot, but expect it gated behind a paid key the user supplies, not something to wire up casually. |
| **Waze (traffic data)** | ❌ No official public API | Google/Waze has never opened a general developer API. Options are: (a) "Waze for Cities" — free but restricted to government/public-sector partners, (b) unofficial third-party scraping resellers (fragile, ToS-risk), (c) skip Waze and use OSM-based traffic where possible. Design the provider slot as "unofficial/best-effort," not core. |
| **Flora/fauna ID** | ✅ Real, feasible | iNaturalist's "Seek" identification models are the standard reference; a fully offline path is a small on-device classifier (e.g., a MobileNet/EfficientNet species classifier) rather than a cloud call — this is closer to a "local vision model" provider than an "API" provider. |
| **MCP (Model Context Protocol)** | ✅ Real, standard | An open protocol (Anthropic-originated, now broadly adopted) for exposing tools to a model/agent over a lightweight JSON-RPC-like transport. Perfect fit as the app's internal spine — the Tricorder *is* an MCP host, and each subsystem (vision, TTS, sensors, context feeds) is an MCP tool. |

**Implication for the build:** don't depend on PocketPal exposing an API — it doesn't, yet. Run `llama-server` directly (via Termux, or a bundled native build) as the actual inference backend, and treat PocketPal as an optional *reference client* / model-downloader convenience, not infrastructure.

---

## 2. High-Level Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                     UI LAYER (dumb renderer)                     │
│   TOS shell: screen · 3 status lights · 3 buttons · speaker      │
│   Subscribes to events. Never calls models/sensors directly.     │
└───────────────────────────────┬───────────────────────────────────┘
                                 │ subscribe/emit
┌───────────────────────────────▼───────────────────────────────────┐
│                          EVENT BUS                                │
│  button.press · sensor.frame · network.changed · provider.data    │
│  tuple.resolved · model.response.delta · model.response.done      │
│  audio.output.start/stop · alert.raised                           │
└───────────────────────────────┬───────────────────────────────────┘
                                 │
┌───────────────────────────────▼───────────────────────────────────┐
│                   TUPLE INFERENCE ENGINE                          │
│   raw input → normalized tuple → config-defined transform rules   │
│   → resolved MCP tool call plan (see §4)                          │
└───────────────────────────────┬───────────────────────────────────┘
                                 │ MCP tool calls
┌───────────────────────────────▼───────────────────────────────────┐
│                    LOCAL MCP SERVER (the spine)                  │
│  Every capability is a tool. Backends are swappable via config.   │
│                                                                    │
│  chat.complete        → llama-server (Gemma 4 E2B, config'd)      │
│  vision.describe       → same or separate VLM (SmolVLM2, config'd)│
│  image.generate        → SD backend (config'd, optional)          │
│  speech.synthesize     → TTS backend (Kokoro/Supertonic, config'd)│
│  speech.transcribe     → local STT (Whisper-tiny, config'd)       │
│  sensor.motion_delta    → OpenCV frame-diff (local, always on)     │
│  context.<provider_id> → pluggable, see §6 (weather/flights/etc.) │
└───────────────────────────────┬───────────────────────────────────┘
                                 │
                    ┌────────────┴────────────┐
              ON-DEVICE MODELS           NETWORK PROVIDERS
           (always available,          (only if Wi-Fi/cell alive;
            zero network needed)        each individually toggleable)
```

Nothing in the UI or event bus knows a model's name, a provider's URL, or which button means what. That's all config.

---

## 3. The Config Document (single source of truth)

One JSON (or YAML) file, hot-reloadable, versioned. Sketch of the shape — this is illustrative, not final:

```json
{
  "config_version": "0.1",

  "models": {
    "chat_vision": {
      "id": "gemma-4-e2b",
      "endpoint": "http://127.0.0.1:8080/v1/chat/completions",
      "supports_vision": true,
      "context_tokens": 8192,
      "quant": "Q4_K_M"
    },
    "vision_fast": {
      "id": "smolvlm2-500m-video-instruct",
      "endpoint": "http://127.0.0.1:8081/v1/chat/completions",
      "supports_vision": true,
      "use_for": ["sensor_mode_stream"]
    },
    "image_generation": {
      "id": "sd-turbo-mobile-q4",
      "endpoint": "http://127.0.0.1:8188/v1/images/generations",
      "enabled": false
    },
    "tts": {
      "id": "kokoro-82m",
      "endpoint": "http://127.0.0.1:5000/v1/audio/speech",
      "voice": "computer_female_measured"
    },
    "stt": {
      "id": "whisper-tiny-en",
      "endpoint": "http://127.0.0.1:5001/v1/audio/transcriptions"
    }
  },

  "controls": {
    "buttons": [
      { "id": "btn_1", "label": "Inquiry",  "tuple_seed": ["CHATTING", "AUDIO_IN", "AUTO", "TOGGLE"] },
      { "id": "btn_2", "label": "Sensor",   "tuple_seed": ["SCANNING", "CAMERA",  "VISION", "LOOP"] },
      { "id": "btn_3", "label": "Sentry",   "tuple_seed": ["GUARDING", "CAMERA",  "MOTION", "LOOP"] }
    ],
    "note": "button->tuple mapping is data, not code. Re-map or add a 4th button without touching app logic."
  },

  "tuple_rules": [
    {
      "match": { "mode": "CHATTING", "target_hint": "IMAGE_GEN" },
      "route_to": "models.image_generation",
      "fallback": "models.chat_vision"
    },
    {
      "match": { "mode": "CHATTING", "target_hint": "*" },
      "route_to": "models.chat_vision"
    },
    {
      "match": { "mode": "SCANNING" },
      "route_to": "models.vision_fast",
      "loop_interval_ms": 3500
    },
    {
      "match": { "mode": "GUARDING" },
      "route_to": "sensor.motion_delta",
      "escalate_to": "models.vision_fast",
      "escalation_threshold_pct": 12.5
    }
  ],

  "context_providers": {
    "geolocation": { "enabled": true,  "requires_network": false, "source": "device_gps" },
    "clock_env":   { "enabled": true,  "requires_network": false, "source": "device_sensors" },
    "weather_alerts_noaa": {
      "enabled": false, "requires_network": true,
      "endpoint": "https://api.weather.gov/alerts/active",
      "auth": "none", "poll_interval_s": 300
    },
    "flight_overhead": {
      "enabled": false, "requires_network": true,
      "endpoint": "https://opensky-network.org/api/states/all",
      "auth": "oauth2_client_credentials", "poll_interval_s": 20,
      "bbox_radius_km": 15
    },
    "crime_safety_citizen": {
      "enabled": false, "requires_network": true,
      "endpoint": "https://business.citizen.com/api",
      "auth": "enterprise_api_key", "notes": "paid/contractual, not casually available"
    },
    "flora_fauna_id": {
      "enabled": false, "requires_network": false,
      "source": "local_classifier_model", "notes": "on-device model, not an API"
    },
    "traffic_waze": {
      "enabled": false, "requires_network": true,
      "endpoint": null, "auth": "none_available",
      "notes": "no official public API; unofficial only, treat as best-effort/roadmap"
    }
  },

  "ui": {
    "theme": "tos_1966",
    "status_lights": ["idle", "listening", "processing"],
    "sensor_sound": "classic_chirp.wav"
  }
}
```

Every provider entry has the same shape: `enabled`, `requires_network`, `endpoint`/`source`, `auth`, and a polling or trigger cadence. Adding NOAA alerts, or Waze, or a fourth button, is a config edit — never a code change.

---

## 4. Algebraic Tuple Intent Engine

**Tuple shape:** `I = (Mode, InputChannel, TargetModality, Action)`

- **Mode** — the current top-level state (`CHATTING`, `SCANNING`, `GUARDING`, `IDLE`)
- **InputChannel** — where the stimulus came from (`AUDIO_IN`, `CAMERA`, `TEXT`, `TIMER`)
- **TargetModality** — what kind of output is wanted (`TEXT`, `IMAGE_GEN`, `VISION`, `MOTION`, `AUTO`)
- **Action** — what to do with it (`EXECUTE`, `TOGGLE`, `LOOP`, `STOP`)

**Transformations** are pattern → route rules, loaded from `tuple_rules` in config (§3), evaluated in order, first match wins. This is deliberately *not* an LLM doing intent classification — it's a cheap, deterministic, offline-safe router. The LLM only gets invoked *after* routing decides it should be.

This keeps the system fast (no model call needed to know a button press means "start sensor loop") and fully auditable — you can read the config and know exactly what every input does.

---

## 5. Event Bus — the vocabulary

| Event | Payload | Emitted by |
|---|---|---|
| `button.press` | `{ button_id }` | UI |
| `input.audio_captured` | `{ transcript }` | STT tool |
| `tuple.resolved` | `{ tuple, route }` | Tuple engine |
| `provider.data` | `{ provider_id, data, ts }` | Context provider poller |
| `model.response.delta` | `{ text_chunk }` | MCP chat tool (streaming) |
| `model.response.done` | `{ full_text }` | MCP chat tool |
| `audio.output.start` / `.stop` | `{ voice_id }` | TTS tool |
| `sensor.motion_delta` | `{ pct_change }` | Motion watcher |
| `alert.raised` | `{ severity, source, message }` | Any provider or sentry logic |

UI components only ever subscribe to this bus. Swapping "3 buttons" for "voice wake word + 1 button" later touches only the input adapters, not the bus contract.

---

## 6. MCP Server — tool catalog (Phase 1)

The app runs (or connects to) a local MCP-compatible server exposing:

- `chat.complete` (streaming, vision-capable when image attached)
- `vision.describe` (single-frame, fast model)
- `speech.synthesize`
- `speech.transcribe`
- `sensor.motion_delta`

Each tool's *implementation* is whatever `models.*` config entry it's bound to. `image.generate` exists in the schema now but stays `enabled: false` in Phase 1 — the seam is there, the wiring isn't, per your "start with the basics" instruction.

Context providers (§3) are exposed the same way — `context.weather_alerts_noaa`, `context.flight_overhead`, etc. — all present in the tool catalog, all `enabled: false` until you're ready.

---

## 7. Phase 1 MVP scope

Build only this first:

1. Event bus + tuple engine (config-driven, per §3–5)
2. `llama-server` running Gemma 4 E2B locally (chat + vision), reached via `models.chat_vision`
3. Button 1 (Inquiry): STT → tuple engine → chat → TTS
4. Button 2 (Sensor): camera loop → fast VLM → text overlay, no network required
5. Button 3 (Sentry): local frame-diff motion watch, no network, no model call until motion crosses threshold
6. Settings page that edits the config JSON directly (raw editor is fine for v0.1; nice UI later)
7. **Every context provider present in config, all disabled** — proves the extensibility shape without spending build time on Citizen/Waze/OpenSky integrations yet

Everything in §1's "not yet real" column (PocketPal-as-server) is explicitly *not* a dependency for Phase 1.

---

## 8. Open questions for next pass

- React Native (reuse PocketPal's `llama.rn` ecosystem) vs. native Kotlin — affects how easily you can embed `llama-server` vs. shell out to Termux.
- Where does the tuple-rule config live for hot-reload — bundled asset, local file, or synced from a companion desktop tool?
- STT: bundle a tiny on-device Whisper, or lean on Android's built-in speech recognizer for Phase 1 and swap later (also just config)?
- For `flight_overhead`, decide now whether OAuth2 client-credential refresh lives in the provider adapter or a shared "auth manager" other providers can reuse (Citizen will need the same shape later).

---

*This document defines the shape. No provider beyond geolocation/clock is wired up yet — that's intentional, per your instruction to nail the basics first while keeping the extensible skeleton in place.*
