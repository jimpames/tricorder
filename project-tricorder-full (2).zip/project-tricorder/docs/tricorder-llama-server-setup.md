# Setting Up `llama-server` on the Fold 3 (Termux)

Goal: get a real, local, OpenAI-compatible endpoint running at
`http://127.0.0.1:8080/v1/chat/completions` — exactly what
`config/tricorder.config.json` already points `models.chat_vision` at.
Nothing in `tricorder-core` needs to change; this just makes the config's
promise real.

---

## 0. One important correction up front

**Don't install Termux from the Play Store.** That build was frozen years
ago and its package mirrors are broken — `pkg install` will fail on modern
packages. Get it from **F-Droid** (or the project's GitHub releases) instead.
If you already have the Play Store version, uninstall it first.

- F-Droid: https://f-droid.org/packages/com.termux/

---

## 1. Storage + base packages

Open Termux and run:

```bash
termux-setup-storage      # grants access to shared storage (Downloads, etc.)
pkg update && pkg upgrade -y
pkg install git cmake clang make -y
```

`termux-setup-storage` pops an Android permission dialog — accept it. It
creates `~/storage/shared`, which is how you'll move a GGUF file in if you
downloaded it in a browser instead of pulling it with `curl` inside Termux.

---

## 2. Build llama.cpp

```bash
cd ~
git clone https://github.com/ggml-org/llama.cpp.git
cd llama.cpp
cmake -B build
cmake --build build --config Release -j$(nproc)
```

This is CPU-only and will take a while on a Snapdragon 888 — that's normal,
it's a one-time build. When it finishes, the binaries you care about are at
`~/llama.cpp/build/bin/llama-server` (and `llama-cli` for quick manual tests).

**Optional, advanced, skip on a first pass:** llama.cpp can also build with
a Vulkan backend to offload some work to the Adreno 660 GPU, via Termux's
`tur-repo` (Termux User Repository) for the Vulkan/shader toolchain. It's a
real speedup on some phones but adds real build complexity and isn't
guaranteed on the 888's driver stack — get the CPU build working first,
come back to Vulkan later if 5–15 tok/s isn't fast enough for you.

---

## 3. Get a model

Two ways. Easiest first:

**Option A — let llama-server fetch it for you:**

```bash
cd ~/llama.cpp
./build/bin/llama-server -hf ggml-org/gemma-3-4b-it-GGUF --host 127.0.0.1 --port 8080
```

The `-hf` flag downloads the GGUF (and, if the repo has one, the matching
`mmproj` file) straight from Hugging Face on first run. Swap the repo id for
whichever Gemma 4 E2B GGUF repo you land on (check current names on Hugging
Face — these get reorganized).

**Option B — download manually, useful if `-hf` can't find your exact repo:**

```bash
cd ~
curl -L -o gemma-4-e2b-it-Q4_K_M.gguf "<direct GGUF URL from Hugging Face>"
curl -L -o mmproj-gemma-4-e2b-it-F16.gguf "<direct mmproj URL from Hugging Face>"
```

The mmproj filename **must start with `mmproj`** — that's how llama.cpp's
tooling recognizes it as the vision projector rather than a second model
shard.

---

## 4. Run the server (manual model files)

```bash
cd ~/llama.cpp
./build/bin/llama-server \
  -m ~/gemma-4-e2b-it-Q4_K_M.gguf \
  --mmproj ~/mmproj-gemma-4-e2b-it-F16.gguf \
  --host 127.0.0.1 \
  --port 8080 \
  -c 8192
```

- `--host 127.0.0.1` keeps it reachable only from the phone itself — matches
  `config.json`'s `http://127.0.0.1:...` endpoints and means nothing on your
  LAN can reach it. (Loosen this deliberately later if you want the
  "connect from my laptop" trick from the earlier PocketPal research —
  that's a config change here, not a code change in `tricorder-core`.)
- `-c 8192` matches `models.chat_vision.context_tokens` in the reference
  config. Keep these in sync if you change one.
- Without `--mmproj`, the server still runs and answers text fine — vision
  input will just be ignored. Add it once you've confirmed text works.

Leave this running in the Termux session. To keep Android from killing it
in the background:

```bash
termux-wake-lock
```

Run that in a **second** Termux session (swipe to open another) so the
server keeps its own session in the foreground; `termux-wake-lock` just
stops the OS from suspending the Termux app entirely.

---

## 5. Verify it against the same shape `tricorder-core` expects

```bash
curl http://127.0.0.1:8080/v1/chat/completions \
  -H "Content-Type: application/json" \
  -d '{
    "messages": [{ "role": "user", "content": "What is the distance from Earth to Alpha Centauri?" }],
    "stream": false
  }'
```

You should get back a JSON body with a `choices[0].message.content` field —
standard OpenAI chat-completions shape.

**Important gap to close next in `tricorder-core`:** the current
`McpClient` in `mcpClient.mjs` POSTs whatever payload it's given, verbatim,
and the tests feed it `{ prompt: "..." }` for simplicity. A real
`llama-server` expects the `{ messages: [...] }` shape above, not `prompt`.
The fix is a small **payload-builder** step between the tuple engine's
decision and `client.callRoute(...)` — something that turns
`(tuple, transcript)` into `{ messages: [...] }` for a chat route, or
`{ image_url, prompt }`-shaped bodies for the image-gen route once that's
enabled. That builder is genuinely the next piece of `tricorder-core` to
write, and it's a good, small, testable unit on its own — happy to build it
next if you want.

---

## 6. The second model (`vision_fast`, port 8081)

The config also has `models.vision_fast` pointed at
`http://127.0.0.1:8081/...` for the fast sensor-mode VLM (SmolVLM2 or
similar). Running two `llama-server` processes at once on a Snapdragon 888
is real memory/CPU pressure — for now, the pragmatic move is:

- **If RAM allows:** repeat steps 3–4 with a second model and
  `--port 8081` in a third Termux session.
- **If it doesn't:** temporarily point `models.vision_fast.endpoint` at
  `127.0.0.1:8080` (the same server) in `tricorder.config.json` — no code
  change, just a config edit — and revisit running two servers once you've
  seen how the single one performs.

---

## 7. Sanity checklist before moving on

- [ ] Termux installed from F-Droid, not Play Store
- [ ] `llama-server` builds and runs without crashing
- [ ] `curl` test above returns a real completion
- [ ] `termux-wake-lock` keeps it alive when you switch apps
- [ ] Phone doesn't overheat badly within ~5 minutes of steady chat (if it
      does, lower `-c`, or add `--threads 4` to cap CPU thread count instead
      of using all 8 cores)

---

## Next steps after this

1. Write the **payload-builder** in `tricorder-core` (§5 above) so
   `McpClient` sends real OpenAI-shaped bodies.
2. Do the same Termux pattern for TTS/STT — `llama.cpp` doesn't do
   speech, so `models.tts` / `models.stt` need a separate small server
   (e.g. a `kokoro-onnx` Python process, or `whisper.cpp`'s own server binary,
   which is a sibling build in the same `llama.cpp`-adjacent ecosystem).
3. Once both are confirmed, the sensor-loop driver and the UI shell are
   what's left per the original roadmap.
