#!/data/data/com.termux/files/usr/bin/bash
# Download the four on-device weights this tricorder expects.
# Safe to re-run. Uses wget -c so a dropped Wi-Fi just resumes.
set -euo pipefail
MODELS="${TRICORDER_MODELS:-$HOME/models}"
KOKORO="${TRICORDER_KOKORO:-$HOME/kokoro}"
mkdir -p "$MODELS" "$KOKORO"

need() { command -v "$1" >/dev/null || { echo "pkg install $1"; exit 1; }; }
need wget

pull() {
  local url="$1" dest="$2"
  if [[ -s "$dest" ]]; then
    echo "have $(basename "$dest")  $(du -h "$dest" | awk '{print $1}')"
    return 0
  fi
  echo "get $(basename "$dest")"
  wget -c --show-progress -O "$dest.part" "$url"
  mv "$dest.part" "$dest"
}

echo "== models -> $MODELS"

# Chat ~2.5 GB  (Gemma license — accept on huggingface.co first if gated)
pull "https://huggingface.co/ggml-org/gemma-3-4b-it-GGUF/resolve/main/gemma-3-4b-it-Q4_K_M.gguf" \
     "$MODELS/gemma-3-4b-it-Q4_K_M.gguf"

# Vision ~0.4 + 0.2 GB
pull "https://huggingface.co/ggml-org/SmolVLM2-500M-Video-Instruct-GGUF/resolve/main/SmolVLM2-500M-Video-Instruct-Q8_0.gguf" \
     "$MODELS/SmolVLM2-500M-Video-Instruct-Q8_0.gguf"
pull "https://huggingface.co/ggml-org/SmolVLM2-500M-Video-Instruct-GGUF/resolve/main/mmproj-SmolVLM2-500M-Video-Instruct-f16.gguf" \
     "$MODELS/mmproj-SmolVLM2-500M-Video-Instruct-f16.gguf"

# Imagine ~2.2 GB
pull "https://huggingface.co/gpustack/stable-diffusion-v2-1-turbo-GGUF/resolve/main/stable-diffusion-v2-1-turbo-Q4_0.gguf" \
     "$MODELS/stable-diffusion-v2-1-turbo-Q4_0.gguf"

echo "== kokoro -> $KOKORO"
pull "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/kokoro-v1.0.onnx" \
     "$KOKORO/kokoro-v1.0.onnx"
pull "https://github.com/thewh1teagle/kokoro-onnx/releases/download/model-files-v1.0/voices-v1.0.bin" \
     "$KOKORO/voices-v1.0.bin"

echo
echo "done"
ls -lh "$MODELS" "$KOKORO"
echo
echo "next: copy termux/tricorder to ~/bin/tricorder && chmod +x ~/bin/tricorder && ~/bin/tricorder start"
