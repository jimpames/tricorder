package com.projecttricorder.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Bundle as OsBundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.webkit.GeolocationPermissions
import android.webkit.PermissionRequest
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.ConnectivityManager
import android.os.BatteryManager
import android.os.SystemClock
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.window.layout.FoldingFeature
import androidx.window.layout.WindowInfoTracker
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var webView: WebView
    private lateinit var bridge: TricorderBridge
    private var speechRecognizer: SpeechRecognizer? = null
    private var ttsPlayer: MediaPlayer? = null
    private val ttsExecutor = Executors.newSingleThreadExecutor()
    @Volatile private var pressureHpa: Double? = null
    @Volatile private var ambientC: Double? = null
    @Volatile private var humidityPct: Double? = null
    @Volatile private var earthLink: Boolean? = null
    private var sensorManager: SensorManager? = null
    private val envListener = object : SensorEventListener {
        override fun onSensorChanged(event: SensorEvent?) {
            val e = event ?: return
            when (e.sensor.type) {
                Sensor.TYPE_PRESSURE -> pressureHpa = e.values[0].toDouble()
                Sensor.TYPE_AMBIENT_TEMPERATURE -> ambientC = e.values[0].toDouble()
                Sensor.TYPE_RELATIVE_HUMIDITY -> humidityPct = e.values[0].toDouble()
            }
        }
        override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { /* WebView will re-request via WebChromeClient if still needed */ }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        bridge = TricorderBridge(this)

        webView = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.mediaPlaybackRequiresUserGesture = false
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            settings.cacheMode = WebSettings.LOAD_DEFAULT
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.javaScriptCanOpenWindowsAutomatically = true
            settings.setSupportZoom(false)
            settings.builtInZoomControls = false
            settings.displayZoomControls = false
            settings.userAgentString = settings.userAgentString + " TricorderNative/0.1"
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                settings.safeBrowsingEnabled = false
            }
            addJavascriptInterface(bridge, "TricorderNative")
            webViewClient = object : WebViewClient() {
                override fun shouldOverrideUrlLoading(
                    view: WebView,
                    request: WebResourceRequest,
                ): Boolean = false

                override fun onPageFinished(view: WebView, url: String?) {
                    injectNativeBanner()
                }
            }
            webChromeClient = object : WebChromeClient() {
                override fun onPermissionRequest(request: PermissionRequest) {
                    request.grant(request.resources)
                }

                override fun onGeolocationPermissionsShowPrompt(
                    origin: String?,
                    callback: GeolocationPermissions.Callback?,
                ) {
                    callback?.invoke(origin, true, false)
                }
            }
        }

        setContentView(webView)
        requestRuntimePermissions()
        observeFoldPosture()
        startEnvSensors()
        ttsExecutor.execute { earthLink = probeEarthLink() }
        webView.loadUrl("file:///android_asset/www/tricorder-ui-shell.html")
    }

    private fun injectNativeBanner() {
        val js = """
            (function () {
              try {
                window.__TRICORDER_NATIVE__ = true;
                var plate = document.querySelector('.nameplate');
                if (plate && !document.getElementById('native-badge')) {
                  var badge = document.createElement('div');
                  badge.id = 'native-badge';
                  badge.style.cssText = 'margin-top:6px;font-size:9px;letter-spacing:0.16em;color:#7dffb0;';
                  badge.textContent = 'NATIVE APK  ·  WEBVIEW WRAPPER';
                  plate.appendChild(badge);
                }
              } catch (e) {}
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun requestRuntimePermissions() {
        val wanted = mutableListOf(
            Manifest.permission.CAMERA,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION,
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            wanted += Manifest.permission.BLUETOOTH_SCAN
            wanted += Manifest.permission.BLUETOOTH_CONNECT
        }
        val missing = wanted.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isNotEmpty()) {
            permissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun observeFoldPosture() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                WindowInfoTracker.getOrCreate(this@MainActivity)
                    .windowLayoutInfo(this@MainActivity)
                    .collect { info ->
                        val folding = info.displayFeatures.filterIsInstance<FoldingFeature>().firstOrNull()
                        if (folding == null) {
                            bridge.updatePosture("FLAT_OR_PHONE", "UNKNOWN", "windowmanager")
                        } else {
                            val state = when (folding.state) {
                                FoldingFeature.State.FLAT -> "FLAT"
                                FoldingFeature.State.HALF_OPENED -> "HALF_OPENED"
                                else -> "UNKNOWN"
                            }
                            val orientation = when (folding.orientation) {
                                FoldingFeature.Orientation.HORIZONTAL -> "HORIZONTAL"
                                FoldingFeature.Orientation.VERTICAL -> "VERTICAL"
                                else -> "UNKNOWN"
                            }
                            bridge.updatePosture(state, orientation, "windowmanager")
                        }
                    }
            }
        }
    }

    fun startNativeListen() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            evalJs("window.__tricorderSpeechError && window.__tricorderSpeechError('mic permission denied')")
            permissionLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO))
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            evalJs("window.__tricorderSpeechError && window.__tricorderSpeechError('no on-device recognizer')")
            return
        }
        stopNativeListen()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: OsBundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {
                val msg = when (error) {
                    SpeechRecognizer.ERROR_NO_MATCH -> "no match"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "timeout"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "mic permission denied"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "network"
                    SpeechRecognizer.ERROR_CLIENT -> "canceled"
                    else -> "error $error"
                }
                evalJs("window.__tricorderSpeechError && window.__tricorderSpeechError(${jsonStr(msg)})")
            }
            override fun onResults(results: OsBundle?) {
                val said = results
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                evalJs("window.__tricorderSpeechResult && window.__tricorderSpeechResult(${jsonStr(said)})")
            }
            override fun onPartialResults(partialResults: OsBundle?) {
                val said = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                    .orEmpty()
                if (said.isNotBlank()) {
                    evalJs("window.__tricorderSpeechPartial && window.__tricorderSpeechPartial(${jsonStr(said)})")
                }
            }
            override fun onEvent(eventType: Int, params: OsBundle?) {}
        })
        speechRecognizer = rec
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        rec.startListening(intent)
    }

    fun stopNativeListen() {
        try { speechRecognizer?.stopListening() } catch (_: Exception) {}
        try { speechRecognizer?.cancel() } catch (_: Exception) {}
        try { speechRecognizer?.destroy() } catch (_: Exception) {}
        speechRecognizer = null
    }

    private fun evalJs(code: String) {
        if (!this::webView.isInitialized) return
        webView.post { webView.evaluateJavascript(code, null) }
    }

    private fun jsonStr(s: String): String =
        org.json.JSONObject.quote(s)

    fun speakKokoro(text: String) {
        val clipped = text.trim().take(2000)
        if (clipped.isEmpty()) return
        ttsExecutor.execute {
            try {
                runOnUiThread { stopKokoro() }
                val conn = (URL("http://127.0.0.1:5000/v1/audio/speech").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    setRequestProperty("Content-Type", "application/json")
                    doOutput = true
                    connectTimeout = 8000
                    readTimeout = 120_000
                }
                val body = org.json.JSONObject()
                    .put("model", "kokoro-82m")
                    .put("input", clipped)
                    .put("voice", "af_bella")
                    .toString()
                    .toByteArray()
                conn.outputStream.use { it.write(body) }
                val code = conn.responseCode
                if (code !in 200..299) {
                    notifyTtsFallback(clipped)
                    return@execute
                }
                val bytes = conn.inputStream.use { it.readBytes() }
                if (bytes.isEmpty()) {
                    notifyTtsFallback(clipped)
                    return@execute
                }
                val tmp = File(cacheDir, "kokoro-play.wav")
                tmp.writeBytes(bytes)
                runOnUiThread {
                    try {
                        val mp = MediaPlayer()
                        ttsPlayer = mp
                        mp.setAudioAttributes(
                            AudioAttributes.Builder()
                                .setUsage(AudioAttributes.USAGE_MEDIA)
                                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                                .build(),
                        )
                        mp.setDataSource(tmp.absolutePath)
                        mp.setOnCompletionListener {
                            it.release()
                            if (ttsPlayer === it) ttsPlayer = null
                            webView.evaluateJavascript("window.__tricorderTtsDone && window.__tricorderTtsDone()", null)
                        }
                        mp.setOnErrorListener { _, _, _ ->
                            notifyTtsFallback(clipped)
                            true
                        }
                        mp.prepare()
                        mp.start()
                    } catch (_: Exception) {
                        notifyTtsFallback(clipped)
                    }
                }
            } catch (_: Exception) {
                notifyTtsFallback(clipped)
            }
        }
    }

    private fun startEnvSensors() {
        val sm = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManager = sm
        listOf(
            Sensor.TYPE_PRESSURE,
            Sensor.TYPE_AMBIENT_TEMPERATURE,
            Sensor.TYPE_RELATIVE_HUMIDITY,
        ).forEach { type ->
            sm.getDefaultSensor(type)?.let { sm.registerListener(envListener, it, SensorManager.SENSOR_DELAY_NORMAL) }
        }
    }

    private fun probeEarthLink(): Boolean {
        return try {
            val proc = Runtime.getRuntime().exec(arrayOf("/system/bin/ping", "-c", "1", "-W", "2", "8.8.8.8"))
            val code = proc.waitFor()
            if (code == 0) return true
            val conn = URL("https://clients3.google.com/generate_204").openConnection() as HttpURLConnection
            conn.connectTimeout = 2000
            conn.readTimeout = 2000
            conn.requestMethod = "HEAD"
            conn.responseCode in 200..399
        } catch (_: Exception) {
            false
        }
    }

    fun shipStatusJson(): String {
        ttsExecutor.execute { earthLink = probeEarthLink() }
        val bm = getSystemService(BatteryManager::class.java)
        val battery = bm?.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY) ?: -1
        val cm = getSystemService(ConnectivityManager::class.java)
        val net = cm?.activeNetwork != null
        val uptimeMs = SystemClock.elapsedRealtime()
        return org.json.JSONObject()
            .put("battery_pct", battery)
            .put("uptime_ms", uptimeMs)
            .put("network", net)
            .put("earth_link", earthLink == true)
            .put("pressure_hpa", pressureHpa ?: org.json.JSONObject.NULL)
            .put("temp_c", ambientC ?: org.json.JSONObject.NULL)
            .put("humidity_pct", humidityPct ?: org.json.JSONObject.NULL)
            .put("model", Build.MODEL)
            .toString()
    }

    fun stopKokoro() {
        try {
            ttsPlayer?.stop()
        } catch (_: Exception) { }
        try {
            ttsPlayer?.release()
        } catch (_: Exception) { }
        ttsPlayer = null
    }

    private fun notifyTtsFallback(text: String) {
        runOnUiThread {
            webView.evaluateJavascript(
                "window.__tricorderTtsFallback && window.__tricorderTtsFallback(${jsonStr(text)})",
                null,
            )
        }
    }

    override fun onDestroy() {
        try { sensorManager?.unregisterListener(envListener) } catch (_: Exception) {}
        stopKokoro()
        ttsExecutor.shutdownNow()
        stopNativeListen()
        webView.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (this::webView.isInitialized && webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}
