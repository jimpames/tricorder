package com.projecttricorder.app

import android.content.Context
import android.os.Build
import android.webkit.JavascriptInterface
import org.json.JSONObject

class TricorderBridge(private val activity: MainActivity) {

    @Volatile
    private var postureJson: String = """{"state":"UNKNOWN","orientation":"UNKNOWN","source":"none"}"""

    fun updatePosture(state: String, orientation: String, source: String) {
        postureJson = JSONObject()
            .put("state", state)
            .put("orientation", orientation)
            .put("source", source)
            .toString()
    }

    @JavascriptInterface
    fun getCapabilities(): String {
        return JSONObject()
            .put("platform", "android")
            .put("wrapper", "webview")
            .put("version", BuildConfig.VERSION_NAME)
            .put("sdk", Build.VERSION.SDK_INT)
            .put("manufacturer", Build.MANUFACTURER)
            .put("model", Build.MODEL)
            .put("device", Build.DEVICE)
            .put("foldPosture", true)
            .put("speech", true)
            .put("uwb", false)
            .put("nfc", false)
            .put("ambientBle", false)
            .toString()
    }

    @JavascriptInterface
    fun getFoldPosture(): String = postureJson

    @JavascriptInterface
    fun getDeviceInfo(): String {
        return JSONObject()
            .put("manufacturer", Build.MANUFACTURER)
            .put("model", Build.MODEL)
            .put("device", Build.DEVICE)
            .put("product", Build.PRODUCT)
            .put("release", Build.VERSION.RELEASE)
            .put("sdk", Build.VERSION.SDK_INT)
            .toString()
    }

    @JavascriptInterface
    fun vibrate(ms: Int) {
        val ctx = activity
        val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val mgr = ctx.getSystemService(android.os.VibratorManager::class.java)
            mgr?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            ctx.getSystemService(Context.VIBRATOR_SERVICE) as? android.os.Vibrator
        }
        vibrator?.vibrate(
            android.os.VibrationEffect.createOneShot(
                ms.coerceIn(10, 400).toLong(),
                android.os.VibrationEffect.DEFAULT_AMPLITUDE,
            ),
        )
    }

    @JavascriptInterface
    fun startListening() {
        activity.runOnUiThread { activity.startNativeListen() }
    }

    @JavascriptInterface
    fun stopListening() {
        activity.runOnUiThread { activity.stopNativeListen() }
    }

    @JavascriptInterface
    fun speakKokoro(text: String) {
        activity.speakKokoro(text)
    }

    @JavascriptInterface
    fun stopKokoro() {
        activity.stopKokoro()
    }

    @JavascriptInterface
    fun getShipStatus(): String = activity.shipStatusJson()
}
