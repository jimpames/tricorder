# Debug sideload APK — no shrinking.
-keepclassmembers class com.projecttricorder.app.TricorderBridge {
    public *;
}
