# Building the Tricorder APK

This folder is a minimal Kotlin + WebView Android app that loads
`ui-shell/tricorder-ui-shell.html` from assets.

## Sideload the prebuilt debug APK

If you already have `Tricorder-debug.apk` from this session:

1. Copy it to the phone.
2. Settings → Security → allow install from this source.
3. Open the APK and install.
4. On first launch, grant Camera / Location / Nearby devices when asked.

No Play Store signing is required for personal sideloading.

## Build it yourself (Android Studio)

1. Open the `android-app` folder in Android Studio.
2. Let Gradle sync.
3. Run **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
4. Debug APK lands at `app/build/outputs/apk/debug/app-debug.apk`.

## Build it yourself (command line)

```bash
export ANDROID_HOME=/path/to/Android/Sdk
export JAVA_HOME=/path/to/jdk-17
cd android-app
gradle assembleDebug     # or ./gradlew assembleDebug once a wrapper jar exists
```

## What this wrapper does / does not do

Does:

- Loads the existing TOS UI shell unchanged.
- Grants WebView camera / mic / geolocation so Sensor + Sentry can use `getUserMedia`.
- Allows cleartext HTTP so a Termux `llama-server` on `http://127.0.0.1:8080` works.
- Exposes `window.TricorderNative` with `getCapabilities()`, `getFoldPosture()`, `getDeviceInfo()`, `vibrate(ms)`.
- Listens to Jetpack WindowManager for Fold 3 posture (`FLAT` / `HALF_OPENED`).

Does not (yet):

- Ambient BLE scanning (Web Bluetooth picker still used if the WebView supports it; most don't).
- UWB ranging or NFC.
- A foreground service, so Sentry will pause when the app is backgrounded.

Those are the next native-bridge slices, not blockers for a first sideloadable APK.
