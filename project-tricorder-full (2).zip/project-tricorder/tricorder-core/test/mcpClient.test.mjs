import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ConfigLoader } from '../src/configLoader.mjs';
import { EventBus } from '../src/eventBus.mjs';
import { McpClient, resolveRoutePath, RouteResolutionError } from '../src/mcpClient.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = path.join(__dirname, '..', 'config', 'tricorder.config.json');

async function loadClient({ fetchImpl } = {}) {
  const bus = new EventBus();
  const loader = new ConfigLoader(CONFIG_PATH, bus);
  await loader.load();
  return { client: new McpClient(loader, bus, { fetchImpl }), bus, loader };
}

test('resolveRoutePath walks a dotted path into the config', async () => {
  const loader = new ConfigLoader(CONFIG_PATH);
  const config = await loader.load();
  const target = resolveRoutePath(config, 'models.chat_vision');
  assert.equal(target.id, 'gemma-4-e2b');
});

test('resolveRoutePath returns undefined for a path that does not exist', async () => {
  const loader = new ConfigLoader(CONFIG_PATH);
  const config = await loader.load();
  assert.equal(resolveRoutePath(config, 'models.nope'), undefined);
});

test('callRoute POSTs to the configured endpoint and returns the parsed JSON', async () => {
  const calls = [];
  const fetchImpl = async (url, opts) => {
    calls.push({ url, body: JSON.parse(opts.body) });
    return { ok: true, json: async () => ({ text: 'Alpha Centauri is 4.37 light-years away.' }) };
  };
  const { client } = await loadClient({ fetchImpl });

  const result = await client.callRoute(
    { route_to: 'models.chat_vision' },
    { prompt: 'distance to Alpha Centauri' }
  );

  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'http://127.0.0.1:8080/v1/chat/completions');
  assert.deepEqual(result, { text: 'Alpha Centauri is 4.37 light-years away.' });
});

test('callRoute refuses a route whose config target is disabled', async () => {
  const { client } = await loadClient({ fetchImpl: async () => ({ ok: true, json: async () => ({}) }) });

  await assert.rejects(
    () => client.callRoute({ route_to: 'models.image_generation' }, {}),
    RouteResolutionError
  );
});

test('callRoute falls back when the primary route is disabled, and emits route.fallback_used', async () => {
  const calls = [];
  const fetchImpl = async (url) => {
    calls.push(url);
    return { ok: true, json: async () => ({ image_url: 'file://talos-iv.png' }) };
  };
  const { client, bus } = await loadClient({ fetchImpl });

  const fallbackEvents = [];
  bus.on('route.fallback_used', (payload) => fallbackEvents.push(payload));

  const result = await client.callRoute(
    { route_to: 'models.image_generation', fallback: 'models.chat_vision' },
    { prompt: 'Talos Four' }
  );

  assert.equal(calls.length, 1);
  assert.equal(calls[0], 'http://127.0.0.1:8080/v1/chat/completions');
  assert.deepEqual(result, { image_url: 'file://talos-iv.png' });
  assert.equal(fallbackEvents.length, 1);
  assert.equal(fallbackEvents[0].primary, 'models.image_generation');
});

test('callRoute throws if both primary and fallback are unavailable', async () => {
  const { client } = await loadClient({ fetchImpl: async () => ({ ok: true, json: async () => ({}) }) });

  await assert.rejects(() =>
    client.callRoute({ route_to: 'models.image_generation', fallback: 'models.nonexistent' }, {})
  );
});

test('registerLocalHandler intercepts a route before any HTTP call is attempted', async () => {
  let fetchCalled = false;
  const { client } = await loadClient({ fetchImpl: async () => { fetchCalled = true; return { ok: true, json: async () => ({}) }; } });

  client.registerLocalHandler('sensor.motion_delta', async () => ({ pct_change: 3.2 }));

  const result = await client.callRoute({ route_to: 'sensor.motion_delta' }, {});

  assert.deepEqual(result, { pct_change: 3.2 });
  assert.equal(fetchCalled, false);
});

test('callRoute surfaces a clear error when the backend returns a non-OK status', async () => {
  const { client } = await loadClient({ fetchImpl: async () => ({ ok: false, status: 503 }) });

  await assert.rejects(
    () => client.callRoute({ route_to: 'models.chat_vision' }, {}),
    /returned 503/
  );
});

test('callRouteWithContext builds an OpenAI-chat-vision body for chat_vision using the config protocol', async () => {
  const calls = [];
  const fetchImpl = async (url, opts) => {
    calls.push({ url, body: JSON.parse(opts.body) });
    return { ok: true, json: async () => ({ choices: [{ message: { content: '4.37 light-years' } }] }) };
  };
  const { client } = await loadClient({ fetchImpl });

  await client.callRouteWithContext(
    { route_to: 'models.chat_vision' },
    { text: 'distance to Alpha Centauri' }
  );

  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0].body, {
    model: 'gemma-4-e2b',
    messages: [{ role: 'user', content: 'distance to Alpha Centauri' }],
    stream: false,
  });
});

test('callRouteWithContext rebuilds the payload for a fallback target with a different protocol', async () => {
  const calls = [];
  const fetchImpl = async (url, opts) => {
    calls.push({ url, body: JSON.parse(opts.body) });
    return { ok: true, json: async () => ({ choices: [{ message: { content: 'described instead' } }] }) };
  };
  const { client } = await loadClient({ fetchImpl });

  // image_generation is disabled in the reference config, so this must fall
  // back to chat_vision — and the fallback body must be openai_chat_vision
  // shaped (messages array), NOT openai_images shaped (prompt/n/size),
  // even though the *primary* route's protocol was openai_images.
  await client.callRouteWithContext(
    { route_to: 'models.image_generation', fallback: 'models.chat_vision' },
    { text: 'Talos Four' }
  );

  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'http://127.0.0.1:8080/v1/chat/completions');
  assert.deepEqual(calls[0].body.messages, [{ role: 'user', content: 'Talos Four' }]);
  assert.equal('prompt' in calls[0].body, false);
});

test('callRouteWithContext passes images through to a vision-capable route', async () => {
  const calls = [];
  const fetchImpl = async (url, opts) => {
    calls.push(JSON.parse(opts.body));
    return { ok: true, json: async () => ({}) };
  };
  const { client } = await loadClient({ fetchImpl });

  await client.callRouteWithContext(
    { route_to: 'models.vision_fast' },
    { text: 'What do you see?', images: ['data:image/jpeg;base64,AAA='] }
  );

  const content = calls[0].messages[0].content;
  assert.equal(content[0].text, 'What do you see?');
  assert.equal(content[1].image_url.url, 'data:image/jpeg;base64,AAA=');
});

test('callRouteWithContext gives a local handler the raw context, not a built payload', async () => {
  const { client } = await loadClient({ fetchImpl: async () => ({ ok: true, json: async () => ({}) }) });
  let received;
  client.registerLocalHandler('sensor.motion_delta', async (ctx) => {
    received = ctx;
    return { pct_change: 1 };
  });

  await client.callRouteWithContext({ route_to: 'sensor.motion_delta' }, { frame: 42 });

  assert.deepEqual(received, { frame: 42 });
});
