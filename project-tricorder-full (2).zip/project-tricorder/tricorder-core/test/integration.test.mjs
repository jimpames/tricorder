import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ConfigLoader } from '../src/configLoader.mjs';
import { EventBus, Events } from '../src/eventBus.mjs';
import { TupleEngine } from '../src/tupleEngine.mjs';
import { McpClient } from '../src/mcpClient.mjs';
import { SensorLoopDriver } from '../src/sensorLoopDriver.mjs';
import { ContextProviderPoller } from '../src/contextProviderPoller.mjs';
import { fetchActiveAlerts, deriveSevereAlerts } from '../src/providers/noaaWeatherAlerts.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = path.join(__dirname, '..', 'config', 'tricorder.config.json');

async function loadStack({ fetchImpl }) {
  const bus = new EventBus();
  const loader = new ConfigLoader(CONFIG_PATH, bus);
  await loader.load();
  const engine = new TupleEngine(loader, bus);
  const client = new McpClient(loader, bus, { fetchImpl });
  return { bus, loader, engine, client };
}

test('"What is the distance to Alpha Centauri?" -> chat_vision, spoken reply', async () => {
  const fetchImpl = async (url, opts) => {
    const body = JSON.parse(opts.body);
    if (url.includes('8080')) {
      return { ok: true, json: async () => ({ text: `Alpha Centauri is about 4.37 light-years away. (heard: "${body.prompt}")` }) };
    }
    throw new Error(`unexpected endpoint in test: ${url}`);
  };
  const { engine, client } = await loadStack({ fetchImpl });

  const decision = engine.resolveButtonPress('btn_1', {
    text: 'What is the distance from Earth to Alpha Centauri?',
  });
  assert.equal(decision.rule.route_to, 'models.chat_vision');

  const response = await client.callRoute(decision.rule, { prompt: decision.tuple.mode });
  assert.match(response.text, /4\.37 light-years/);
});

test('"Computer, show me an image of Talos Four" -> image_generation disabled -> falls back to chat_vision', async () => {
  const hitUrls = [];
  const fetchImpl = async (url) => {
    hitUrls.push(url);
    return { ok: true, json: async () => ({ text: 'Rendering Talos IV is unavailable offline; describing instead: a lush, illusion-filled world.' }) };
  };
  const { engine, client, bus } = await loadStack({ fetchImpl });

  const fallbacks = [];
  bus.on('route.fallback_used', (p) => fallbacks.push(p));

  const decision = engine.resolveButtonPress('btn_1', {
    text: 'Computer, show me an image of Talos Four',
  });
  assert.equal(decision.rule.route_to, 'models.image_generation');

  const response = await client.callRoute(decision.rule, { prompt: 'Talos Four' });

  assert.equal(hitUrls.length, 1);
  assert.equal(hitUrls[0], 'http://127.0.0.1:8080/v1/chat/completions'); // chat_vision's endpoint, not image_generation's
  assert.equal(fallbacks.length, 1);
  assert.match(response.text, /Talos IV/);
});

test('Sensor mode (btn_2) loop: repeated frames all route to vision_fast at the configured interval', async () => {
  const calls = [];
  const fetchImpl = async (url) => {
    calls.push(url);
    return { ok: true, json: async () => ({ text: 'There is a cat ahead.' }) };
  };
  const { engine, client } = await loadStack({ fetchImpl });

  const decision = engine.resolveButtonPress('btn_2');
  assert.equal(decision.rule.loop_interval_ms, 3500);

  // Simulate three frames of the sensor loop.
  for (let i = 0; i < 3; i += 1) {
    // eslint-disable-next-line no-await-in-loop
    await client.callRoute(decision.rule, { frame: i });
  }

  assert.equal(calls.length, 3);
  assert.ok(calls.every((u) => u === 'http://127.0.0.1:8081/v1/chat/completions'));
});

test('Sentry mode (btn_3): local motion handler runs with zero network calls until threshold is crossed', async () => {
  let networkCalls = 0;
  const fetchImpl = async () => { networkCalls += 1; return { ok: true, json: async () => ({}) }; };
  const { engine, client } = await loadStack({ fetchImpl });

  client.registerLocalHandler('sensor.motion_delta', async () => ({ pct_change: 4.0 }));

  const decision = engine.resolveButtonPress('btn_3');
  assert.equal(decision.rule.route_to, 'sensor.motion_delta');
  assert.equal(decision.rule.escalation_threshold_pct, 12.5);

  const motionReading = await client.callRoute(decision.rule, {});
  assert.equal(networkCalls, 0);

  const shouldEscalate = motionReading.pct_change >= decision.rule.escalation_threshold_pct;
  assert.equal(shouldEscalate, false); // 4.0% is under the 12.5% threshold — no VLM call yet
});

test('end-to-end with real payload shapes: "imagine Talos Four" falls back to a properly-reshaped chat body', async () => {
  const calls = [];
  const fetchImpl = async (url, opts) => {
    const body = JSON.parse(opts.body);
    calls.push({ url, body });
    return {
      ok: true,
      json: async () => ({
        choices: [{ message: { content: `Rendering unavailable offline; describing instead: ${body.messages[0].content}` } }],
      }),
    };
  };
  const { engine, client } = await loadStack({ fetchImpl });

  const decision = engine.resolveButtonPress('btn_1', {
    text: 'Computer, show me an image of Talos Four',
  });
  assert.equal(decision.rule.route_to, 'models.image_generation');

  const response = await client.callRouteWithContext(decision.rule, { text: 'Talos Four' });

  // Only one network call happened (the fallback), and it's shaped for
  // chat_vision (messages array), not for the images API it was originally
  // routed toward.
  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'http://127.0.0.1:8080/v1/chat/completions');
  assert.deepEqual(calls[0].body.messages, [{ role: 'user', content: 'Talos Four' }]);
  assert.match(response.choices[0].message.content, /Talos Four/);
});

test('emits mode.changed-worthy tuple events observable purely from the bus (UI never touches the engine directly)', async () => {
  const { engine, bus } = await loadStack({ fetchImpl: async () => ({ ok: true, json: async () => ({}) }) });

  const seenModes = [];
  bus.on(Events.TUPLE_RESOLVED, ({ tuple }) => seenModes.push(tuple.mode));

  engine.resolveButtonPress('btn_1', { text: 'hello' });
  engine.resolveButtonPress('btn_2');
  engine.resolveButtonPress('btn_3');

  assert.deepEqual(seenModes, ['CHATTING', 'SCANNING', 'GUARDING']);
});

test('full stack: Button 2 (Sensor) resolved rule drives a real scan loop end to end', async () => {
  let frameNumber = 0;
  const fetchImpl = async (url, opts) => {
    const body = JSON.parse(opts.body);
    const seenImage = body.messages[0].content.find((p) => p.type === 'image_url').image_url.url;
    return {
      ok: true,
      json: async () => ({ choices: [{ message: { content: `Frame ${seenImage}: there is a cat ahead.` } }] }),
    };
  };
  const { engine, client, bus } = await loadStack({ fetchImpl });
  const driver = new SensorLoopDriver(client, bus, {
    captureFrame: async () => `frame-${frameNumber += 1}`,
  });

  const decision = engine.resolveButtonPress('btn_2');
  assert.equal(decision.rule.route_to, 'models.vision_fast');
  assert.equal(decision.rule.loop_interval_ms, 3500);

  const descriptions = [];
  bus.on(Events.SENSOR_DESCRIPTION, (p) => descriptions.push(p.text));

  driver.start('btn_2', decision.rule, {}, { intervalMs: 10 });
  await new Promise((r) => setTimeout(r, 45));
  driver.stop('btn_2');

  assert.ok(descriptions.length >= 2, `expected multiple auto-refreshing descriptions, got ${descriptions.length}`);
  assert.ok(descriptions.every((d) => d.includes('there is a cat ahead')));
  // Each tick captured a genuinely new frame (frame-1, frame-2, ...) — this is the "auto-refresh" from the design doc.
  assert.ok(descriptions[0] !== descriptions[1]);
});

test('full stack: Button 3 (Sentry) stays local/no-op until motion crosses the configured threshold, then escalates once', async () => {
  const httpCalls = [];
  const fetchImpl = async (url, opts) => {
    httpCalls.push(url);
    return { ok: true, json: async () => ({ choices: [{ message: { content: 'Warning: motion detected in scanning sector.' } }] }) };
  };
  const { engine, client, bus } = await loadStack({ fetchImpl });

  // Local motion sensor: quiet for the first two ticks, then a spike.
  const pctSequence = [2.0, 3.5, 20.0];
  let i = 0;
  client.registerLocalHandler('sensor.motion_delta', async () => ({ pct_change: pctSequence[Math.min(i++, pctSequence.length - 1)] }));

  const decision = engine.resolveButtonPress('btn_3');
  assert.equal(decision.rule.route_to, 'sensor.motion_delta');
  assert.equal(decision.rule.motion_poll_interval_ms, 750);

  const driver = new SensorLoopDriver(client, bus, { captureFrame: async () => 'frame://sentry' });
  const alerts = [];
  bus.on(Events.ALERT_RAISED, (p) => alerts.push(p));

  driver.start('btn_3', decision.rule, {}, { intervalMs: 10 });
  await new Promise((r) => setTimeout(r, 45)); // enough ticks to reach the spike in pctSequence
  driver.stop('btn_3');

  assert.equal(httpCalls.length, alerts.length); // network only touched on escalation ticks
  assert.ok(alerts.length >= 1);
  assert.match(alerts[0].message, /motion detected/);
});

test('full stack: weather_alerts_noaa (real, enabled config entry) drives a live-shaped provider poll end to end', async () => {
  const { loader, bus } = await loadStack({ fetchImpl: async () => ({ ok: true, json: async () => ({ features: [] }) }) });
  const providerConfig = loader.getProvider('weather_alerts_noaa');
  assert.equal(providerConfig.enabled, true);

  const noaaFetchCalls = [];
  const noaaFetchImpl = async (url, opts) => {
    noaaFetchCalls.push({ url, headers: opts.headers });
    return {
      ok: true,
      json: async () => ({
        features: [
          {
            properties: {
              id: 'NWS-1', event: 'Frost Advisory', headline: 'Frost Advisory issued', severity: 'Minor',
              urgency: 'Expected', certainty: 'Likely', areaDesc: 'Orange County, NY',
              effective: '2026-08-29T18:00:00-04:00', expires: '2026-08-29T22:00:00-04:00',
            },
          },
          {
            properties: {
              id: 'NWS-2', event: 'Tornado Warning', headline: 'Tornado Warning issued for Orange County', severity: 'Extreme',
              urgency: 'Immediate', certainty: 'Observed', areaDesc: 'Orange County, NY',
              effective: '2026-08-29T18:05:00-04:00', expires: '2026-08-29T18:45:00-04:00',
            },
          },
        ],
      }),
    };
  };

  const poller = new ContextProviderPoller(bus);
  const providerData = [];
  const alerts = [];
  bus.on(Events.PROVIDER_DATA, (p) => providerData.push(p));
  bus.on(Events.ALERT_RAISED, (p) => alerts.push(p));

  poller.start('weather_alerts_noaa', providerConfig, { lat: 41.5034, lon: -74.0104 }, {
    intervalMs: 10_000, // one manual tick is enough to prove the wiring; no need to wait on a real poll cadence in a test
    fetchFn: (cfg, params) => fetchActiveAlerts(cfg, params, noaaFetchImpl),
    deriveAlerts: (data, cfg) => deriveSevereAlerts(data.alerts, cfg),
  });
  await new Promise((r) => setImmediate(r));
  poller.stop('weather_alerts_noaa');

  // Real User-Agent from config actually got sent — this is the exact
  // requirement NOAA's API enforces, and it's coming from config, not code.
  assert.equal(noaaFetchCalls.length, 1);
  assert.match(noaaFetchCalls[0].headers['User-Agent'], /ProjectTricorder/);
  assert.equal(noaaFetchCalls[0].url, 'https://api.weather.gov/alerts/active?point=41.5034,-74.0104');

  // Both alerts show up in the raw provider data...
  assert.equal(providerData.length, 1);
  assert.equal(providerData[0].data.alerts.length, 2);

  // ...but only the Extreme one (per config's alert_severities: ["Severe","Extreme"])
  // crosses into an actual alert.raised event — the Minor Frost Advisory does not.
  assert.equal(alerts.length, 1);
  assert.equal(alerts[0].severity, 'Extreme');
  assert.match(alerts[0].message, /Tornado Warning/);
});
