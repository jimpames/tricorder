import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventBus, Events } from '../src/eventBus.mjs';
import { ContextProviderPoller, ContextProviderPollerError } from '../src/contextProviderPoller.mjs';
import { deriveSevereAlerts } from '../src/providers/noaaWeatherAlerts.mjs';

test('start() requires a fetchFn', () => {
  const poller = new ContextProviderPoller(new EventBus());
  assert.throws(() => poller.start('weather_alerts_noaa', {}, {}, {}), ContextProviderPollerError);
});

test('start() fires an immediate fetch and emits provider.data', async () => {
  const bus = new EventBus();
  const poller = new ContextProviderPoller(bus);
  const events = [];
  bus.on(Events.PROVIDER_DATA, (p) => events.push(p));

  poller.start('weather_alerts_noaa', { poll_interval_s: 9999 }, { lat: 1, lon: 2 }, {
    fetchFn: async () => ({ alerts: [] }),
  });
  await new Promise((r) => setImmediate(r));

  assert.equal(events.length, 1);
  assert.equal(events[0].providerId, 'weather_alerts_noaa');
  poller.stop('weather_alerts_noaa');
});

test('a fetchFn error emits provider.error and does not kill the timer', async () => {
  const bus = new EventBus();
  const poller = new ContextProviderPoller(bus);
  const errors = [];
  bus.on(Events.PROVIDER_ERROR, (p) => errors.push(p));

  let attempt = 0;
  poller.start('weather_alerts_noaa', {}, {}, {
    intervalMs: 15,
    fetchFn: async () => {
      attempt += 1;
      if (attempt === 1) throw new Error('network hiccup');
      return { alerts: [] };
    },
  });

  await new Promise((r) => setTimeout(r, 40));
  poller.stop('weather_alerts_noaa');

  assert.ok(errors.length >= 1);
  assert.match(errors[0].error, /network hiccup/);
  assert.ok(attempt >= 2, 'poller should keep ticking after one failed attempt');
});

test('deriveAlerts, when provided, raises alert.raised only for alerts that pass the filter', async () => {
  const bus = new EventBus();
  const poller = new ContextProviderPoller(bus);
  const raised = [];
  bus.on(Events.ALERT_RAISED, (p) => raised.push(p));

  const noaaData = {
    alerts: [
      { severity: 'Minor', event: 'Frost Advisory', headline: 'Frost Advisory issued' },
      { severity: 'Extreme', event: 'Hurricane Warning', headline: 'Hurricane Warning issued' },
    ],
  };

  poller.start('weather_alerts_noaa', { alert_severities: ['Severe', 'Extreme'] }, { lat: 1, lon: 2 }, {
    intervalMs: 10_000,
    fetchFn: async () => noaaData,
    deriveAlerts: (data, providerConfig) => deriveSevereAlerts(data.alerts, providerConfig),
  });
  await new Promise((r) => setImmediate(r));
  poller.stop('weather_alerts_noaa');

  assert.equal(raised.length, 1);
  assert.equal(raised[0].severity, 'Extreme');
  assert.equal(raised[0].providerId, 'weather_alerts_noaa');
  assert.match(raised[0].message, /Hurricane Warning/);
});

test('no deriveAlerts means no alert.raised events, even with severe-looking data', async () => {
  const bus = new EventBus();
  const poller = new ContextProviderPoller(bus);
  const raised = [];
  bus.on(Events.ALERT_RAISED, (p) => raised.push(p));

  poller.start('weather_alerts_noaa', {}, {}, {
    intervalMs: 10_000,
    fetchFn: async () => ({ alerts: [{ severity: 'Extreme' }] }),
  });
  await new Promise((r) => setImmediate(r));
  poller.stop('weather_alerts_noaa');

  assert.equal(raised.length, 0);
});

test('stop() is idempotent / harmless on a poller that is not running', () => {
  const poller = new ContextProviderPoller(new EventBus());
  assert.equal(poller.stop('nope'), false);
});

test('starting an already-running providerId throws', () => {
  const poller = new ContextProviderPoller(new EventBus());
  poller.start('weather_alerts_noaa', {}, {}, { intervalMs: 10_000, fetchFn: async () => ({}) });
  assert.throws(
    () => poller.start('weather_alerts_noaa', {}, {}, { intervalMs: 10_000, fetchFn: async () => ({}) }),
    ContextProviderPollerError
  );
  poller.stop('weather_alerts_noaa');
});

test('isRunning / stopAll reflect and clear state for multiple providers', () => {
  const poller = new ContextProviderPoller(new EventBus());
  poller.start('weather_alerts_noaa', {}, {}, { intervalMs: 10_000, fetchFn: async () => ({}) });
  poller.start('flight_overhead', {}, {}, { intervalMs: 10_000, fetchFn: async () => ({}) });

  assert.equal(poller.isRunning('weather_alerts_noaa'), true);
  assert.equal(poller.isRunning('flight_overhead'), true);

  poller.stopAll();

  assert.equal(poller.isRunning('weather_alerts_noaa'), false);
  assert.equal(poller.isRunning('flight_overhead'), false);
});

test('poll_interval_s from providerConfig is honored when intervalMs is not explicitly overridden', async () => {
  const bus = new EventBus();
  const poller = new ContextProviderPoller(bus);
  let fetchCalls = 0;

  // poll_interval_s: 0.01 -> 10ms, close enough to assert multiple ticks quickly.
  poller.start('weather_alerts_noaa', { poll_interval_s: 0.01 }, {}, {
    fetchFn: async () => { fetchCalls += 1; return { alerts: [] }; },
  });
  await new Promise((r) => setTimeout(r, 45));
  poller.stop('weather_alerts_noaa');

  assert.ok(fetchCalls >= 2, `expected multiple ticks from poll_interval_s, got ${fetchCalls}`);
});
