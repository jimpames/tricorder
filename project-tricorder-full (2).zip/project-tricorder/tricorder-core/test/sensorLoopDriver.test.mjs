import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventBus, Events } from '../src/eventBus.mjs';
import { SensorLoopDriver, SensorLoopDriverError, extractResponseText } from '../src/sensorLoopDriver.mjs';

/** A minimal fake McpClient — just enough surface for the driver to call. */
function fakeClient(handler) {
  return { callRouteWithContext: handler };
}

test('constructor requires a captureFrame function', () => {
  assert.throws(() => new SensorLoopDriver({}, new EventBus(), {}), SensorLoopDriverError);
});

test('extractResponseText handles a plain string content field', () => {
  assert.equal(
    extractResponseText({ choices: [{ message: { content: 'There is a cat ahead.' } }] }),
    'There is a cat ahead.'
  );
});

test('extractResponseText handles multi-part vision-style content', () => {
  const response = {
    choices: [{ message: { content: [{ type: 'text', text: 'A cat.' }, { type: 'image_url', image_url: {} }] } }],
  };
  assert.equal(extractResponseText(response), 'A cat.');
});

test('extractResponseText falls back to a bare .text field', () => {
  assert.equal(extractResponseText({ text: 'fallback shape' }), 'fallback shape');
});

test('extractResponseText returns empty string for garbage input rather than throwing', () => {
  assert.equal(extractResponseText(null), '');
  assert.equal(extractResponseText({}), '');
  assert.equal(extractResponseText(undefined), '');
});

test('scan tick (no escalate_to): captures a frame, calls the route with it, emits frame + description', async () => {
  const bus = new EventBus();
  const calls = [];
  const client = fakeClient(async (rule, context) => {
    calls.push({ rule, context });
    return { choices: [{ message: { content: 'There is a cat ahead.' } }] };
  });
  const driver = new SensorLoopDriver(client, bus, { captureFrame: async () => 'frame://1' });

  const frameEvents = [];
  const descEvents = [];
  bus.on(Events.SENSOR_FRAME, (p) => frameEvents.push(p));
  bus.on(Events.SENSOR_DESCRIPTION, (p) => descEvents.push(p));

  const result = await driver.runOnce('btn_2', { route_to: 'models.vision_fast' });

  assert.equal(result.escalated, false);
  assert.equal(result.text, 'There is a cat ahead.');
  assert.equal(calls.length, 1);
  assert.deepEqual(calls[0].context.images, ['frame://1']);
  assert.equal(frameEvents.length, 1);
  assert.equal(descEvents.length, 1);
  assert.equal(descEvents[0].text, 'There is a cat ahead.');
});

test('guard tick under threshold: no frame captured, no escalation call, no alert', async () => {
  const bus = new EventBus();
  let captureCalls = 0;
  const routeCalls = [];
  const client = fakeClient(async (rule) => {
    routeCalls.push(rule.route_to);
    return { pct_change: 4.0 };
  });
  const driver = new SensorLoopDriver(client, bus, {
    captureFrame: async () => { captureCalls += 1; return 'frame://x'; },
  });

  const alerts = [];
  const readings = [];
  bus.on(Events.ALERT_RAISED, (p) => alerts.push(p));
  bus.on(Events.SENSOR_MOTION_READING, (p) => readings.push(p));

  const result = await driver.runOnce('btn_3', {
    route_to: 'sensor.motion_delta',
    escalate_to: 'models.vision_fast',
    escalation_threshold_pct: 12.5,
  });

  assert.equal(result.escalated, false);
  assert.equal(result.pct_change, 4.0);
  assert.equal(captureCalls, 0); // no frame needed — motion stayed under threshold
  assert.deepEqual(routeCalls, ['sensor.motion_delta']); // escalate_to never called
  assert.equal(alerts.length, 0);
  assert.equal(readings.length, 1);
  assert.equal(readings[0].pct_change, 4.0);
});

test('guard tick at/over threshold: captures a frame, escalates, raises an alert', async () => {
  const bus = new EventBus();
  let captureCalls = 0;
  const routeCalls = [];
  const client = fakeClient(async (rule) => {
    routeCalls.push(rule.route_to);
    if (rule.route_to === 'sensor.motion_delta') return { pct_change: 18.2 };
    if (rule.route_to === 'models.vision_fast') {
      return { choices: [{ message: { content: 'Warning: motion detected in scanning sector.' } }] };
    }
    throw new Error(`unexpected route in test: ${rule.route_to}`);
  });
  const driver = new SensorLoopDriver(client, bus, {
    captureFrame: async () => { captureCalls += 1; return 'frame://motion'; },
  });

  const alerts = [];
  bus.on(Events.ALERT_RAISED, (p) => alerts.push(p));

  const result = await driver.runOnce('btn_3', {
    route_to: 'sensor.motion_delta',
    escalate_to: 'models.vision_fast',
    escalation_threshold_pct: 12.5,
  });

  assert.equal(result.escalated, true);
  assert.equal(result.pct_change, 18.2);
  assert.equal(result.text, 'Warning: motion detected in scanning sector.');
  assert.equal(captureCalls, 1);
  assert.deepEqual(routeCalls, ['sensor.motion_delta', 'models.vision_fast']);
  assert.equal(alerts.length, 1);
  assert.equal(alerts[0].source, 'models.vision_fast');
  assert.match(alerts[0].message, /motion detected/);
});

test('a pct_change exactly at the threshold escalates (threshold is inclusive)', async () => {
  const bus = new EventBus();
  const client = fakeClient(async (rule) => (
    rule.route_to === 'sensor.motion_delta' ? { pct_change: 12.5 } : { choices: [{ message: { content: 'edge case' } }] }
  ));
  const driver = new SensorLoopDriver(client, bus, { captureFrame: async () => 'frame://edge' });

  const result = await driver.runOnce('btn_3', {
    route_to: 'sensor.motion_delta',
    escalate_to: 'models.vision_fast',
    escalation_threshold_pct: 12.5,
  });

  assert.equal(result.escalated, true);
});

test('start() fires an immediate tick without waiting a full interval', async () => {
  const bus = new EventBus();
  let calls = 0;
  const client = fakeClient(async () => { calls += 1; return { choices: [{ message: { content: 'x' } }] }; });
  const driver = new SensorLoopDriver(client, bus, { captureFrame: async () => 'frame://1' });

  driver.start('btn_2', { route_to: 'models.vision_fast', loop_interval_ms: 999_999 });
  // Give the immediately-fired async tick a chance to resolve before we assert.
  await new Promise((r) => setImmediate(r));

  assert.equal(calls, 1);
  driver.stop('btn_2');
});

test('start()/stop() lifecycle: repeats on interval, stop halts further ticks', async () => {
  const bus = new EventBus();
  let calls = 0;
  const client = fakeClient(async () => { calls += 1; return { choices: [{ message: { content: 'x' } }] }; });
  const driver = new SensorLoopDriver(client, bus, { captureFrame: async () => 'frame://1' });

  driver.start('btn_2', { route_to: 'models.vision_fast' }, {}, { intervalMs: 10 });
  await new Promise((r) => setTimeout(r, 45)); // immediate tick + ~4 interval ticks
  driver.stop('btn_2');
  const callsAtStop = calls;

  await new Promise((r) => setTimeout(r, 30)); // nothing more should happen after stop

  assert.ok(callsAtStop >= 2, `expected at least 2 ticks, got ${callsAtStop}`);
  assert.equal(calls, callsAtStop);
});

test('starting an already-running loopId throws', () => {
  const bus = new EventBus();
  const client = fakeClient(async () => ({}));
  const driver = new SensorLoopDriver(client, bus, { captureFrame: async () => 'f' });

  driver.start('btn_2', { route_to: 'models.vision_fast' }, {}, { intervalMs: 10_000 });
  assert.throws(() => driver.start('btn_2', { route_to: 'models.vision_fast' }, {}, { intervalMs: 10_000 }), SensorLoopDriverError);
  driver.stop('btn_2');
});

test('stop() on a loop that is not running returns false, not an error', () => {
  const driver = new SensorLoopDriver(fakeClient(async () => ({})), new EventBus(), { captureFrame: async () => 'f' });
  assert.equal(driver.stop('never_started'), false);
});

test('isRunning reflects start/stop state', () => {
  const driver = new SensorLoopDriver(fakeClient(async () => ({})), new EventBus(), { captureFrame: async () => 'f' });
  assert.equal(driver.isRunning('btn_2'), false);
  driver.start('btn_2', { route_to: 'models.vision_fast' }, {}, { intervalMs: 10_000 });
  assert.equal(driver.isRunning('btn_2'), true);
  driver.stop('btn_2');
  assert.equal(driver.isRunning('btn_2'), false);
});

test('stopAll halts every running loop', () => {
  const driver = new SensorLoopDriver(fakeClient(async () => ({})), new EventBus(), { captureFrame: async () => 'f' });
  driver.start('btn_2', { route_to: 'models.vision_fast' }, {}, { intervalMs: 10_000 });
  driver.start('btn_3', { route_to: 'sensor.motion_delta', escalate_to: 'models.vision_fast' }, {}, { intervalMs: 10_000 });

  driver.stopAll();

  assert.equal(driver.isRunning('btn_2'), false);
  assert.equal(driver.isRunning('btn_3'), false);
});

test('a route error during a tick emits sensor.loop_error and calls onError, without killing the timer', async () => {
  const bus = new EventBus();
  let attempt = 0;
  const client = fakeClient(async () => {
    attempt += 1;
    if (attempt === 1) throw new Error('backend hiccup');
    return { choices: [{ message: { content: 'recovered' } }] };
  });
  const driver = new SensorLoopDriver(client, bus, { captureFrame: async () => 'frame://1' });

  const errors = [];
  const onErrorCalls = [];
  bus.on(Events.SENSOR_LOOP_ERROR, (p) => errors.push(p));

  driver.start('btn_2', { route_to: 'models.vision_fast' }, {}, {
    intervalMs: 15,
    onError: (err) => onErrorCalls.push(err),
  });

  await new Promise((r) => setTimeout(r, 40));
  driver.stop('btn_2');

  assert.ok(errors.length >= 1);
  assert.match(errors[0].error, /backend hiccup/);
  assert.ok(onErrorCalls.length >= 1);
  assert.ok(attempt >= 2, 'loop should keep ticking after a single failed attempt');
});
