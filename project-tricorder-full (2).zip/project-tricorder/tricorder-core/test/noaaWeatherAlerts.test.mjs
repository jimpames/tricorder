import { test } from 'node:test';
import assert from 'node:assert/strict';
import { fetchActiveAlerts, deriveSevereAlerts, NoaaProviderError } from '../src/providers/noaaWeatherAlerts.mjs';

const PROVIDER_CONFIG = {
  endpoint: 'https://api.weather.gov/alerts/active',
  user_agent: 'ProjectTricorder/0.1 (contact: test@example.com)',
  alert_severities: ['Severe', 'Extreme'],
};

function sampleFeature(overrides = {}) {
  return {
    id: 'https://api.weather.gov/alerts/NWS-IDP-PROD-1',
    properties: {
      id: 'NWS-IDP-PROD-1',
      event: 'Severe Thunderstorm Warning',
      headline: 'Severe Thunderstorm Warning issued for Orange County',
      severity: 'Severe',
      urgency: 'Immediate',
      certainty: 'Observed',
      areaDesc: 'Orange County, NY',
      effective: '2026-08-29T18:00:00-04:00',
      expires: '2026-08-29T19:00:00-04:00',
      ...overrides,
    },
  };
}

test('fetchActiveAlerts builds a point-based URL and sends the configured User-Agent', async () => {
  const calls = [];
  const fetchImpl = async (url, opts) => {
    calls.push({ url, headers: opts.headers });
    return { ok: true, json: async () => ({ features: [] }) };
  };

  await fetchActiveAlerts(PROVIDER_CONFIG, { lat: 41.5, lon: -74.0 }, fetchImpl);

  assert.equal(calls.length, 1);
  assert.equal(calls[0].url, 'https://api.weather.gov/alerts/active?point=41.5,-74');
  assert.equal(calls[0].headers['User-Agent'], 'ProjectTricorder/0.1 (contact: test@example.com)');
  assert.equal(calls[0].headers.Accept, 'application/geo+json');
});

test('fetchActiveAlerts falls back to a generic User-Agent if none is configured, rather than sending none', async () => {
  const calls = [];
  const fetchImpl = async (url, opts) => { calls.push(opts.headers); return { ok: true, json: async () => ({ features: [] }) }; };

  await fetchActiveAlerts({ endpoint: 'https://api.weather.gov/alerts/active' }, { lat: 1, lon: 2 }, fetchImpl);

  assert.match(calls[0]['User-Agent'], /ProjectTricorder/);
});

test('fetchActiveAlerts throws without an endpoint configured', async () => {
  await assert.rejects(() => fetchActiveAlerts({}, { lat: 1, lon: 2 }, async () => ({})), NoaaProviderError);
});

test('fetchActiveAlerts throws without a valid location', async () => {
  await assert.rejects(
    () => fetchActiveAlerts(PROVIDER_CONFIG, {}, async () => ({ ok: true, json: async () => ({}) })),
    NoaaProviderError
  );
});

test('fetchActiveAlerts throws a clear error on a non-OK response', async () => {
  const fetchImpl = async () => ({ ok: false, status: 500 });
  await assert.rejects(
    () => fetchActiveAlerts(PROVIDER_CONFIG, { lat: 1, lon: 2 }, fetchImpl),
    /returned 500/
  );
});

test('fetchActiveAlerts normalizes GeoJSON features into flat alert objects', async () => {
  const fetchImpl = async () => ({
    ok: true,
    json: async () => ({ features: [sampleFeature()] }),
  });

  const { alerts } = await fetchActiveAlerts(PROVIDER_CONFIG, { lat: 1, lon: 2 }, fetchImpl);

  assert.equal(alerts.length, 1);
  assert.deepEqual(alerts[0], {
    id: 'NWS-IDP-PROD-1',
    event: 'Severe Thunderstorm Warning',
    headline: 'Severe Thunderstorm Warning issued for Orange County',
    severity: 'Severe',
    urgency: 'Immediate',
    certainty: 'Observed',
    areaDesc: 'Orange County, NY',
    effective: '2026-08-29T18:00:00-04:00',
    expires: '2026-08-29T19:00:00-04:00',
  });
});

test('fetchActiveAlerts returns an empty array (not an error) when there are no active alerts', async () => {
  const fetchImpl = async () => ({ ok: true, json: async () => ({ features: [] }) });
  const { alerts } = await fetchActiveAlerts(PROVIDER_CONFIG, { lat: 1, lon: 2 }, fetchImpl);
  assert.deepEqual(alerts, []);
});

test('fetchActiveAlerts tolerates a feature missing optional fields', async () => {
  const fetchImpl = async () => ({
    ok: true,
    json: async () => ({ features: [{ properties: {} }] }),
  });
  const { alerts } = await fetchActiveAlerts(PROVIDER_CONFIG, { lat: 1, lon: 2 }, fetchImpl);
  assert.equal(alerts[0].event, 'Unknown Event');
  assert.equal(alerts[0].severity, 'Unknown');
});

test('deriveSevereAlerts keeps only Severe/Extreme by default, dropping Minor/Moderate', () => {
  const alerts = [
    sampleFeature({ severity: 'Minor', event: 'Frost Advisory' }).properties,
    sampleFeature({ severity: 'Severe', event: 'Tornado Warning' }).properties,
    sampleFeature({ severity: 'Extreme', event: 'Hurricane Warning' }).properties,
  ].map((p) => ({ ...p, headline: p.headline }));

  const result = deriveSevereAlerts(alerts, {});
  assert.deepEqual(result.map((a) => a.severity).sort(), ['Extreme', 'Severe']);
  assert.ok(result.every((a) => a.source === 'weather_alerts_noaa'));
});

test('deriveSevereAlerts respects a custom alert_severities floor from config', () => {
  const alerts = [{ severity: 'Moderate', event: 'Flood Watch', headline: 'Flood Watch' }];
  const result = deriveSevereAlerts(alerts, { alert_severities: ['Moderate', 'Severe', 'Extreme'] });
  assert.equal(result.length, 1);
});

test('deriveSevereAlerts returns an empty array when nothing meets the floor', () => {
  const alerts = [{ severity: 'Minor', event: 'Frost Advisory', headline: 'Frost Advisory' }];
  assert.deepEqual(deriveSevereAlerts(alerts, {}), []);
});
