import { test } from 'node:test';
import assert from 'node:assert/strict';
import { buildPayload, registerProtocol, Protocols, UnknownProtocolError } from '../src/payloadBuilder.mjs';

test('openai_chat builds a simple single-turn messages array', () => {
  const target = { id: 'gemma-4-e2b', protocol: Protocols.OPENAI_CHAT };
  const payload = buildPayload(target, { text: 'What time is it?' });

  assert.deepEqual(payload, {
    model: 'gemma-4-e2b',
    messages: [{ role: 'user', content: 'What time is it?' }],
    stream: false,
  });
});

test('openai_chat includes a system message when provided', () => {
  const target = { id: 'gemma-4-e2b', protocol: Protocols.OPENAI_CHAT };
  const payload = buildPayload(target, {
    text: 'Hello',
    systemPrompt: 'You are a Star Trek tricorder computer.',
  });

  assert.equal(payload.messages.length, 2);
  assert.equal(payload.messages[0].role, 'system');
  assert.equal(payload.messages[1].role, 'user');
});

test('openai_chat_vision uses a plain string body when there are no images', () => {
  const target = { id: 'gemma-4-e2b', protocol: Protocols.OPENAI_CHAT_VISION };
  const payload = buildPayload(target, { text: 'distance to Alpha Centauri' });

  assert.equal(payload.messages[0].content, 'distance to Alpha Centauri');
});

test('openai_chat_vision builds multi-part content when images are present', () => {
  const target = { id: 'smolvlm2-500m-video-instruct', protocol: Protocols.OPENAI_CHAT_VISION };
  const payload = buildPayload(target, {
    text: 'Describe this scene.',
    images: ['data:image/jpeg;base64,AAAA'],
  });

  const content = payload.messages[0].content;
  assert.equal(Array.isArray(content), true);
  assert.deepEqual(content[0], { type: 'text', text: 'Describe this scene.' });
  assert.deepEqual(content[1], { type: 'image_url', image_url: { url: 'data:image/jpeg;base64,AAAA' } });
});

test('openai_chat_vision supports multiple images', () => {
  const target = { id: 'gemma-4-e2b', protocol: Protocols.OPENAI_CHAT_VISION };
  const payload = buildPayload(target, {
    text: 'Compare these.',
    images: ['img://a', 'img://b'],
  });

  const imageParts = payload.messages[0].content.filter((p) => p.type === 'image_url');
  assert.equal(imageParts.length, 2);
});

test('openai_images builds a prompt-based body with sensible defaults', () => {
  const target = { id: 'sd-turbo-mobile-q4', protocol: Protocols.OPENAI_IMAGES };
  const payload = buildPayload(target, { text: 'Talos Four, alien illusion world' });

  assert.deepEqual(payload, {
    model: 'sd-turbo-mobile-q4',
    prompt: 'Talos Four, alien illusion world',
    n: 1,
    size: '512x512',
  });
});

test('openai_images respects an explicit n/size and a target default_size', () => {
  const target = { id: 'sd-turbo-mobile-q4', protocol: Protocols.OPENAI_IMAGES, default_size: '768x768' };

  const usesTargetDefault = buildPayload(target, { text: 'a cat' });
  assert.equal(usesTargetDefault.size, '768x768');

  const usesExplicit = buildPayload(target, { text: 'a cat', n: 4, size: '256x256' });
  assert.equal(usesExplicit.n, 4);
  assert.equal(usesExplicit.size, '256x256');
});

test('openai_audio_speech falls back from context voice, to target voice, to "default"', () => {
  const target = { id: 'kokoro-82m', protocol: Protocols.OPENAI_AUDIO_SPEECH, voice: 'computer_female_measured' };

  const withContextVoice = buildPayload(target, { text: 'Processing.', voice: 'alt_voice' });
  assert.equal(withContextVoice.voice, 'alt_voice');

  const withTargetVoice = buildPayload(target, { text: 'Processing.' });
  assert.equal(withTargetVoice.voice, 'computer_female_measured');

  const withNeither = buildPayload({ id: 'x', protocol: Protocols.OPENAI_AUDIO_SPEECH }, { text: 'hi' });
  assert.equal(withNeither.voice, 'default');
});

test('openai_audio_transcription builds a file+format body', () => {
  const target = { id: 'whisper-tiny-en', protocol: Protocols.OPENAI_AUDIO_TRANSCRIPTION };
  const payload = buildPayload(target, { audioBase64: 'AAAA==' });

  assert.deepEqual(payload, { model: 'whisper-tiny-en', file: 'AAAA==', response_format: 'json' });
});

test('raw protocol passes the context through untouched', () => {
  const target = { id: 'anything', protocol: Protocols.RAW };
  const context = { whatever: 'shape', nested: { a: 1 } };
  assert.deepEqual(buildPayload(target, context), context);
});

test('a target with no protocol at all defaults to raw pass-through', () => {
  const target = { id: 'legacy' };
  const context = { some: 'thing' };
  assert.deepEqual(buildPayload(target, context), context);
});

test('an unrecognized protocol throws UnknownProtocolError with the offending name', () => {
  const target = { id: 'x', protocol: 'carrier_pigeon' };
  assert.throws(() => buildPayload(target, {}), (err) => {
    assert.ok(err instanceof UnknownProtocolError);
    assert.match(err.message, /carrier_pigeon/);
    return true;
  });
});

test('registerProtocol adds a new builder at runtime without touching this file again', () => {
  registerProtocol('shout', (target, context) => ({ SHOUTING: (context.text ?? '').toUpperCase() }));
  const payload = buildPayload({ id: 'x', protocol: 'shout' }, { text: 'red alert' });
  assert.deepEqual(payload, { SHOUTING: 'RED ALERT' });
});
