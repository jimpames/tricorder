import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ConfigLoader, validateConfig, ConfigValidationError } from '../src/configLoader.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = path.join(__dirname, '..', 'config', 'tricorder.config.json');

test('loads the reference config with no validation issues', async () => {
  const loader = new ConfigLoader(CONFIG_PATH);
  const config = await loader.load();

  assert.equal(config.config_version, '0.1');
  assert.ok(config.models.chat_vision);
  assert.equal(loader.current, config);
});

test('validateConfig flags a missing top-level key', () => {
  const issues = validateConfig({ config_version: '0.1' });
  assert.ok(issues.some((i) => i.includes('models')));
  assert.ok(issues.some((i) => i.includes('controls')));
});

test('validateConfig flags a button with a malformed tuple_seed', () => {
  const issues = validateConfig({
    config_version: '0.1',
    models: {},
    controls: { buttons: [{ id: 'btn_1', tuple_seed: ['ONLY_ONE'] }] },
    tuple_rules: [],
    context_providers: {},
  });
  assert.ok(issues.some((i) => i.includes('btn_1') && i.includes('tuple_seed')));
});

test('validateConfig flags a provider missing "enabled"', () => {
  const issues = validateConfig({
    config_version: '0.1',
    models: {},
    controls: { buttons: [] },
    tuple_rules: [],
    context_providers: { weather: { requires_network: true } },
  });
  assert.ok(issues.some((i) => i.includes('weather') && i.includes('enabled')));
});

test('getModel throws a clear error for an unconfigured id', async () => {
  const loader = new ConfigLoader(CONFIG_PATH);
  await loader.load();
  assert.throws(() => loader.getModel('nonexistent'), /No model configured/);
});

test('enabledProviders only returns providers with enabled: true', async () => {
  const loader = new ConfigLoader(CONFIG_PATH);
  await loader.load();
  const enabledIds = loader.enabledProviders().map(([id]) => id);
  assert.deepEqual(enabledIds.sort(), ['clock_env', 'geolocation', 'weather_alerts_noaa']);
});
