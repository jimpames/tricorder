import { test } from 'node:test';
import assert from 'node:assert/strict';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { ConfigLoader } from '../src/configLoader.mjs';
import { EventBus, Events } from '../src/eventBus.mjs';
import {
  TupleEngine,
  tupleFromSeed,
  matchesRule,
  applyKeywordHints,
} from '../src/tupleEngine.mjs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CONFIG_PATH = path.join(__dirname, '..', 'config', 'tricorder.config.json');

async function loadEngine() {
  const bus = new EventBus();
  const loader = new ConfigLoader(CONFIG_PATH, bus);
  await loader.load();
  return { engine: new TupleEngine(loader, bus), bus, loader };
}

test('tupleFromSeed maps seed array to named fields in order', () => {
  const tuple = tupleFromSeed(['CHATTING', 'AUDIO_IN', 'TEXT', 'TOGGLE']);
  assert.deepEqual(tuple, {
    mode: 'CHATTING',
    inputChannel: 'AUDIO_IN',
    targetModality: 'TEXT',
    action: 'TOGGLE',
  });
});

test('matchesRule treats "*" as a wildcard', () => {
  const tuple = tupleFromSeed(['CHATTING', 'AUDIO_IN', 'IMAGE_GEN', 'EXECUTE']);
  assert.equal(matchesRule({ mode: 'CHATTING', target_hint: '*' }, tuple), true);
  assert.equal(matchesRule({ mode: 'GUARDING' }, tuple), false);
});

test('matchesRule ignores match keys it does not recognize instead of crashing', () => {
  const tuple = tupleFromSeed(['CHATTING', 'AUDIO_IN', 'TEXT', 'TOGGLE']);
  assert.equal(matchesRule({ some_future_field: 'whatever' }, tuple), true);
});

test('applyKeywordHints overrides targetModality when text matches a configured keyword', () => {
  const base = tupleFromSeed(['CHATTING', 'AUDIO_IN', 'TEXT', 'TOGGLE']);
  const hints = { IMAGE_GEN: ['imagine', 'draw me'] };

  const result = applyKeywordHints(base, 'Computer, imagine a sunset over Vulcan', hints);
  assert.equal(result.targetModality, 'IMAGE_GEN');
});

test('applyKeywordHints leaves the tuple untouched when nothing matches', () => {
  const base = tupleFromSeed(['CHATTING', 'AUDIO_IN', 'TEXT', 'TOGGLE']);
  const result = applyKeywordHints(base, 'What is the distance to Alpha Centauri?', {
    IMAGE_GEN: ['imagine', 'draw me'],
  });
  assert.equal(result.targetModality, 'TEXT');
});

test('button 1 (Inquiry), plain question, routes to chat_vision', async () => {
  const { engine } = await loadEngine();
  const result = engine.resolveButtonPress('btn_1', {
    text: 'What is the distance from Earth to Alpha Centauri?',
  });

  assert.ok(result);
  assert.equal(result.rule.route_to, 'models.chat_vision');
});

test('button 1 (Inquiry), "imagine" phrasing, routes to image_generation with a fallback', async () => {
  const { engine } = await loadEngine();
  const result = engine.resolveButtonPress('btn_1', {
    text: 'Computer, show me an image of Talos Four',
  });

  assert.ok(result);
  assert.equal(result.rule.route_to, 'models.image_generation');
  assert.equal(result.rule.fallback, 'models.chat_vision');
});

test('button 2 (Sensor) routes to the fast vision model with a loop interval', async () => {
  const { engine } = await loadEngine();
  const result = engine.resolveButtonPress('btn_2');

  assert.ok(result);
  assert.equal(result.rule.route_to, 'models.vision_fast');
  assert.equal(result.rule.loop_interval_ms, 3500);
});

test('button 3 (Sentry) routes to local motion sensing with an escalation path', async () => {
  const { engine } = await loadEngine();
  const result = engine.resolveButtonPress('btn_3');

  assert.ok(result);
  assert.equal(result.rule.route_to, 'sensor.motion_delta');
  assert.equal(result.rule.escalate_to, 'models.vision_fast');
  assert.equal(result.rule.escalation_threshold_pct, 12.5);
});

test('resolving an unknown button throws', async () => {
  const { engine } = await loadEngine();
  assert.throws(() => engine.resolveButtonPress('btn_nonexistent'), /No button configured/);
});

test('emits tuple.resolved with both the tuple and the winning rule', async () => {
  const { engine, bus } = await loadEngine();
  const events = [];
  bus.on(Events.TUPLE_RESOLVED, (payload) => events.push(payload));

  engine.resolveButtonPress('btn_2');

  assert.equal(events.length, 1);
  assert.equal(events[0].tuple.mode, 'SCANNING');
  assert.equal(events[0].rule.route_to, 'models.vision_fast');
});

test('emits tuple.unresolved when no rule matches', async () => {
  const { engine, bus, loader } = await loadEngine();
  // Inject a mode no rule covers, without touching the on-disk config.
  loader.current.controls.buttons.push({
    id: 'btn_ghost',
    tuple_seed: ['UNKNOWN_MODE', 'TEXT', 'TEXT', 'EXECUTE'],
  });

  const events = [];
  bus.on(Events.TUPLE_UNRESOLVED, (payload) => events.push(payload));

  const result = engine.resolveButtonPress('btn_ghost');

  assert.equal(result, null);
  assert.equal(events.length, 1);
  assert.equal(events[0].tuple.mode, 'UNKNOWN_MODE');
});
