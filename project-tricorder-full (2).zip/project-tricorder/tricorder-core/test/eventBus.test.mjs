import { test } from 'node:test';
import assert from 'node:assert/strict';
import { EventBus, Events } from '../src/eventBus.mjs';

test('emits to a specific subscriber', () => {
  const bus = new EventBus();
  const received = [];
  bus.on(Events.BUTTON_PRESS, (payload) => received.push(payload));

  bus.emit(Events.BUTTON_PRESS, { buttonId: 'btn_1' });

  assert.deepEqual(received, [{ buttonId: 'btn_1' }]);
});

test('does not call handlers for other event names', () => {
  const bus = new EventBus();
  let called = false;
  bus.on(Events.BUTTON_PRESS, () => { called = true; });

  bus.emit(Events.SENSOR_FRAME, {});

  assert.equal(called, false);
});

test('onAny receives every event with its name', () => {
  const bus = new EventBus();
  const seen = [];
  bus.onAny((name, payload) => seen.push([name, payload]));

  bus.emit('a', { x: 1 });
  bus.emit('b', { y: 2 });

  assert.deepEqual(seen, [['a', { x: 1 }], ['b', { y: 2 }]]);
});

test('unsubscribe stops future delivery', () => {
  const bus = new EventBus();
  let count = 0;
  const unsubscribe = bus.on('x', () => { count += 1; });

  bus.emit('x');
  unsubscribe();
  bus.emit('x');

  assert.equal(count, 1);
});

test('history respects the configured limit', () => {
  const bus = new EventBus({ historyLimit: 3 });
  for (let i = 0; i < 5; i += 1) bus.emit('tick', { i });

  const history = bus.getHistory();
  assert.equal(history.length, 3);
  assert.deepEqual(history.map((h) => h.payload.i), [2, 3, 4]);
});
