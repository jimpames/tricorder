/**
 * ConfigLoader — loads, validates, and hot-reloads the single config document
 * that drives everything (§3 of the design doc). No app logic ever hardcodes
 * a model id, an endpoint, a button meaning, or a provider — it all comes
 * through here.
 */

import { readFile, watch } from 'node:fs/promises';
import { EventBus } from './eventBus.mjs';

/** Fields we require to exist so a malformed config fails loudly, not silently. */
const REQUIRED_TOP_LEVEL_KEYS = ['config_version', 'models', 'controls', 'tuple_rules', 'context_providers'];

export class ConfigValidationError extends Error {
  constructor(issues) {
    super(`Config validation failed:\n - ${issues.join('\n - ')}`);
    this.issues = issues;
  }
}

/**
 * Validate the shape of a config object. Intentionally lightweight (no
 * external schema library dependency) — it checks the things that would
 * otherwise fail confusingly deep inside the tuple engine or MCP client.
 * @param {any} config
 * @returns {string[]} list of human-readable issues, empty if valid
 */
export function validateConfig(config) {
  const issues = [];

  if (typeof config !== 'object' || config === null) {
    return ['config is not an object'];
  }

  for (const key of REQUIRED_TOP_LEVEL_KEYS) {
    if (!(key in config)) issues.push(`missing top-level key "${key}"`);
  }

  if (config.models) {
    for (const [id, model] of Object.entries(config.models)) {
      if (model.endpoint && !model.protocol) {
        issues.push(
          `models.${id} has an "endpoint" but no "protocol" — payloadBuilder won't know how to shape requests to it`
        );
      }
    }
  }

  if (config.controls?.buttons) {
    for (const [i, btn] of config.controls.buttons.entries()) {
      if (!btn.id) issues.push(`controls.buttons[${i}] missing "id"`);
      if (!Array.isArray(btn.tuple_seed) || btn.tuple_seed.length !== 4) {
        issues.push(`controls.buttons[${i}] ("${btn.id ?? '?'}") tuple_seed must be a 4-element array`);
      }
    }
  }

  if (Array.isArray(config.tuple_rules)) {
    for (const [i, rule] of config.tuple_rules.entries()) {
      if (!rule.match || typeof rule.match !== 'object') {
        issues.push(`tuple_rules[${i}] missing "match" object`);
      }
      if (!rule.route_to) {
        issues.push(`tuple_rules[${i}] missing "route_to"`);
      }
    }
  }

  if (config.context_providers) {
    for (const [id, provider] of Object.entries(config.context_providers)) {
      if (typeof provider.enabled !== 'boolean') {
        issues.push(`context_providers.${id} missing boolean "enabled"`);
      }
      if (provider.enabled && provider.requires_network && !provider.endpoint && !provider.source) {
        issues.push(`context_providers.${id} is enabled and needs network but has no "endpoint"/"source"`);
      }
    }
  }

  return issues;
}

export class ConfigLoader {
  #path;
  #config = null;
  #bus;
  #watcher = null;

  /**
   * @param {string} path path to the JSON config file
   * @param {EventBus} [bus] optional bus to emit `config.reloaded` / `config.error` on
   */
  constructor(path, bus = new EventBus()) {
    this.#path = path;
    this.#bus = bus;
  }

  get current() {
    return this.#config;
  }

  get bus() {
    return this.#bus;
  }

  async load() {
    const raw = await readFile(this.#path, 'utf-8');
    const parsed = JSON.parse(raw);
    const issues = validateConfig(parsed);
    if (issues.length) throw new ConfigValidationError(issues);
    this.#config = parsed;
    this.#bus.emit('config.reloaded', { config: parsed });
    return parsed;
  }

  /**
   * Watch the config file and reload on change. Bad edits are reported via
   * `config.error` on the bus instead of crashing the running app — you can
   * keep chatting with the tricorder while you fix a typo in settings.
   */
  async watchForChanges() {
    if (this.#watcher) return;
    this.#watcher = (async () => {
      const ac = new AbortController();
      this._abort = () => ac.abort();
      try {
        const watcher = watch(this.#path, { signal: ac.signal });
        for await (const event of watcher) {
          if (event.eventType !== 'change') continue;
          try {
            await this.load();
          } catch (err) {
            this.#bus.emit('config.error', { error: String(err?.message ?? err) });
          }
        }
      } catch (err) {
        if (err?.name !== 'AbortError') throw err;
      }
    })();
  }

  stopWatching() {
    this._abort?.();
  }

  /** Convenience accessor: `getModel('chat_vision')` */
  getModel(id) {
    const model = this.#config?.models?.[id];
    if (!model) throw new Error(`No model configured with id "${id}"`);
    return model;
  }

  /** Convenience accessor: `getProvider('flight_overhead')` */
  getProvider(id) {
    const provider = this.#config?.context_providers?.[id];
    if (!provider) throw new Error(`No context provider configured with id "${id}"`);
    return provider;
  }

  /** All providers currently enabled, as [id, config] pairs. */
  enabledProviders() {
    return Object.entries(this.#config?.context_providers ?? {}).filter(([, p]) => p.enabled);
  }
}
