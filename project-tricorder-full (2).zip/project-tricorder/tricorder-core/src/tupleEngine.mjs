/**
 * TupleEngine — deterministic intent routing (§4 of the design doc).
 *
 * I = (Mode, InputChannel, TargetModality, Action)
 *
 * This deliberately does NOT call an LLM to figure out what a button press
 * or utterance means. It's a cheap, offline-safe, fully auditable router:
 * read the config, know exactly what every input does. The LLM only gets
 * invoked once the *route* has already been decided.
 *
 * Every rule, every keyword hint, every button mapping comes from config.
 * This file contains zero domain-specific literals ("Gemma", "sentry",
 * "IMAGE_GEN") outside of a couple of built-in wildcard/field-name constants
 * needed to make the matcher work at all.
 */

import { Events } from './eventBus.mjs';

/** Maps rule.match keys (config-facing names) to tuple field names. */
const MATCH_KEY_TO_TUPLE_FIELD = {
  mode: 'mode',
  input_channel: 'inputChannel',
  target_hint: 'targetModality',
  action: 'action',
};

const WILDCARD = '*';

/** @typedef {{ mode: string, inputChannel: string, targetModality: string, action: string }} Tuple */

/**
 * Build a tuple from a button's configured `tuple_seed` ([mode, inputChannel, targetModality, action]).
 * @param {string[]} seed
 * @returns {Tuple}
 */
export function tupleFromSeed(seed) {
  const [mode, inputChannel, targetModality, action] = seed;
  return { mode, inputChannel, targetModality, action };
}

/**
 * Does a single rule.match object match a given tuple?
 * `"*"` in a match field means "matches anything, including a differing tuple value."
 * A field simply absent from `match` is not checked at all (also matches anything).
 * @param {Record<string, string>} match
 * @param {Tuple} tuple
 */
export function matchesRule(match, tuple) {
  for (const [matchKey, expected] of Object.entries(match)) {
    const tupleField = MATCH_KEY_TO_TUPLE_FIELD[matchKey];
    if (!tupleField) continue; // unknown match key — ignore rather than crash
    if (expected === WILDCARD) continue;
    if (tuple[tupleField] !== expected) return false;
  }
  return true;
}

/**
 * Pick the first matching rule from a config's `tuple_rules` list, in order.
 * @param {Array<{match: object, [k: string]: any}>} rules
 * @param {Tuple} tuple
 */
export function resolveRule(rules, tuple) {
  return rules.find((rule) => matchesRule(rule.match ?? {}, tuple)) ?? null;
}

/**
 * Apply keyword-based target-modality overrides to a tuple, using the
 * config's `intent_keyword_hints` map (e.g. `{ "IMAGE_GEN": ["imagine", "draw me"] }`).
 * This is how "Computer, imagine a sunset" gets its targetModality bumped
 * from the button's default (say, TEXT) to IMAGE_GEN — via config, not an if-chain.
 *
 * @param {Tuple} tuple
 * @param {string} text free-text input (transcript or typed text), case-insensitive match
 * @param {Record<string, string[]>} [keywordHints]
 * @returns {Tuple} a new tuple, possibly with targetModality overridden
 */
export function applyKeywordHints(tuple, text, keywordHints = {}) {
  if (!text) return tuple;
  const lower = text.toLowerCase();
  for (const [modality, keywords] of Object.entries(keywordHints)) {
    if (keywords.some((kw) => lower.includes(kw.toLowerCase()))) {
      return { ...tuple, targetModality: modality };
    }
  }
  return tuple;
}

export class TupleEngine {
  #configLoader;
  #bus;

  /**
   * @param {import('./configLoader.mjs').ConfigLoader} configLoader
   * @param {import('./eventBus.mjs').EventBus} bus
   */
  constructor(configLoader, bus) {
    this.#configLoader = configLoader;
    this.#bus = bus;
  }

  #config() {
    const config = this.#configLoader.current;
    if (!config) throw new Error('TupleEngine used before config was loaded');
    return config;
  }

  /**
   * Resolve a button press into a tuple + route decision.
   * @param {string} buttonId
   * @param {{ text?: string }} [context] free text (e.g. STT transcript) to run keyword hints against
   */
  resolveButtonPress(buttonId, context = {}) {
    const config = this.#config();
    const button = config.controls?.buttons?.find((b) => b.id === buttonId);
    if (!button) {
      throw new Error(`No button configured with id "${buttonId}"`);
    }

    this.#bus.emit(Events.BUTTON_PRESS, { buttonId });

    let tuple = tupleFromSeed(button.tuple_seed);
    tuple = applyKeywordHints(tuple, context.text, config.intent_keyword_hints);

    return this.#resolveTuple(tuple);
  }

  /**
   * Resolve an already-built tuple (e.g. from a provider-triggered event,
   * not a button) into a route decision.
   * @param {Tuple} tuple
   */
  #resolveTuple(tuple) {
    const config = this.#config();
    const rule = resolveRule(config.tuple_rules ?? [], tuple);

    if (!rule) {
      this.#bus.emit(Events.TUPLE_UNRESOLVED, { tuple });
      return null;
    }

    this.#bus.emit(Events.TUPLE_RESOLVED, { tuple, rule });
    return { tuple, rule };
  }

  /** Public entry point for resolving a manually constructed tuple (testing, providers, etc). */
  resolveTuple(tuple) {
    return this.#resolveTuple(tuple);
  }
}
