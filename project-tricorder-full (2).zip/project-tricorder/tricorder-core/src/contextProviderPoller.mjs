/**
 * ContextProviderPoller — the provider-side sibling of SensorLoopDriver.
 *
 * Where SensorLoopDriver turns a tuple-engine rule into a repeating
 * capture-and-call loop, this turns a `context_providers.*` config entry
 * into a repeating fetch-and-normalize loop. Same shape deliberately: a
 * generic timer wrapper around one injected async function, emitting
 * events on success/failure, start/stop/isRunning/stopAll.
 *
 * The point of pulling this out as its own generic class (rather than
 * writing a one-off poller inside noaaWeatherAlerts.mjs) is that the next
 * context provider — flight_overhead, crime_safety_citizen, whatever comes
 * after — reuses this exact class. Only `fetchFn` (and optionally
 * `deriveAlerts`) changes per provider; nothing here mentions NOAA.
 */

import { Events } from './eventBus.mjs';

export class ContextProviderPollerError extends Error {}

export class ContextProviderPoller {
  #bus;
  /** @type {Map<string, { handle: any, clearIntervalFn: (h: any) => void }>} */
  #timers = new Map();

  /** @param {import('./eventBus.mjs').EventBus} bus */
  constructor(bus) {
    this.#bus = bus;
  }

  /**
   * @param {string} providerId e.g. "weather_alerts_noaa" — matches the config key
   * @param {{ poll_interval_s?: number, [k: string]: any }} providerConfig
   * @param {any} params provider-specific fetch params (e.g. `{ lat, lon }`)
   * @param {{
   *   fetchFn: (providerConfig: any, params: any) => Promise<any>,
   *   deriveAlerts?: (data: any, providerConfig: any) => Array<{ severity: string, message: string, source: string, [k: string]: any }>,
   *   intervalMs?: number,
   *   onData?: (data: any) => void,
   *   onError?: (err: Error) => void,
   *   timerImpl?: { setInterval: typeof setInterval, clearInterval: typeof clearInterval },
   * }} opts
   */
  start(providerId, providerConfig, params, opts) {
    if (!opts?.fetchFn) {
      throw new ContextProviderPollerError(`start("${providerId}", ...) requires opts.fetchFn`);
    }
    if (this.#timers.has(providerId)) {
      throw new ContextProviderPollerError(`Provider poller "${providerId}" is already running`);
    }

    const intervalMs = opts.intervalMs ?? (providerConfig.poll_interval_s ?? 300) * 1000;
    const setIntervalFn = opts.timerImpl?.setInterval ?? setInterval;
    const clearIntervalFn = opts.timerImpl?.clearInterval ?? clearInterval;

    const tick = async () => {
      try {
        const data = await opts.fetchFn(providerConfig, params);
        this.#bus.emit(Events.PROVIDER_DATA, { providerId, data });
        opts.onData?.(data);

        if (opts.deriveAlerts) {
          const alerts = opts.deriveAlerts(data, providerConfig) ?? [];
          for (const alert of alerts) {
            this.#bus.emit(Events.ALERT_RAISED, { providerId, ...alert });
          }
        }
      } catch (err) {
        this.#bus.emit(Events.PROVIDER_ERROR, { providerId, error: String(err?.message ?? err) });
        opts.onError?.(err);
      }
    };

    const handle = setIntervalFn(tick, intervalMs);
    this.#timers.set(providerId, { handle, clearIntervalFn });
    this.#bus.emit('provider.poll_started', { providerId, intervalMs });

    tick(); // immediate first fetch, don't make the UI wait a full interval
  }

  /** @param {string} providerId */
  isRunning(providerId) {
    return this.#timers.has(providerId);
  }

  /** @param {string} providerId */
  stop(providerId) {
    const entry = this.#timers.get(providerId);
    if (!entry) return false;
    entry.clearIntervalFn(entry.handle);
    this.#timers.delete(providerId);
    this.#bus.emit('provider.poll_stopped', { providerId });
    return true;
  }

  stopAll() {
    for (const providerId of [...this.#timers.keys()]) this.stop(providerId);
  }
}
