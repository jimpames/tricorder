/**
 * SensorLoopDriver — the thing that actually makes Button 2 (Sensor) and
 * Button 3 (Sentry) do something continuous, per §7 of the design doc.
 *
 * It knows nothing about cameras, Android, or React Native — frame capture
 * is injected as a `captureFrame` function. On a real device that's a
 * camera hook; in tests (and here) it's whatever the caller provides. This
 * keeps the loop logic itself fully unit-testable without a device.
 *
 * Two loop shapes, both driven entirely by the *shape of the rule* coming
 * out of TupleEngine — nothing here hardcodes "SCANNING" or "GUARDING":
 *
 *  - A rule with `escalate_to` is a **guard loop**: poll a (usually local,
 *    cheap) route on an interval; only capture a frame and call the
 *    escalation route once a reading crosses `escalation_threshold_pct`.
 *    This is what keeps Sentry mode from hammering the vision model (or
 *    the network) every tick — exactly the "stops passing frames to the
 *    heavy VLM to save battery" behavior from the original brainstorm.
 *
 *  - Any other rule with an interval configured is a **scan loop**: capture
 *    a frame and call the route every tick, unconditionally. This is
 *    Button 2's "describe what the camera sees, continuously" behavior.
 */

import { Events } from './eventBus.mjs';

/**
 * Pull human-readable text out of whatever shape a backend responded with.
 * Tolerant of OpenAI chat completions (string or multi-part content), a
 * bare `{ text }` shape, or anything else — falls back to an empty string
 * rather than throwing, since a malformed response shouldn't crash a loop
 * that's supposed to keep running.
 * @param {any} response
 */
export function extractResponseText(response) {
  const content = response?.choices?.[0]?.message?.content;
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content
      .filter((part) => part?.type === 'text')
      .map((part) => part.text)
      .join(' ');
  }
  if (typeof response?.text === 'string') return response.text;
  return '';
}

export class SensorLoopDriverError extends Error {}

export class SensorLoopDriver {
  #client;
  #bus;
  #captureFrame;
  /** @type {Map<string, { handle: any, clearIntervalFn: (h: any) => void }>} */
  #timers = new Map();

  /**
   * @param {import('./mcpClient.mjs').McpClient} client
   * @param {import('./eventBus.mjs').EventBus} bus
   * @param {{ captureFrame: () => Promise<string> }} opts
   *   `captureFrame` returns a single frame as a data: URL (or whatever
   *   string shape the configured vision protocol's `images` expects).
   */
  constructor(client, bus, opts = {}) {
    if (typeof opts.captureFrame !== 'function') {
      throw new SensorLoopDriverError(
        'SensorLoopDriver requires a captureFrame() function — there is no built-in camera access.'
      );
    }
    this.#client = client;
    this.#bus = bus;
    this.#captureFrame = opts.captureFrame;
  }

  /**
   * Run exactly one iteration of whichever loop shape `rule` describes.
   * This is the core testable unit — `start()` is just this on a timer.
   * @param {string} loopId identifies this loop for events/timer bookkeeping (e.g. a button id)
   * @param {{ route_to: string, escalate_to?: string, escalation_threshold_pct?: number, [k: string]: any }} rule
   * @param {import('./payloadBuilder.mjs').IntentContext} [context]
   */
  async runOnce(loopId, rule, context = {}) {
    if (rule.escalate_to) {
      return this.#runGuardTick(loopId, rule, context);
    }
    return this.#runScanTick(loopId, rule, context);
  }

  async #runScanTick(loopId, rule, context) {
    const frame = await this.#captureFrame();
    this.#bus.emit(Events.SENSOR_FRAME, { loopId, ts: Date.now() });

    const response = await this.#client.callRouteWithContext(rule, { ...context, images: [frame] });
    const text = extractResponseText(response);

    this.#bus.emit(Events.SENSOR_DESCRIPTION, { loopId, text });
    return { escalated: false, text, frame };
  }

  async #runGuardTick(loopId, rule, context) {
    const reading = await this.#client.callRouteWithContext(rule, context);
    const pctChange = reading?.pct_change ?? 0;
    this.#bus.emit(Events.SENSOR_MOTION_READING, { loopId, pct_change: pctChange });

    const threshold = rule.escalation_threshold_pct ?? Infinity;
    if (pctChange < threshold) {
      return { escalated: false, pct_change: pctChange };
    }

    const frame = await this.#captureFrame();
    this.#bus.emit(Events.SENSOR_FRAME, { loopId, ts: Date.now() });

    const response = await this.#client.callRouteWithContext(
      { route_to: rule.escalate_to },
      { ...context, images: [frame] }
    );
    const text = extractResponseText(response);

    this.#bus.emit(Events.ALERT_RAISED, {
      loopId,
      severity: 'motion',
      source: rule.escalate_to,
      message: text,
      pct_change: pctChange,
    });

    return { escalated: true, text, pct_change: pctChange, frame };
  }

  /**
   * Start a repeating loop. Fires one tick immediately (so the UI isn't
   * staring at a blank screen for a full interval before the first
   * description shows up), then repeats every `intervalMs`.
   *
   * @param {string} loopId unique id for this loop; starting an already-running loopId throws
   * @param {{ route_to: string, [k: string]: any }} rule
   * @param {import('./payloadBuilder.mjs').IntentContext} [context]
   * @param {{
   *   intervalMs?: number,
   *   onTick?: (result: any) => void,
   *   onError?: (err: Error) => void,
   *   timerImpl?: { setInterval: typeof setInterval, clearInterval: typeof clearInterval }
   * }} [opts]
   */
  start(loopId, rule, context = {}, opts = {}) {
    if (this.#timers.has(loopId)) {
      throw new SensorLoopDriverError(`Loop "${loopId}" is already running`);
    }

    const intervalMs =
      opts.intervalMs ?? rule.loop_interval_ms ?? rule.motion_poll_interval_ms ?? 1000;
    const setIntervalFn = opts.timerImpl?.setInterval ?? setInterval;
    const clearIntervalFn = opts.timerImpl?.clearInterval ?? clearInterval;

    const tick = async () => {
      try {
        const result = await this.runOnce(loopId, rule, context);
        opts.onTick?.(result);
      } catch (err) {
        this.#bus.emit(Events.SENSOR_LOOP_ERROR, { loopId, error: String(err?.message ?? err) });
        opts.onError?.(err);
      }
    };

    const handle = setIntervalFn(tick, intervalMs);
    this.#timers.set(loopId, { handle, clearIntervalFn });
    this.#bus.emit(Events.SENSOR_LOOP_STARTED, { loopId, intervalMs });

    tick(); // fire the first tick immediately, don't wait a full interval
  }

  /** @param {string} loopId */
  isRunning(loopId) {
    return this.#timers.has(loopId);
  }

  /**
   * Stop a running loop. Returns false (not an error) if it wasn't running —
   * stopping something already stopped is a normal, harmless UI action.
   * @param {string} loopId
   */
  stop(loopId) {
    const entry = this.#timers.get(loopId);
    if (!entry) return false;
    entry.clearIntervalFn(entry.handle);
    this.#timers.delete(loopId);
    this.#bus.emit(Events.SENSOR_LOOP_STOPPED, { loopId });
    return true;
  }

  /** Stop every currently running loop (e.g. app backgrounded). */
  stopAll() {
    for (const loopId of [...this.#timers.keys()]) this.stop(loopId);
  }
}
