/**
 * payloadBuilder — closes the gap between "we decided to call
 * models.chat_vision" and "here's the exact JSON body llama-server wants."
 *
 * Per the project's own rule (nothing important hardcoded): the *shape* of
 * a request body is a property of the backend, not of the app. So each
 * model/provider entry in config declares a `protocol` (e.g.
 * "openai_chat_vision", "openai_images"), and this module is just a
 * registry of protocol -> builder function. Adding a new backend shape
 * later (say, a non-OpenAI-compatible TTS server) means adding one function
 * and one registry entry here — nothing upstream (TupleEngine, McpClient)
 * needs to know or care.
 *
 * Every builder is a pure function: (target, context) -> plain object body.
 * No network, no config-file access, no side effects — easy to unit test
 * in isolation, which is the point.
 */

/** Canonical protocol identifiers. A model's config `protocol` field should be one of these. */
export const Protocols = Object.freeze({
  OPENAI_CHAT: 'openai_chat',
  OPENAI_CHAT_VISION: 'openai_chat_vision',
  OPENAI_IMAGES: 'openai_images',
  OPENAI_AUDIO_SPEECH: 'openai_audio_speech',
  OPENAI_AUDIO_TRANSCRIPTION: 'openai_audio_transcription',
  RAW: 'raw',
});

export class UnknownProtocolError extends Error {}

/**
 * @typedef {object} IntentContext
 * @property {string} [text] user text or STT transcript — the main prompt content
 * @property {string} [systemPrompt] optional system-role instruction
 * @property {string[]} [images] optional array of image URLs or data: URLs
 * @property {string} [voice] optional voice id override for TTS
 * @property {string} [audioBase64] base64 audio payload for STT
 * @property {number} [n] number of images to generate
 * @property {string} [size] image size, e.g. "512x512"
 */

/**
 * @param {any} target the resolved config entry for the backend being called (has `.id`, may have `.voice`, etc.)
 * @param {IntentContext} context
 */
function buildOpenAiChat(target, context) {
  const messages = [];
  if (context.systemPrompt) messages.push({ role: 'system', content: context.systemPrompt });
  messages.push({ role: 'user', content: context.text ?? '' });
  return { model: target.id, messages, stream: false };
}

/**
 * Same as openai_chat, but content becomes a multi-part array (OpenAI
 * vision shape) when images are present. Falls back to a plain string
 * body when there are none, so a vision-capable model still works fine
 * for plain-text turns.
 */
function buildOpenAiChatVision(target, context) {
  const hasImages = Array.isArray(context.images) && context.images.length > 0;
  const userContent = hasImages
    ? [
        { type: 'text', text: context.text ?? '' },
        ...context.images.map((url) => ({ type: 'image_url', image_url: { url } })),
      ]
    : (context.text ?? '');

  const messages = [];
  if (context.systemPrompt) messages.push({ role: 'system', content: context.systemPrompt });
  messages.push({ role: 'user', content: userContent });
  return { model: target.id, messages, stream: false };
}

function buildOpenAiImages(target, context) {
  return {
    model: target.id,
    prompt: context.text ?? '',
    n: context.n ?? 1,
    size: context.size ?? target.default_size ?? '512x512',
  };
}

function buildOpenAiAudioSpeech(target, context) {
  return {
    model: target.id,
    input: context.text ?? '',
    voice: context.voice ?? target.voice ?? 'default',
  };
}

function buildOpenAiAudioTranscription(target, context) {
  return {
    model: target.id,
    file: context.audioBase64 ?? '',
    response_format: context.response_format ?? 'json',
  };
}

/** Pass the context through untouched — for local (non-HTTP) handlers, or genuinely custom backends. */
function buildRaw(_target, context) {
  return context;
}

const BUILDERS = {
  [Protocols.OPENAI_CHAT]: buildOpenAiChat,
  [Protocols.OPENAI_CHAT_VISION]: buildOpenAiChatVision,
  [Protocols.OPENAI_IMAGES]: buildOpenAiImages,
  [Protocols.OPENAI_AUDIO_SPEECH]: buildOpenAiAudioSpeech,
  [Protocols.OPENAI_AUDIO_TRANSCRIPTION]: buildOpenAiAudioTranscription,
  [Protocols.RAW]: buildRaw,
};

/**
 * Build the request body for a resolved backend config entry.
 * @param {any} target a resolved `models.*` (or future `context_providers.*`) config entry
 * @param {IntentContext} context
 */
export function buildPayload(target, context = {}) {
  const protocol = target?.protocol ?? Protocols.RAW;
  const builder = BUILDERS[protocol];
  if (!builder) {
    throw new UnknownProtocolError(
      `No payload builder registered for protocol "${protocol}". ` +
        `Known protocols: ${Object.keys(BUILDERS).join(', ')}`
    );
  }
  return builder(target, context);
}

/**
 * Register a builder for a new protocol at runtime — the extensibility
 * seam for a backend shape nobody's thought of yet, without editing this
 * file.
 * @param {string} protocol
 * @param {(target: any, context: IntentContext) => any} builder
 */
export function registerProtocol(protocol, builder) {
  BUILDERS[protocol] = builder;
}
