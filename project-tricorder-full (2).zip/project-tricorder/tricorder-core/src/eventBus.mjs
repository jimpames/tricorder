/**
 * EventBus — the only thing UI components, providers, and engines talk to.
 *
 * Design rule (per spec §5): nobody calls anybody directly. You emit an
 * event, and whoever cares has subscribed. This is what lets us swap
 * "3 buttons" for "voice wake word" later without touching downstream code.
 */

export class EventBus {
  #listeners = new Map(); // eventName -> Set<handler>
  #wildcardListeners = new Set();
  #history = [];
  #historyLimit;

  /**
   * @param {{ historyLimit?: number }} [opts]
   */
  constructor(opts = {}) {
    this.#historyLimit = opts.historyLimit ?? 200;
  }

  /**
   * @param {string} eventName
   * @param {(payload: any, meta: { eventName: string, ts: number }) => void} handler
   * @returns {() => void} unsubscribe function
   */
  on(eventName, handler) {
    if (!this.#listeners.has(eventName)) {
      this.#listeners.set(eventName, new Set());
    }
    this.#listeners.get(eventName).add(handler);
    return () => this.#listeners.get(eventName)?.delete(handler);
  }

  /**
   * Subscribe to every event, regardless of name. Useful for logging/devtools.
   * @param {(eventName: string, payload: any, meta: { ts: number }) => void} handler
   */
  onAny(handler) {
    this.#wildcardListeners.add(handler);
    return () => this.#wildcardListeners.delete(handler);
  }

  /**
   * @param {string} eventName
   * @param {any} [payload]
   */
  emit(eventName, payload = {}) {
    const meta = { eventName, ts: Date.now() };

    this.#history.push({ eventName, payload, ts: meta.ts });
    if (this.#history.length > this.#historyLimit) this.#history.shift();

    for (const handler of this.#listeners.get(eventName) ?? []) {
      handler(payload, meta);
    }
    for (const handler of this.#wildcardListeners) {
      handler(eventName, payload, meta);
    }
  }

  /** Snapshot of recent events, oldest first. Mainly for debugging/tests. */
  getHistory() {
    return [...this.#history];
  }

  clearHistory() {
    this.#history = [];
  }
}

/**
 * Canonical event names (§5 of the design doc). Not enforced — the bus will
 * happily emit any string — but importing from here keeps typos out of the
 * codebase instead of scattering string literals everywhere.
 */
export const Events = Object.freeze({
  BUTTON_PRESS: 'button.press',
  INPUT_AUDIO_CAPTURED: 'input.audio_captured',
  INPUT_TEXT: 'input.text',
  TUPLE_RESOLVED: 'tuple.resolved',
  TUPLE_UNRESOLVED: 'tuple.unresolved',
  PROVIDER_DATA: 'provider.data',
  PROVIDER_ERROR: 'provider.error',
  MODEL_RESPONSE_DELTA: 'model.response.delta',
  MODEL_RESPONSE_DONE: 'model.response.done',
  AUDIO_OUTPUT_START: 'audio.output.start',
  AUDIO_OUTPUT_STOP: 'audio.output.stop',
  SENSOR_MOTION_DELTA: 'sensor.motion_delta',
  SENSOR_FRAME: 'sensor.frame',
  SENSOR_DESCRIPTION: 'sensor.description',
  SENSOR_MOTION_READING: 'sensor.motion_reading',
  SENSOR_LOOP_STARTED: 'sensor.loop_started',
  SENSOR_LOOP_STOPPED: 'sensor.loop_stopped',
  SENSOR_LOOP_ERROR: 'sensor.loop_error',
  ALERT_RAISED: 'alert.raised',
  MODE_CHANGED: 'mode.changed',
});
