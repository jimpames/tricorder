/**
 * NOAA / National Weather Service active alerts provider.
 *
 * Real endpoint: https://api.weather.gov/alerts/active
 * Free, no API key — but it does require a descriptive `User-Agent` header
 * identifying the app and a contact, or requests get rejected. That's why
 * `user_agent` lives in config (`context_providers.weather_alerts_noaa.user_agent`)
 * rather than being written into this file: it's a deployment detail, not
 * a code detail, and someone shipping this app under their own name needs
 * to be able to change it without touching source.
 *
 * This module is deliberately just "fetch + normalize" — no polling, no
 * timers, no bus. `contextProviderPoller.mjs` is what turns this into a
 * running loop; that separation is what lets the exact same poller drive
 * a completely different provider (flights, crime alerts, ...) later.
 */

export class NoaaProviderError extends Error {}

/**
 * NWS alert severities, from the CAP standard, roughly least to most urgent.
 * Exported so callers configuring `alert_severities` thresholds don't have
 * to remember NWS's exact vocabulary.
 */
export const NoaaSeverities = Object.freeze(['Unknown', 'Minor', 'Moderate', 'Severe', 'Extreme']);

/**
 * @param {{ endpoint: string, user_agent?: string }} providerConfig
 * @param {{ lat: number, lon: number }} location
 * @param {typeof fetch} [fetchImpl]
 * @returns {Promise<{ alerts: NormalizedAlert[], raw: any }>}
 */
export async function fetchActiveAlerts(providerConfig, location, fetchImpl = globalThis.fetch) {
  if (!providerConfig?.endpoint) {
    throw new NoaaProviderError('NOAA provider config is missing "endpoint"');
  }
  if (typeof location?.lat !== 'number' || typeof location?.lon !== 'number') {
    throw new NoaaProviderError('fetchActiveAlerts requires a { lat, lon } location');
  }

  const url = `${providerConfig.endpoint}?point=${location.lat},${location.lon}`;
  const userAgent = providerConfig.user_agent ?? 'ProjectTricorder/0.1 (no contact configured)';

  const res = await fetchImpl(url, {
    headers: {
      'User-Agent': userAgent,
      Accept: 'application/geo+json',
    },
  });

  if (!res.ok) {
    throw new NoaaProviderError(`NOAA alerts endpoint returned ${res.status}`);
  }

  const raw = await res.json();
  const alerts = (raw?.features ?? []).map(normalizeFeature);
  return { alerts, raw };
}

/**
 * @typedef {object} NormalizedAlert
 * @property {string} id
 * @property {string} event
 * @property {string} headline
 * @property {string} severity
 * @property {string} urgency
 * @property {string} certainty
 * @property {string} areaDesc
 * @property {string|null} effective
 * @property {string|null} expires
 */

/** @param {any} feature a single GeoJSON feature from the NWS alerts response */
function normalizeFeature(feature) {
  const p = feature?.properties ?? {};
  return {
    id: p.id ?? feature?.id ?? null,
    event: p.event ?? 'Unknown Event',
    headline: p.headline ?? p.event ?? 'Weather alert',
    severity: p.severity ?? 'Unknown',
    urgency: p.urgency ?? 'Unknown',
    certainty: p.certainty ?? 'Unknown',
    areaDesc: p.areaDesc ?? '',
    effective: p.effective ?? null,
    expires: p.expires ?? null,
  };
}

/**
 * Filter normalized alerts down to the ones worth interrupting the user
 * for, per a configurable severity floor (default: Severe and Extreme
 * only — Minor/Moderate advisories are common and not sentry-worthy).
 * This is the function you'd pass as `deriveAlerts` to
 * `ContextProviderPoller#start` so it can raise `alert.raised` events.
 *
 * @param {NormalizedAlert[]} alerts
 * @param {{ alert_severities?: string[] }} [providerConfig]
 */
export function deriveSevereAlerts(alerts, providerConfig = {}) {
  const floor = providerConfig.alert_severities ?? ['Severe', 'Extreme'];
  return alerts
    .filter((a) => floor.includes(a.severity))
    .map((a) => ({
      severity: a.severity,
      message: `${a.event}: ${a.headline}`,
      source: 'weather_alerts_noaa',
      raw: a,
    }));
}
