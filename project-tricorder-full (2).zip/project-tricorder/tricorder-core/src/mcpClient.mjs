/**
 * McpClient — turns a tuple-engine route decision into an actual call
 * against whatever backend the config says to use.
 *
 * A "route_to" value is a dotted path into the config document, e.g.
 * "models.chat_vision" or "context.flight_overhead" or "sensor.motion_delta".
 * This file never mentions "Gemma" or "OpenSky" — it just resolves paths
 * and calls whatever `endpoint` shows up there, OpenAI-chat-shaped by
 * default. Non-HTTP backends (local sensors) register a handler instead
 * of an endpoint — see `registerLocalHandler`.
 *
 * `callRouteWithContext` is the more useful entry point once real backends
 * are involved: hand it a generic `IntentContext` (text, images, voice, ...)
 * and it builds the correct request body per backend *using that backend's
 * own declared `protocol`* — including rebuilding the body from scratch for
 * a fallback target, since a fallback backend (e.g. a chat model standing
 * in for a disabled image generator) almost always expects a different
 * shape than the primary one did. See `payloadBuilder.mjs`.
 */

import { buildPayload } from './payloadBuilder.mjs';

/**
 * Walk a dotted path ("models.chat_vision") into a config object.
 * @param {any} config
 * @param {string} path
 */
export function resolveRoutePath(config, path) {
  const parts = path.split('.');
  let node = config;
  for (const part of parts) {
    if (node == null) return undefined;
    node = node[part];
  }
  return node;
}

export class RouteResolutionError extends Error {}
export class BackendCallError extends Error {}

export class McpClient {
  #configLoader;
  #bus;
  #fetchImpl;
  /** @type {Map<string, (payload: any) => Promise<any>>} */
  #localHandlers = new Map();

  /**
   * @param {import('./configLoader.mjs').ConfigLoader} configLoader
   * @param {import('./eventBus.mjs').EventBus} bus
   * @param {{ fetchImpl?: typeof fetch }} [opts]
   */
  constructor(configLoader, bus, opts = {}) {
    this.#configLoader = configLoader;
    this.#bus = bus;
    this.#fetchImpl = opts.fetchImpl ?? globalThis.fetch;
  }

  /**
   * Register a handler for a route path that isn't an HTTP backend at all —
   * e.g. "sensor.motion_delta" is answered by local frame-diff code, not a URL.
   * @param {string} routePath
   * @param {(payload: any) => Promise<any>} handler
   */
  registerLocalHandler(routePath, handler) {
    this.#localHandlers.set(routePath, handler);
  }

  /**
   * Execute a route decision produced by TupleEngine#resolveTuple.
   * Tries `rule.route_to` first; on failure, falls back to `rule.fallback`
   * if one is configured; throws only if both are exhausted.
   * @param {{ route_to: string, fallback?: string, [k: string]: any }} rule
   * @param {any} payload
   */
  async callRoute(rule, payload) {
    try {
      return await this.#callPath(rule.route_to, payload);
    } catch (err) {
      if (!rule.fallback) throw err;
      this.#bus.emit('route.fallback_used', {
        primary: rule.route_to,
        fallback: rule.fallback,
        reason: String(err?.message ?? err),
      });
      return this.#callPath(rule.fallback, payload);
    }
  }

  /**
   * Same as `callRoute`, but takes a generic `IntentContext` (text, images,
   * voice, ...) instead of a pre-built payload, and builds the correct body
   * for whichever backend actually ends up handling the call — primary or
   * fallback — using that backend's own `protocol`. This is what closes the
   * "we routed to image_generation but it's disabled, so chat_vision has to
   * handle it instead, and chat_vision does NOT want an images-API body"
   * gap.
   *
   * @param {{ route_to: string, fallback?: string, [k: string]: any }} rule
   * @param {import('./payloadBuilder.mjs').IntentContext} context
   */
  async callRouteWithContext(rule, context) {
    try {
      const payload = this.#buildPayloadFor(rule.route_to, context);
      return await this.#callPath(rule.route_to, payload);
    } catch (err) {
      if (!rule.fallback) throw err;
      this.#bus.emit('route.fallback_used', {
        primary: rule.route_to,
        fallback: rule.fallback,
        reason: String(err?.message ?? err),
      });
      const fallbackPayload = this.#buildPayloadFor(rule.fallback, context);
      return this.#callPath(rule.fallback, fallbackPayload);
    }
  }

  /**
   * Build the request body for a given route path, without calling it.
   * Local (non-HTTP) handlers get the raw context, untouched — building an
   * OpenAI-shaped body for a motion sensor makes no sense.
   */
  #buildPayloadFor(routePath, context) {
    if (this.#localHandlers.has(routePath)) return context;
    const target = this.#resolveHttpTarget(routePath);
    return buildPayload(target, context);
  }

  /** Resolve and validate an HTTP backend's config entry, or throw. */
  #resolveHttpTarget(routePath) {
    const config = this.#configLoader.current;
    const target = resolveRoutePath(config, routePath);
    if (!target) {
      throw new RouteResolutionError(`No config entry found at route path "${routePath}"`);
    }
    if (target.enabled === false) {
      throw new RouteResolutionError(`Route "${routePath}" is present in config but disabled`);
    }
    if (!target.endpoint) {
      throw new RouteResolutionError(
        `Route "${routePath}" has no "endpoint" and no local handler is registered for it`
      );
    }
    return target;
  }

  async #callPath(routePath, payload) {
    if (this.#localHandlers.has(routePath)) {
      return this.#localHandlers.get(routePath)(payload);
    }

    const target = this.#resolveHttpTarget(routePath);

    if (!this.#fetchImpl) {
      throw new BackendCallError('No fetch implementation available to call HTTP route');
    }

    const res = await this.#fetchImpl(target.endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      throw new BackendCallError(`Backend at "${routePath}" (${target.endpoint}) returned ${res.status}`);
    }
    return res.json();
  }
}
