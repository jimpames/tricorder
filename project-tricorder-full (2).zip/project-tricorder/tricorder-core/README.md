# tricorder-core

The platform-agnostic brain of Project Tricorder: event bus, config loader,
deterministic tuple-algebra intent engine, and an MCP-style routing client.
No UI, no React Native, no Android/iOS glue yet — this is the part that has
to be right before any of that is worth building, and it's plain JS so it
can be embedded in React Native, a Node-based Termux service, or tested
standalone (as it is here).

## Run the tests

```
npm test
```

93 tests, zero network calls (everything is mocked), zero dependencies.

## What's here

| File | Design doc section | What it does |
|---|---|---|
| `src/eventBus.mjs` | §5 (Event Bus) | Pub/sub. UI, providers, and engines only ever touch this — never each other. |
| `src/configLoader.mjs` | §3 (Config Document) | Loads `config/tricorder.config.json`, validates its shape, hot-reloads on file change, emits `config.error` instead of crashing on a bad edit. |
| `src/tupleEngine.mjs` | §4 (Tuple Engine) | Turns a button press (or any input) into a `(Mode, InputChannel, TargetModality, Action)` tuple, applies config-defined keyword hints, and matches it against `tuple_rules` — first match wins, no LLM call involved. |
| `src/mcpClient.mjs` | §6 (MCP Server tool catalog) | Resolves a rule's `route_to` (a dotted path like `models.chat_vision`) against the config, POSTs to whatever endpoint is configured there, and falls back to `rule.fallback` on failure. Non-HTTP backends (sensors) register a local handler instead. `callRouteWithContext` is the version to actually use once real backends exist — see below. |
| `src/payloadBuilder.mjs` | new — closes the gap from the llama-server setup guide | Turns a generic `IntentContext` (`{ text, images, voice, ... }`) into the exact request body a given backend's declared `protocol` expects (`openai_chat`, `openai_chat_vision`, `openai_images`, `openai_audio_speech`, `openai_audio_transcription`, or `raw`). Each model in config now declares its `protocol` — this is itself validated: `configLoader` flags any model with an `endpoint` but no `protocol`. |
| `src/sensorLoopDriver.mjs` | §7 (Button 2/3 behavior) | Turns a resolved rule into a repeating capture-and-call loop. A rule with `escalate_to` runs a cheap **guard loop** (poll a local/cheap route, only call the escalation route once a reading crosses `escalation_threshold_pct`) — that's Sentry mode. Any other rule runs a **scan loop** (capture + call every tick, unconditionally) — that's Sensor mode. Frame capture is injected (`captureFrame`), so this has zero camera/platform dependency and is fully unit-testable. |
| `src/providers/noaaWeatherAlerts.mjs` | §1/§6 (context providers) | The first real (non-stubbed) context provider. `fetchActiveAlerts` hits `api.weather.gov/alerts/active` with a point (lat/lon) query and the config-supplied `User-Agent` NOAA requires, and normalizes the GeoJSON response into flat alert objects. `deriveSevereAlerts` filters those down to a configurable severity floor (`alert_severities`, default `["Severe","Extreme"]`) for anything worth actually interrupting the user. |
| `src/contextProviderPoller.mjs` | §6/§1 (extensibility) | The provider-side sibling of `SensorLoopDriver` — a generic repeating-fetch-and-normalize loop. Deliberately provider-agnostic: NOAA is the first `fetchFn` it drives, but the *next* context provider (flights, crime alerts, ...) reuses this exact class untouched. |
| `config/tricorder.config.json` | §3 | The actual reference config — 3 buttons, 4 tuple rules, 5 disabled context providers, matching the design doc exactly. |
| `test/*.test.mjs` | — | Unit tests per module, plus `integration.test.mjs` which walks the literal demo scenarios from our planning conversation ("distance to Alpha Centauri," "show me an image of Talos Four," sensor loop, sentry motion threshold) end to end with a mocked network. |

## Calling a real backend (once one exists)

Use `callRouteWithContext`, not the older `callRoute` (which still exists,
still tested, and still expects you to hand it an already-built payload —
kept for cases where you genuinely want to bypass the builder):

```js
const decision = engine.resolveButtonPress('btn_1', { text: transcript });
const response = await client.callRouteWithContext(decision.rule, {
  text: transcript,
  // images: [dataUrl], voice: 'computer_female_measured', etc. as relevant
});
```

The important detail this covers: if the primary route is disabled (image
generation, in the reference config) and it falls back to `chat_vision`,
the fallback body gets **rebuilt from scratch** for chat_vision's own
protocol — it does not send an images-API-shaped body to a chat endpoint.
`test/integration.test.mjs` has the full "imagine Talos Four" scenario
verifying exactly this.

## Running the sensor loops

```js
import { SensorLoopDriver } from './src/sensorLoopDriver.mjs';

// captureFrame is the one piece of real platform glue this needs —
// on-device, this is your camera hook; here it's whatever you inject.
const driver = new SensorLoopDriver(client, bus, {
  captureFrame: async () => await grabCameraFrameAsDataUrl(),
});

// Sensor mode (Button 2): describes what the camera sees, on repeat.
const scanDecision = engine.resolveButtonPress('btn_2');
driver.start('btn_2', scanDecision.rule); // uses rule.loop_interval_ms from config

// Sentry mode (Button 3): silent/local until motion crosses threshold,
// then escalates to the vision model exactly once per spike.
const guardDecision = engine.resolveButtonPress('btn_3');
driver.start('btn_3', guardDecision.rule); // uses rule.motion_poll_interval_ms

// ...later, e.g. when the button is pressed again to turn a mode off:
driver.stop('btn_2');
```

Subscribe to `Events.SENSOR_DESCRIPTION` (scan mode) or `Events.ALERT_RAISED`
(guard mode, only fires on an actual escalation) on the bus — that's the
whole UI-facing contract; the UI never touches `SensorLoopDriver` or
`McpClient` directly.

## Running a context provider

```js
import { ContextProviderPoller } from './src/contextProviderPoller.mjs';
import { fetchActiveAlerts, deriveSevereAlerts } from './src/providers/noaaWeatherAlerts.mjs';

const poller = new ContextProviderPoller(bus);
const providerConfig = loader.getProvider('weather_alerts_noaa');

poller.start('weather_alerts_noaa', providerConfig, { lat: myLat, lon: myLon }, {
  fetchFn: (cfg, params) => fetchActiveAlerts(cfg, params),
  deriveAlerts: (data, cfg) => deriveSevereAlerts(data.alerts, cfg),
});
```

`{ lat, lon }` should come from the (already-enabled) `geolocation` provider
in a real build — this module doesn't read GPS itself, on purpose, same
reasoning as `captureFrame` for the camera.

**Before shipping:** edit `context_providers.weather_alerts_noaa.user_agent`
in `tricorder.config.json` to include a real contact — NOAA's API requires
a descriptive User-Agent and will reject requests from a generic/default
one at any real volume.

## What's deliberately *not* here yet

- Any actual model, TTS, or STT backend — the tests mock `fetch`. Wiring up
  a real `llama-server` endpoint is a config edit (`config/tricorder.config.json`
  → `models.chat_vision.endpoint`), not a code change. See
  `tricorder-llama-server-setup.md` for the Termux walkthrough.
- Real camera access — `captureFrame` is injected on purpose; the actual
  React Native / native camera hook is platform glue that belongs outside
  this module.
- The UI (TOS shell: screen, 3 lights, 3 buttons, speaker). This module
  exposes exactly what a UI layer needs to subscribe to (`EventBus` events)
  and one method to call on button press (`TupleEngine#resolveButtonPress`).
- Real context providers (weather, flights, Citizen, flora/fauna, Waze).
  Their config *shape* exists and is validated; their actual polling/fetch
  logic is future work, each as its own small module that calls
  `client.registerLocalHandler(...)` or gets a normal `endpoint`.
- Motion escalation *behavior* (the integration test shows how to read
  `escalation_threshold_pct` against a live reading, but the sentry loop
  itself — the `setInterval`/frame-capture wiring — belongs in the
  platform-specific layer, not here).

## Try editing the config

Open `config/tricorder.config.json` and:

- Add a 4th button by adding an entry to `controls.buttons` with its own
  `tuple_seed` — no code changes required.
- Add a new keyword hint under `intent_keyword_hints` (e.g. a `"TRANSLATE"`
  modality triggered by the word "translate") and a matching `tuple_rules`
  entry — the engine picks it up on next load with zero code changes.
- Flip `context_providers.weather_alerts_noaa.enabled` to `true` — it'll show
  up in `loader.enabledProviders()` immediately; wiring an actual poller to
  call it is the next piece of work.

## Suggested next steps (in order)

1. ~~`llama-server` + Termux setup~~ — done, see `tricorder-llama-server-setup.md`.
2. ~~Payload builder~~ — done, see `src/payloadBuilder.mjs`.
3. ~~Sensor-loop driver~~ — done, see `src/sensorLoopDriver.mjs`.
4. ~~First real context provider (NOAA)~~ — done, see `src/providers/noaaWeatherAlerts.mjs`
   and `src/contextProviderPoller.mjs`. `flight_overhead` (OpenSky, OAuth2)
   and `crime_safety_citizen` (paid) are the next two, in roughly that
   order of difficulty.
5. The **UI shell**, subscribing to `EventBus` events only. By this point
   it genuinely only needs: render on `SENSOR_DESCRIPTION` / `ALERT_RAISED`
   / `MODEL_RESPONSE_*`, and call `resolveButtonPress` + `driver.start/stop`
   on button taps. The camera hook, audio playback/STT capture, and GPS
   read are the only real native code left to write.
