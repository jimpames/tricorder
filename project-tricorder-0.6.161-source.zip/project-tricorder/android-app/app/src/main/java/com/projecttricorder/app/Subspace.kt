package com.projecttricorder.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * SUBSPACE send queue. Field log stays the evidence book.
 * This sidecar only remembers what was offered and what was blasted.
 * blastable is the checkbox set at send time, not a stored bit.
 */
class Subspace(
    private val context: Context,
    private val guid: () -> String,
    private val send: (String) -> Unit,
) {
    private val pending = ConcurrentHashMap<String, JSONObject>()
    private val recent = ArrayDeque<String>()
    private var tokens = 1.0
    private var lastMs = System.currentTimeMillis()

    fun note(id: String, kind: String, text: String, lat: Double?, lon: Double?) {
        val cat = category(kind, text) ?: if (kind.equals("flight", true) || kind.equals("citizen", true) || kind.equals("civic", true)) {
            if (kind.equals("flight", true)) "flight" else "civic"
        } else return
        val row = JSONObject()
            .put("id", id.ifBlank { cat + System.currentTimeMillis() })
            .put("kind", kind)
            .put("category", cat)
            .put("text", text.take(80))
            .put("t_ms", System.currentTimeMillis())
            .put("blasted", false)
        if (lat != null && lon != null && lat.isFinite() && lon.isFinite()) {
            row.put("lat", lat).put("lon", lon)
        }
        row.put("blastable", enabled(cat))
        pending[row.optString("id")] = row
        writeSidecar(row)
        if (row.optBoolean("blastable")) {
            WireLog.line(context, "DETECT id=" + row.optString("id") + " cat=" + cat + " t=" + row.optLong("t_ms") + " text=" + row.optString("text"))
        }
    }

    fun pump() {
        if (!loraOn()) return
        refill()
        if (tokens < 1.0) return
        val cat = PRIORITY.firstOrNull { c -> enabled(c) && pending.values.any { row -> row.optString("category") == c && !row.optBoolean("blasted") } } ?: return
        val row = pending.values
            .filter { it.optString("category") == cat && !it.optBoolean("blasted") }
            .minByOrNull { it.optLong("t_ms") } ?: return
        val frames = frames(row)
        val blastAt = System.currentTimeMillis()
        WireLog.line(context, "BLAST id=" + row.optString("id") + " cat=" + row.optString("category") + " t=" + blastAt + " n=" + frames.size)
        frames.forEachIndexed { i, line ->
            WireLog.line(context, "TX t=" + System.currentTimeMillis() + " frame=" + (i + 1) + "/" + frames.size + " " + line)
            send(line)
        }
        pending.remove(row.optString("id"))
        recent.addFirst("sent | " + row.optString("category") + " | " + row.optString("text").take(60))
        while (recent.size > 8) recent.removeLast()
        tokens -= 1.0
        row.put("blasted", true).put("blasted_ms", System.currentTimeMillis()).put("wire", frames.joinToString(" || "))
        writeSidecar(row)
    }

    fun status(): JSONObject = JSONObject()
        .put("pending", pending.size)
        .put("per_min", rate())
        .put("tokens", tokens)
        .put("queue", queueJson())

    fun queueJson(): org.json.JSONArray {
        val arr = org.json.JSONArray()
        pending.values.sortedBy { it.optLong("t_ms") }.forEach { row ->
            val flag = if (row.optBoolean("blastable")) "blast" else "hold"
            arr.put(flag + " | " + row.optString("category") + " | " + row.optString("text").take(60))
        }
        recent.forEach { arr.put(it) }
        return arr
    }

    fun clear() {
        pending.clear()
    }

    /** One logical detection, cut into Meshtastic text frames. Body stays under 150 so the line is under 200. */
    private fun frames(row: JSONObject): List<String> {
        val g = guid().replace("-", "").uppercase()
        val node = g.removePrefix("TC").take(6)
        val msg = row.optString("id").replace("-", "").takeLast(4).uppercase().ifBlank { g.takeLast(4) }
        val hh = java.text.SimpleDateFormat("HH:mm", java.util.Locale.US)
            .format(java.util.Date(row.optLong("t_ms")))
        val lat = row.optDouble("lat", Double.NaN)
        val lon = row.optDouble("lon", Double.NaN)
        val place = if (lat.isFinite() && lon.isFinite()) {
            String.format(java.util.Locale.US, "%.3f,%.3f", lat, lon)
        } else "na"
        val label = row.optString("text").replace("|", "/").replace("\n", " ").trim().take(480)
        return frame(node, msg, row.optString("category"), hh, place, label)
    }

    private fun frame(node: String, msg: String, cat: String, hh: String, place: String, label: String): List<String> {
        val head = "$hh $place "
        val body = (head + label).ifBlank { cat }
        val chunks = ArrayList<String>()
        var i = 0
        while (i < body.length) {
            val end = (i + CHUNK).coerceAtMost(body.length)
            chunks.add(body.substring(i, end))
            i = end
        }
        if (chunks.isEmpty()) chunks.add(cat)
        val n = chunks.size
        return chunks.mapIndexed { idx, part -> "TF|$node|$msg|${idx + 1}/$n|$cat|$part" }
    }

    private fun refill() {
        val now = System.currentTimeMillis()
        val per = rate()
        val add = (now - lastMs) / 60000.0 * per
        tokens = (tokens + add).coerceAtMost(per.toDouble())
        lastMs = now
    }

    private fun rate(): Int =
        pref("subspace_per_min", "1").toIntOrNull()?.coerceIn(1, 5) ?: 1

    private fun loraOn(): Boolean {
        val v = pref("lora_on", "0")
        return v == "1" || v.equals("true", true)
    }

    private fun enabled(cat: String): Boolean {
        val def = if (cat == "flight" || cat == "civic" || cat == "weapon") "1" else "0"
        val v = pref("subspace_$cat", def)
        return v == "1" || v.equals("true", true)
    }

    private fun pref(k: String, d: String) =
        context.getSharedPreferences("tricorder", Context.MODE_PRIVATE).getString(k, d) ?: d

    private fun writeSidecar(row: JSONObject) {
        try {
            val f = File(File(context.filesDir, "logs").also { it.mkdirs() }, "subspace.json")
            val arr = if (f.exists()) JSONArray(f.readText()) else JSONArray()
            val next = JSONArray()
            val id = row.optString("id")
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                if (o.optString("id") == id) continue
                next.put(o)
            }
            next.put(row)
            val cap = JSONArray()
            val start = (next.length() - 400).coerceAtLeast(0)
            for (i in start until next.length()) cap.put(next.get(i))
            f.writeText(cap.toString())
        } catch (_: Exception) {}
    }

    companion object {
        const val CHUNK = 140
        val PRIORITY = listOf(
            "weapon", "flight", "civic", "human", "vehicle", "flora", "motion", "soundscape", "silence",
        )

        fun category(kind: String, text: String): String? {
            val k = kind.lowercase()
            val t = text.lowercase()
            return when {
                k.contains("gun") || k.contains("weapon") || k.contains("sentry_weapon") ||
                    t.contains("weapon") || t.contains("gunfire") || t.contains("gunshot") -> "weapon"
                k == "flight" || k.contains("flight") -> "flight"
                k == "citizen" || k.contains("civic") || t.contains("civic") -> "civic"
                k.contains("speech") || k.contains("human") || t.contains("humans detected") ||
                    t.contains("speech") || t.contains("conversation") -> "human"
                k.contains("vehicle") || k.contains("rail") || k.contains("ship") ||
                    t.contains("vehicle") || t.contains(" car") || t.startsWith("car ") ||
                    t.contains("truck") || t.contains("bus") || t.contains("motorcycle") -> "vehicle"
                k.contains("bird") || k.contains("flora") || k.contains("fauna") || k.contains("animal") ||
                    k.contains("plant") || t.contains("bird") || t.contains("animal") ||
                    t.contains("fauna") || t.contains("dog") || t.contains("cat ") || t.contains("insect") -> "flora"
                k.contains("motion") || k == "sentry" || k.contains("sentry") || t.contains("motion detected") -> "motion"
                t.contains("silence") || k.contains("silence") -> "silence"
                k.contains("audio") || k.contains("sound") || k.contains("siren") || k.contains("rain") ||
                    t.contains("siren") || t.contains("rain detected") -> "soundscape"
                else -> null
            }
        }
    }
}
