package com.projecttricorder.app

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** MediaStore Downloads insert, the Android 10 pattern: pending, write descriptor, clear pending. */
object WireLog {
    private val fmt = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)
    private val buf = StringBuilder()
    private var uri: android.net.Uri? = null

    fun arm(context: Context) {
        uri = null
        buf.clear()
        line(context, "START diag on")
    }

    fun line(context: Context, event: String) {
        val prefs = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
        if (prefs.getString("diag_dump", "") != "1") return
        buf.append(fmt.format(Date())).append(' ').append(event.replace("\n", " ")).append('\n')
        publish(context)
    }

    private fun publish(context: Context) {
        val cr = context.contentResolver
        val collection = MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        if (uri == null) {
            val values = ContentValues().apply {
                put(MediaStore.Downloads.DISPLAY_NAME, "tricorder-wire.log")
                put(MediaStore.Downloads.MIME_TYPE, "text/plain")
                put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/ProjectTricorder")
                put(MediaStore.Downloads.IS_PENDING, 1)
            }
            uri = cr.insert(collection, values) ?: return
        }
        cr.openFileDescriptor(uri!!, "w")?.use { pfd ->
            FileOutputStream(pfd.fileDescriptor).use { it.write(buf.toString().toByteArray()) }
        }
        cr.update(uri!!, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
    }
}
