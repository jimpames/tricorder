package com.projecttricorder.app

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupStore {
    const val SCHEMA = 2
    const val DIR_NAME = "backup"
    const val META = "meta.json"
    const val ZIP_NAME = "tricorder-backup-v2.zip"

    fun export(context: Context, faceJson: String?): JSONObject {
        val dir = File(context.filesDir, DIR_NAME).also { it.mkdirs() }
        val prefs = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE)
        val prefObj = JSONObject()
        prefs.all.forEach { (k, v) -> if (v != null) prefObj.put(k, v.toString()) }
        val meta = JSONObject()
            .put("schema", SCHEMA)
            .put("app", "project-tricorder")
            .put("t_ms", System.currentTimeMillis())
            .put("prefs", prefObj)
            .put("face", faceJson ?: "")
        File(dir, META).writeText(meta.toString())
        copyFile(File(context.filesDir, "logs/field.jsonl"), File(dir, "field.jsonl"))
        copyFile(File(context.filesDir, "logs/audio.jsonl"), File(dir, "audio.jsonl"))
        copyFile(File(context.filesDir, "logs/flights.json"), File(dir, "flights.json"))
        copyFile(File(context.filesDir, "logs/civic.json"), File(dir, "civic.json"))
        copyFile(File(context.filesDir, "dictation/memos.json"), File(dir, "memos.json"))

        val zipInternal = File(dir, ZIP_NAME)
        zipDir(dir, zipInternal, skipName = ZIP_NAME)
        val extDir = context.getExternalFilesDir(null)?.let { File(it, DIR_NAME).also { d -> d.mkdirs() } }
        val zipExt = extDir?.let { File(it, ZIP_NAME) }
        if (zipExt != null) copyFile(zipInternal, zipExt)
        val public = writePublicZip(context, zipInternal)

        return JSONObject()
            .put("ok", true)
            .put("schema", SCHEMA)
            .put("bytes", zipInternal.length())
            .put("internal", dir.absolutePath)
            .put("app_copy", zipExt?.absolutePath ?: "")
            .put("public", public.ifBlank { zipExt?.absolutePath ?: "" })
    }

    fun import(context: Context): JSONObject {
        val tried = mutableListOf<String>()

        val internalMeta = File(context.filesDir, "$DIR_NAME/$META")
        if (internalMeta.exists() && internalMeta.length() > 8) {
            val r = applyMetaAndSiblings(context, internalMeta.parentFile!!, "internal-dir")
            if (r.optBoolean("ok")) return r
            tried.add(r.optString("error", "internal-dir"))
        }

        val zips = mutableListOf<File>()
        File(context.filesDir, "$DIR_NAME/$ZIP_NAME").takeIf { it.exists() }?.let { zips.add(it) }
        context.getExternalFilesDir(null)?.let { File(it, "$DIR_NAME/$ZIP_NAME") }?.takeIf { it.exists() }?.let { zips.add(it) }
        try {
            File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ProjectTricorder/$ZIP_NAME",
            ).takeIf { it.exists() }?.let { zips.add(it) }
        } catch (_: Exception) {}

        for (z in zips) {
            tried.add("zip " + z.name + " " + z.length() + "b")
            val unpacked = File(context.cacheDir, "restore-unpack").also {
                it.deleteRecursively()
                it.mkdirs()
            }
            try {
                unzip(z, unpacked)
                val r = applyMetaAndSiblings(context, unpacked, z.name)
                if (r.optBoolean("ok")) return r
                tried.add(r.optString("error", z.name))
            } catch (e: Exception) {
                tried.add(z.name + " " + (e.message ?: "unzip"))
            }
        }

        val legacy = File(context.filesDir, "backup/tricorder-backup-v1.json")
        if (legacy.exists()) {
            tried.add("legacy-v1 " + legacy.length() + "b")
            try {
                val root = JSONObject(legacy.readText())
                return applyLegacyObject(context, root, "legacy-v1")
            } catch (e: Exception) {
                tried.add("legacy-v1 parse " + (e.message ?: "bad"))
            }
        }

        return JSONObject()
            .put("ok", false)
            .put("error", "unreadable (" + tried.joinToString("; ").ifBlank { "no backup yet — tap BACKUP first on this build" } + ")")
    }

    private fun applyMetaAndSiblings(context: Context, dir: File, label: String): JSONObject {
        val metaFile = File(dir, META)
        if (!metaFile.exists()) return JSONObject().put("ok", false).put("error", "$label no meta.json")
        val root = try {
            JSONObject(metaFile.readText())
        } catch (e: Exception) {
            return JSONObject().put("ok", false).put("error", "$label meta " + (e.message ?: "parse"))
        }
        if (root.optString("app") != "project-tricorder") {
            return JSONObject().put("ok", false).put("error", "$label not app")
        }
        val sch = root.optInt("schema", -1)
        if (sch != SCHEMA && sch != 1) {
            return JSONObject().put("ok", false).put("error", "$label schema $sch")
        }
        writePrefs(context, root.optJSONObject("prefs") ?: JSONObject())
        copyFile(File(dir, "field.jsonl"), File(context.filesDir, "logs/field.jsonl"))
        copyFile(File(dir, "audio.jsonl"), File(context.filesDir, "logs/audio.jsonl"))
        copyFile(File(dir, "flights.json"), File(context.filesDir, "logs/flights.json"))
        copyFile(File(dir, "civic.json"), File(context.filesDir, "logs/civic.json"))
        copyFile(File(dir, "memos.json"), File(context.filesDir, "dictation/memos.json"))
        return JSONObject()
            .put("ok", true)
            .put("schema", sch)
            .put("from", label)
            .put("face", root.optString("face"))
    }

    private fun applyLegacyObject(context: Context, root: JSONObject, label: String): JSONObject {
        if (root.optString("app") != "project-tricorder") {
            return JSONObject().put("ok", false).put("error", "$label not app")
        }
        writePrefs(context, root.optJSONObject("prefs") ?: JSONObject())
        writeText(File(context.filesDir, "logs/field.jsonl"), root.optString("field_jsonl"))
        writeText(File(context.filesDir, "logs/audio.jsonl"), root.optString("audio_jsonl"))
        writeText(File(context.filesDir, "dictation/memos.json"), root.optString("dictation_json"))
        return JSONObject()
            .put("ok", true)
            .put("schema", 1)
            .put("from", label)
            .put("face", root.optString("face"))
    }

    private fun writePrefs(context: Context, po: JSONObject) {
        val ed = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE).edit()
        po.keys().forEach { ed.putString(it, po.optString(it)) }
        ed.commit()
    }

    fun writePublicText(context: Context, name: String, text: String): String {
        val rel = Environment.DIRECTORY_DOWNLOADS + "/ProjectTricorder"
        val tmp = File(context.cacheDir, name)
        tmp.writeText(text)
        var shown = ""
        if (Build.VERSION.SDK_INT >= 29) shown = mediaStorePut(context, tmp, name, rel)
        try {
            val pub = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "ProjectTricorder").also { it.mkdirs() }
            copyFile(tmp, File(pub, name))
            if (File(pub, name).exists()) shown = File(pub, name).absolutePath
        } catch (t: Throwable) {
            if (shown.isBlank()) shown = "file fail " + (t.message ?: t.javaClass.simpleName)
        }
        return shown.ifBlank { "no path" }
    }

    private fun writePublicZip(context: Context, zip: File): String {
        if (!zip.exists()) return ""
        val stamp = java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US)
            .format(java.util.Date())
        val dated = "tricorder-backup-$stamp.zip"
        val rel = Environment.DIRECTORY_DOWNLOADS + "/ProjectTricorder"
        var shown = ""
        if (Build.VERSION.SDK_INT >= 29) {
            shown = mediaStorePut(context, zip, ZIP_NAME, rel)
            mediaStorePut(context, zip, dated, rel)
        }
        try {
            val pub = File(
                Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
                "ProjectTricorder",
            ).also { it.mkdirs() }
            copyFile(zip, File(pub, ZIP_NAME))
            copyFile(zip, File(pub, dated))
            if (shown.isBlank() && File(pub, ZIP_NAME).exists()) {
                shown = File(pub, ZIP_NAME).absolutePath
            }
        } catch (_: Exception) {}
        return shown
    }

    private fun mediaStorePut(context: Context, zip: File, name: String, rel: String): String {
        return try {
            val cr = context.contentResolver
            val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            var target: android.net.Uri? = null
            cr.query(
                collection,
                arrayOf(MediaStore.Downloads._ID),
                MediaStore.Downloads.DISPLAY_NAME + "=?",
                arrayOf(name),
                null,
            )?.use { c ->
                if (c.moveToFirst()) {
                    target = android.content.ContentUris.withAppendedId(collection, c.getLong(0))
                }
            }
            if (target == null) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, name)
                    put(MediaStore.Downloads.MIME_TYPE, "application/zip")
                    put(MediaStore.Downloads.RELATIVE_PATH, rel)
                    if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Downloads.IS_PENDING, 1)
                }
                target = cr.insert(collection, values)
            } else if (Build.VERSION.SDK_INT >= 29) {
                cr.update(target!!, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 1) }, null, null)
            }
            val dest = target ?: return ""
            cr.openOutputStream(dest, "w")?.use { out ->
                FileInputStream(zip).use { it.copyTo(out) }
            } ?: return ""
            if (Build.VERSION.SDK_INT >= 29) {
                cr.update(dest, ContentValues().apply { put(MediaStore.Downloads.IS_PENDING, 0) }, null, null)
            }
            "Download/ProjectTricorder/$name"
        } catch (_: Exception) {
            ""
        }
    }

    private fun zipDir(dir: File, zipFile: File, skipName: String) {
        ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
            dir.listFiles()?.forEach { f ->
                if (!f.isFile || f.name == skipName) return@forEach
                zos.putNextEntry(ZipEntry(f.name))
                FileInputStream(f).use { it.copyTo(zos) }
                zos.closeEntry()
            }
        }
    }

    private fun unzip(zip: File, dest: File) {
        ZipInputStream(BufferedInputStream(FileInputStream(zip))).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                val name = File(e.name).name
                if (name.isNotBlank() && !e.isDirectory) {
                    FileOutputStream(File(dest, name)).use { zis.copyTo(it) }
                }
                zis.closeEntry()
                e = zis.nextEntry
            }
        }
    }

    private fun copyFile(src: File, dest: File) {
        if (!src.exists() || src.length() == 0L) return
        dest.parentFile?.mkdirs()
        src.copyTo(dest, overwrite = true)
    }

    private fun writeText(f: File, body: String) {
        if (body.isEmpty()) return
        f.parentFile?.mkdirs()
        f.writeText(body)
    }
}
