package com.projecttricorder.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException

/**
 * One beat for polled work. Incoming PTT and subspace frames are not slots:
 * they arrive on the radio callback and must not wait for a poll.
 */
class PollSlicer(
    private val context: Context,
    private val tick: (String) -> Unit,
) {
    private val beat = Executors.newSingleThreadScheduledExecutor()
    private val work = Executors.newSingleThreadExecutor()
    private val last = HashMap<String, Long>()
    private var anchor = 0L
    @Volatile private var running = false

    fun start() {
        if (running) return
        running = true
        anchor = System.currentTimeMillis()
        beat.scheduleWithFixedDelay({ safeBeat() }, 3, 1, TimeUnit.SECONDS)
    }

    fun stop() {
        running = false
    }

    fun schedule(): JSONObject {
        return defaultSchedule(context)
    }

    private fun safeBeat() {
        if (!running) return
        try { beatOnce() } catch (_: Exception) {}
    }

    private fun beatOnce() {
        val slots = schedule().optJSONArray("slots") ?: return
        val now = System.currentTimeMillis()
        var due: JSONObject? = null
        var overdue = -1L
        for (i in 0 until slots.length()) {
            val slot = slots.optJSONObject(i) ?: continue
            if (!slot.optBoolean("enabled", true)) continue
            if (slot.optBoolean("realtime", false)) continue
            val id = slot.optString("id")
            if (id.isBlank()) continue
            val interval = slot.optLong("interval_s", 120).coerceIn(30, 7200) * 1000L
            val phase = slot.optLong("phase_s", 0).coerceAtLeast(0) * 1000L
            val origin = if (anchor > 0) anchor else now
            val waited = now - (last[id] ?: (origin - interval + phase))
            if (waited < interval) continue
            if (waited > overdue) {
                overdue = waited
                due = slot
            }
        }
        val slot = due ?: return
        val id = slot.optString("id")
        val dwell = slot.optLong("dwell_s", 20).coerceIn(2, 40)
        last[id] = now
        val job = work.submit { tick(id) }
        try {
            job.get(dwell, TimeUnit.SECONDS)
        } catch (_: TimeoutException) {
            job.cancel(true)
        } catch (_: Exception) {}
    }

    companion object {
        fun defaultSchedule(context: Context): JSONObject {
            fun p(k: String, d: String) = context.getSharedPreferences("tricorder", Context.MODE_PRIVATE).getString(k, d) ?: d
            fun on(k: String) = p(k, "1") != "0"
            return JSONObject()
                .put("slots", JSONArray()
                    .put(slot("flight", p("poll_flight_s", "360").toInt(), 12, 0, 0, on("poll_flight_on")))
                    .put(slot("civic", p("poll_civic_s", "600").toInt(), 12, 0, 180, on("poll_civic_on")))
                    .put(slot("weather", p("poll_weather_s", "900").toInt(), 10, 0, 420, on("poll_weather_on")))
                    .put(slot("audio", p("poll_audio_s", "20").toInt(), p("poll_audio_dwell", "5").toInt(), p("poll_audio_sleep", "15").toInt(), 0, on("poll_audio_on")))
                    .put(slot("aloha", p("aloha_min", "3").toInt() * 60, 2, 0, 30, true))
                    .put(slot("subspace_tx", (60 / p("subspace_per_min", "1").toInt().coerceIn(1, 5)), 2, 0, 15, true)))
                .put("realtime", JSONArray().put("ptt_rx").put("subspace_rx").put("aloha_rx").put("gatt_drain"))
                .put("caps", JSONObject().put("flight_per_day", 240).put("note", "OpenSky anonymous budget stays under 400/day"))
        }
        private fun slot(id: String, interval: Int, dwell: Int, sleep: Int, phase: Int, enabled: Boolean) = JSONObject()
            .put("id", id)
            .put("interval_s", interval)
            .put("dwell_s", dwell)
            .put("sleep_s", sleep)
            .put("phase_s", phase)
            .put("enabled", enabled)
    }
}
